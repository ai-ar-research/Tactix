// Sweep: candidate selection and environment construction
// (docs/design/v5-sweep-design.md). What makes detection worth anything, one
// test each: it finds equivalences RUP cannot, every claim it makes holds in
// every model of the original formula, the environment is made of F's own
// clauses (same literals, same proof id), and the limits bind without
// truncating a clause.
#undef NDEBUG
#include "kernel/kernel.hpp"
#include "proof/proof.hpp"
#include "rules/congruence/congruence.hpp" // congruence_replay_rup, RupReplay
#include "rules/propagate/propagate.hpp"
#include "rules/sweep/sweep.hpp"
#include "rules/substitute/substitute.hpp"

#include <algorithm>
#include <cassert>
#include <cstdio>
#include <cstring>
#include <random>
#include <vector>

using namespace tactix;

// White-box proof-adapter regression: the public Sweep action deliberately
// closes pending root propagation first, so this test names the existing
// internal emission boundary without adding a new public rule action.
namespace tactix {
void sweep_capture_core_units_for_test(Kernel &, SweepDirProof &, SweepRound &,
                                       const SweepLimits &);
ApplyResult sweep_emit_round_for_test(Kernel &, SweepRound &, uint32_t,
                                      const SweepLimits &);
bool sweep_normalize_lrat_capture(const SweepEnv &, SweepDirProof &);
}

static void test_effort_prices_embedded_and_representation_ticks() {
  Kernel k;
  k.stats.sweep_ticks_sub = 17;
  k.stats.sweep_ticks_repr = 1000;
  assert(sweep_effort(k) == 1017);
  assert(sweep_semantic_effort(k) == 17);
}

static void test_core_prefixes_share_one_immutable_derivation() {
  SweepDirProof parent;
  parent.steps.push_back(SubStep{3, {0}, {1}, {}});
  parent.steps.push_back(SubStep{4, {2}, {3}, {}});
  parent.share_steps();
  assert(parent.steps.empty());
  assert(parent.steps_view().size() == 2);

  SweepDirProof prefix;
  prefix.shared_steps = parent.shared_steps;
  prefix.shared_step_count = 1;
  assert(prefix.steps_view().size() == 1);
  assert(prefix.steps_view()[0].id == 3);
  assert(parent.shared_steps.use_count() == 2);
  parent = {};
  assert(prefix.steps_view()[0].id == 3);
}

static void test_lrat_capture_replays_lifted_cube() {
  SweepEnv env;
  env.vars = {0, 1};
  env.sub_of_var = {0, 1};
  env.clause_ids = {1, 2, 3};
  env.clause_lits = {internalize(-1), internalize(2),
                     internalize(1), internalize(2), internalize(1)};
  env.clause_off = {0, 2, 4, 5};
  SweepDirProof proof;
  proof.t0 = internalize(1);
  // Under the sub-solver's original -2 cube, hint 1 propagates -1 and hint 2
  // conflicts. The lifted (+1 v +2) lemma also assumes -1: hint 1 is now
  // satisfied and must be omitted, leaving hint 2 as the conflict.
  proof.steps.push_back(SubStep{4, {sub_lit(1, false)}, {1, 2}, {}});
  proof.steps.push_back(SubStep{5, {sub_lit(0, false)}, {3}, {}});
  assert(sweep_normalize_lrat_capture(env, proof));
  assert((std::vector<uint32_t>(proof.chain_view(0).begin(),
                                proof.chain_view(0).end()) ==
          std::vector<uint32_t>{2}));
  assert((std::vector<uint32_t>(proof.chain_view(1).begin(),
                                proof.chain_view(1).end()) ==
          std::vector<uint32_t>{3}));

  // A corrupted remaining antecedent cannot close; the proof direction must
  // decline before Sweep emits even its first temporary lemma.
  proof.steps[0].chain = {1, 2};
  env.clause_lits[3] = internalize(-2);
  assert(!sweep_normalize_lrat_capture(env, proof));
}

static void test_lrat_core_prefix_uses_its_own_target_cube() {
  SweepEnv env;
  env.vars = {0, 1, 2};
  env.sub_of_var = {0, 1, 2};
  env.clause_ids = {1, 2};
  // Under -1, clause 1 propagates 2 and clause 2 conflicts. A direction
  // also assuming -2 conflicts at clause 1 alone; a separate core unit 3
  // still needs both hints. The same raw prefix can serve both targets only
  // when each has its own normalized chain.
  env.clause_lits = {internalize(1), internalize(2), internalize(-2)};
  env.clause_off = {0, 2, 3};
  SweepDirProof direction;
  direction.t0 = internalize(2);
  direction.steps.push_back(SubStep{3, {sub_lit(0, false)}, {1, 2}, {}});
  assert(sweep_normalize_lrat_capture(env, direction));
  assert(direction.chain_view(0).size() == 1);
  assert(direction.chain_view(0)[0] == 1);
  direction.share_steps();
  SweepDirProof core;
  core.t0 = internalize(3);
  core.shared_steps = direction.shared_steps;
  core.shared_step_count = 1;
  assert(sweep_normalize_lrat_capture(env, core));
  assert(core.chain_view(0).size() == 2);
  assert(core.chain_view(0)[0] == 1 && core.chain_view(0)[1] == 2);
  assert(direction.chain_view(0).size() == 1);
  assert(direction.steps_view()[0].chain.size() == 2);
}

static void test_unbounded_clause_limit_sizes_from_formula() {
  Kernel k;
  kernel_reserve_vars(k, 3);
  const Lit clause[] = {internalize(1), internalize(2), internalize(3)};
  kernel_add_large_clause(k, clause, 3, false, 0);
  SweepLimits limits;
  limits.max_env_clauses = UINT32_MAX;
  limits.max_env_clauses_ceiling = UINT32_MAX;
  limits.max_seeds = 1;
  limits.round_ticks = 1;
  SweepRound round;
  sweep_round_begin(k, round);
  assert(sweep_env_build(k, 0, limits, round));
  // An unbounded semantic cap retains the ordinary reference-sized initial
  // table and grows from actual admissions; it never sizes from UINT32_MAX.
  assert(round.env.key_slots.size() == 4096);
  assert(sweep_apply_exact_limits(k, limits) != ApplyResult::Unsat);
  kernel_check_invariants(k);
}

static void test_dense_entry_flushes_only_irredundant_satisfied_clauses() {
  Kernel k;
  kernel_reserve_vars(k, 4);
  const Lit root = internalize(1);
  k.unit_ids[var_of(root)] = ++k.next_clause_id;
  kernel_assign_unit(k, root);
  const Lit irred_lits[3] = {root, internalize(2), internalize(3)};
  const Lit red_lits[3] = {root, internalize(3), internalize(4)};
  const Ref irred = kernel_add_large_clause(
      k, irred_lits, 3, false, 0, ++k.next_clause_id);
  const Ref red = kernel_add_large_clause(k, red_lits, 3, true, 2,
                                          ++k.next_clause_id);

  SweepRound round;
  SweepLimits limits;
  limits.max_seeds = 1;
  (void)sweep_detect_round(k, limits, round);

  assert(clause_at(k.arena, irred)->garbage());
  assert(!clause_at(k.arena, red)->garbage());
}

namespace {

// Build a kernel from DIMACS-style clauses, ids in input order as the parser
// hands them out.
void build(Kernel &k, uint32_t nvars, const std::vector<std::vector<int>> &cls) {
  kernel_reserve_vars(k, nvars);
  for (const auto &c : cls) {
    const uint64_t id = ++k.next_clause_id;
    if (c.size() == 1) {
      k.unit_ids[var_of(internalize(c[0]))] = id;
      kernel_assign_unit(k, internalize(c[0]));
      continue;
    }
    if (c.size() == 2) {
      kernel_add_binary_clause(k, internalize(c[0]), internalize(c[1]), id);
      continue;
    }
    std::vector<Lit> lits;
    for (const int e : c)
      lits.push_back(internalize(e));
    kernel_add_large_clause(k, lits.data(), static_cast<uint32_t>(lits.size()),
                            false, static_cast<uint32_t>(lits.size()), id);
  }
}

bool satisfies(const std::vector<std::vector<int>> &cls, uint32_t bits) {
  for (const auto &c : cls) {
    bool ok = false;
    for (const int e : c) {
      const bool value = (bits >> (std::abs(e) - 1)) & 1u;
      ok = ok || (value == (e > 0));
    }
    if (!ok)
      return false;
  }
  return true;
}

// `a ≡ b` in every model of `cls` (vacuously true for an UNSAT formula, which
// is exactly the entailment the rule may use).
bool equivalent_in_all_models(const std::vector<std::vector<int>> &cls,
                              uint32_t nvars, Lit a, Lit b) {
  for (uint32_t bits = 0; bits < (1u << nvars); bits++) {
    if (!satisfies(cls, bits))
      continue;
    const auto value = [&](Lit l) {
      return (((bits >> var_of(l)) & 1u) != 0) != negated(l);
    };
    if (value(a) != value(b))
      return false;
  }
  return true;
}

// Is `(a ∨ b)` derivable by unit propagation alone from F (i.e. RUP)? Assume
// both negations at a decision level and propagate: a conflict means RUP.
bool is_rup_binary(Kernel &k, Lit a, Lit b) {
  kernel_assign_decision(k, negate(a));
  kernel_assign_decision(k, negate(b));
  const bool conflict = kernel_propagate(k);
  k.conflict_valid = false;
  kernel_backtrack(k, 0);
  return conflict;
}

bool same_polarity_pair(const SweepEquiv &e, Lit x, Lit y) {
  return var_of(e.a) != var_of(e.b) &&
         (var_of(e.a) == var_of(x) || var_of(e.a) == var_of(y)) &&
         (var_of(e.b) == var_of(x) || var_of(e.b) == var_of(y)) &&
         negated(e.a) == negated(e.b);
}

// --- 1. the equivalence RUP cannot reach ------------------------------------
// (¬x ∨ y ∨ ±z ∨ ±w) over all four sign patterns says x → y with no unit
// consequence (refuting x ∧ ¬y needs a decision), and the mirrored block gives
// y → x, so F ⊨ x ≡ y while neither binary is RUP.
std::vector<std::vector<int>> non_rup_formula() {
  std::vector<std::vector<int>> cls;
  for (int zs = -1; zs <= 1; zs += 2)
    for (int ws = -1; ws <= 1; ws += 2) {
      cls.push_back({-1, 2, 3 * zs, 4 * ws});
      cls.push_back({1, -2, 3 * zs, 4 * ws});
    }
  return cls;
}

void test_non_rup_equivalence() {
  const std::vector<std::vector<int>> cls = non_rup_formula();
  Kernel k;
  build(k, 4, cls);
  const Lit x = internalize(1), y = internalize(2);
  // the fixture's own premise: neither direction is RUP
  assert(!is_rup_binary(k, negate(x), y));
  assert(!is_rup_binary(k, x, negate(y)));

  SweepRound r;
  SweepLimits lim;
  assert(sweep_guard(k));
  const uint32_t found = sweep_detect_round(k, lim, r);
  assert(found == 1);
  assert(r.found.size() == 1);
  // The full partition is model-polarized. Kitten's deterministic randomized
  // phases may represent x=y as either (x,y) or (-x,-y).
  assert(same_polarity_pair(r.found[0], x, y));
  // reachability: the detector really ran, and really solved candidate pairs
  assert(k.stats.sweep_rounds == 1);
  assert(k.stats.sweep_environments >= 1);
  assert(k.stats.sweep_env_clauses >= 8);
  assert(k.stats.sweep_solves >= 3); // one model + both directions
  assert(k.stats.sweep_candidates >= 2);
  assert(k.stats.sweep_equivalences == 1);
  assert(k.stats.sweep_ticks > 0);
  assert(k.stats.sweep_env_unsat == 0);
  // detection changes nothing: no clause, no unit, no witness
  assert(k.trail.empty() && k.reconstruction.empty());
  assert(k.next_clause_id == cls.size());
}

// Online parameters may request an effectively unbounded model-flip pass.
// The external stop remains an independent bound on that pass, including
// after the embedded solver has already returned a model.
void test_unbounded_flip_rounds_observe_stop() {
  Kernel k;
  build(k, 4, non_rup_formula());
  SweepLimits limits;
  limits.flip_rounds = UINT32_MAX;
  k.stop_fuzz = 1; // every kernel termination poll fires deterministically
  assert(sweep_try_with_limits(k, 0, limits) != ApplyResult::Unsat);
  assert(k.stats.rule_interrupted > 0);
  assert(k.level == 0 && !k.conflict_valid);
}

void test_proof_capture_limit_is_caller_controlled() {
  // The reference default never declines a proved consequence for its size.
  assert(SweepLimits{}.max_proof_steps == 0);
  const std::vector<std::vector<int>> cls = non_rup_formula();
  Kernel limited;
  build(limited, 4, cls);
  SweepRound limited_round;
  SweepLimits limit;
  limit.max_proof_steps = 1;
  assert(sweep_detect_round(limited, limit, limited_round) == 1);
  assert(limited_round.proofs.size() == 1);
  assert(!limited_round.proofs[0].fwd.ok ||
         !limited_round.proofs[0].rev.ok);

  Kernel unbounded;
  build(unbounded, 4, cls);
  SweepRound unbounded_round;
  limit.max_proof_steps = 0;
  assert(sweep_detect_round(unbounded, limit, unbounded_round) == 1);
  assert(unbounded_round.proofs.size() == 1);
  assert(unbounded_round.proofs[0].fwd.ok &&
         unbounded_round.proofs[0].rev.ok);
}

// The per-seed entry point `instances()` drives: the answer must not depend on
// which end of the pair is swept.
void test_seed_symmetry() {
  const std::vector<std::vector<int>> cls = non_rup_formula();
  for (uint32_t seed = 0; seed < 2; seed++) {
    Kernel k;
    build(k, 4, cls);
    SweepRound r;
    SweepLimits lim;
    sweep_round_begin(k, r);
    assert(sweep_detect_seed(k, seed, lim, r) == 1);
    assert(same_polarity_pair(r.found[0], internalize(1), internalize(2)));
  }
}

void test_full_partition_finds_nonseed_pair() {
  std::vector<std::vector<int>> cls;
  for (int xs = -1; xs <= 1; xs += 2)
    for (int us = -1; us <= 1; us += 2)
      for (int vs = -1; vs <= 1; vs += 2) {
        cls.push_back({-2, 3, xs, 4 * us, 5 * vs});
        cls.push_back({2, -3, xs, 4 * us, 5 * vs});
      }

  Kernel legacy;
  build(legacy, 5, cls);
  SweepRound old_round;
  SweepLimits old_lim;
  old_lim.full_partition = false;
  sweep_round_begin(legacy, old_round);
  sweep_detect_seed(legacy, 0, old_lim, old_round);
  const Lit y = internalize(2), z = internalize(3);
  assert(std::none_of(old_round.found.begin(), old_round.found.end(),
                      [&](const SweepEquiv &e) {
                        return same_polarity_pair(e, y, z);
                      }));

  Kernel full;
  build(full, 5, cls);
  SweepRound new_round;
  SweepLimits new_lim;
  new_lim.full_partition = true;
  // Isolate full-partition reach from the model-dependent flip prefilter.
  new_lim.flip_rounds = 0;
  sweep_round_begin(full, new_round);
  assert(sweep_detect_seed(full, 0, new_lim, new_round) >= 1);
  assert(std::any_of(new_round.found.begin(), new_round.found.end(),
                     [&](const SweepEquiv &e) {
                       return same_polarity_pair(e, y, z);
                     }));

  Kernel filtered;
  build(filtered, 5, cls);
  SweepRound filtered_round;
  SweepLimits filtered_lim;
  sweep_round_begin(filtered, filtered_round);
  (void)sweep_detect_seed(filtered, 0, filtered_lim, filtered_round);
  assert(filtered.stats.sweep_flip_attempts > 0);
  assert(filtered.stats.sweep_flipped > 0);
  assert(filtered.stats.sweep_solves < full.stats.sweep_solves &&
         "candidate flips must avoid embedded SAT queries");

  Kernel emitted;
  build(emitted, 5, cls);
  SweepLimits emitted_limits;
  emitted_limits.full_partition = true;
  emitted_limits.flip_rounds = 0;
  emitted_limits.force_general_proof = true;
  assert(sweep_try_with_limits(emitted, 0, emitted_limits) == ApplyResult::Ok);
  assert(kernel_binary_id(emitted, negate(y), z));
  assert(kernel_binary_id(emitted, y, negate(z)));
  assert(emitted.stats.sweep_general >= 1);
}

// Existing implication binaries make an equivalence cheap to detect. Sweep
// keeps the class active and the bridge live; the following Substitute owns
// whole-formula cleanup and retirement.
static void test_known_equivalence_still_substitutes() {
  Kernel k;
  build(k, 3, {{-1, 2}, {-2, 1}});
  assert(sweep_apply(k) == ApplyResult::Ok);
  assert(k.stats.sweep_known >= 1);
  assert(!kernel_var_retired(k, 0) && !kernel_var_retired(k, 1));
  assert(substitute_apply(k) == ApplyResult::Ok);
  assert(kernel_var_retired(k, 0) || kernel_var_retired(k, 1));
}

// The live Sweep representative map, not Kernel retirement, suppresses the
// two preserved implication bridges from every later local environment.
// Kissat's `sweep_binary` declines either a non-representative owner or other
// endpoint before satisfaction/depth handling.  Since Sweep deliberately keeps
// the class active for canonical Substitute, omitting this check imports the
// losing variable and both bridge clauses into the winner's next environment.
static void test_environment_skips_nonrepresentative_bridges() {
  Kernel k;
  build(k, 3, {{1, 3}, {-1, -3}});
  SweepRound round;
  SweepLimits limits;
  sweep_round_begin(k, round);

  const Lit one = internalize(1), two = internalize(2);
  kernel_add_binary_clause(k, negate(one), two, ++k.next_clause_id);
  kernel_add_binary_clause(k, one, negate(two), ++k.next_clause_id);
  const ApplyResult rewritten = substitute_apply_sweep_equivalences(
      k, {{one, two}}, round.substitution);
  assert(rewritten == ApplyResult::Ok || rewritten == ApplyResult::NoOp);
  round.repr[two] = one;
  round.repr[negate(two)] = negate(one);

  assert(sweep_env_build(k, var_of(one), limits, round));
  assert(round.env.vars.size() == 2);
  assert(round.env.nclauses() == 2);
  for (const Lit lit : round.env.clause_lits)
    assert(var_of(lit) != var_of(two));
}

// Sweep commits backbone units before its equivalence batch. If one member of
// a proved class is fixed by that batch, the class implies a unit on the other
// member; dropping the pair loses a core consequence.
static void test_equivalence_with_new_unit_forces_partner() {
  Kernel k;
  build(k, 3, {{1, 3}, {1, -3}, {-1, 2}, {-2, 1}});
  // One seed is enough: the failed-assumption core exposes unit 1 first, and
  // the following lemma (-1 v 2) must then be simplified against that newly
  // committed root fact to expose unit 2 in the same core transaction.  A
  // detector that retains only its final target loses this ordered consequence.
  assert(sweep_try(k, 0) == ApplyResult::Ok);
  assert(k.value(internalize(1)) > 0);
  assert(k.value(internalize(2)) > 0);
  assert(k.stats.sweep_units >= 2);
  assert(k.trail.size() >= 2);
  assert(k.trail[0] == internalize(1));
  assert(k.trail[1] == internalize(2));
}

// At the saved-core boundary, an already-imported original can become unit
// after earlier units in the same seed. Pose that core row directly: a clause
// already unit at environment construction is correctly omitted by the
// builder, and would not test this adapter at all.
static SweepDirProof original_core_unit_proof(const Kernel &k) {
  SweepDirProof proof;
  proof.ok = true;
  proof.vars = {0, 1, 2, 3};
  proof.orig_ids = {1};
  proof.strip_off = {0, 0};
  proof.formula_epoch = k.touch_epoch;
  proof.core_clauses.push_back(
      {1, false, {sub_lit(0, true), sub_lit(1, false),
                  sub_lit(2, false), sub_lit(3, false)}});
  return proof;
}

static void original_core_unit_env(SweepRound &round) {
  SweepEnv &env = round.env;
  env.vars = {0, 1, 2, 3};
  env.sub_of_var = {0, 1, 2, 3};
  env.clause_ids = {1};
  env.clause_lits = {internalize(-1), internalize(2), internalize(3),
                     internalize(4)};
  env.clause_off = {0, 4};
}

static void test_original_core_unit_capture() {
  Kernel not_unit;
  build(not_unit, 4, {{-1, 2, 3, 4}, {-2}, {-3}});
  SweepRound declined;
  SweepLimits limits;
  sweep_round_begin(not_unit, declined);
  original_core_unit_env(declined);
  SweepDirProof not_unit_proof = original_core_unit_proof(not_unit);
  sweep_capture_core_units_for_test(not_unit, not_unit_proof, declined, limits);
  assert(declined.units.empty()); // -1 and 4 are both still non-false

  Kernel k;
  build(k, 4, {{-1, 2, 3, 4}, {-2}, {-3}, {-4}});
  SweepRound round;
  sweep_round_begin(k, round);
  original_core_unit_env(round);
  SweepDirProof proof = original_core_unit_proof(k);
  sweep_capture_core_units_for_test(k, proof, round, limits);
  assert(!round.units.empty());
  const SweepUnitProof &unit = round.units.front();
  assert(unit.unit == internalize(-1));
  const auto steps = unit.proof.steps_view();
  assert(steps.size() == 1);
  assert(steps[0].chain.size() == 1 && steps[0].chain[0] == 1);
  assert(sweep_emit_round_for_test(k, round, 0, limits) == ApplyResult::Ok);
  assert(k.value(internalize(-1)) > 0);
  assert(k.stats.sweep_units >= 1);
}

// --- 2. every claim is true --------------------------------------------------
void test_brute_force_oracle(uint32_t rounds) {
  std::mt19937 rng(20260805);
  uint64_t claims = 0, nontrivial = 0, envs = 0;
  for (uint32_t it = 0; it < rounds; it++) {
    const uint32_t nvars = 3 + rng() % 4; // 3..6
    const uint32_t nclauses = 2 + rng() % 10;
    std::vector<std::vector<int>> cls;
    for (uint32_t c = 0; c < nclauses; c++) {
      const uint32_t size = 2 + rng() % 3; // 2..4 (units are built separately)
      std::vector<int> lits;
      for (uint32_t i = 0; i < size; i++) {
        const int v = 1 + static_cast<int>(rng() % nvars);
        const int l = (rng() & 1) ? v : -v;
        if (std::find(lits.begin(), lits.end(), l) == lits.end() &&
            std::find(lits.begin(), lits.end(), -l) == lits.end())
          lits.push_back(l);
      }
      if (lits.size() >= 2)
        cls.push_back(lits);
    }
    if (cls.empty())
      continue;
    Kernel k;
    build(k, nvars, cls);
    SweepRound r;
    SweepLimits lim;
    lim.max_depth = 1 + rng() % 3;
    lim.max_env_vars = 2 + rng() % 6;
    lim.max_env_clauses = 2 + rng() % 10;
    lim.max_candidates = 1 + rng() % 4;
    sweep_detect_round(k, lim, r);
    envs += k.stats.sweep_environments;
    for (const SweepEquiv &e : r.found) {
      claims++;
      assert(e.a < e.b);
      assert(var_of(e.a) != var_of(e.b));
      assert(equivalent_in_all_models(cls, nvars, e.a, e.b));
      // was it something the formula did not already say?
      Kernel probe;
      build(probe, nvars, cls);
      nontrivial += !is_rup_binary(probe, negate(e.a), e.b) ||
                    !is_rup_binary(probe, e.a, negate(e.b));
    }
    // the round leaves the formula alone
    assert(k.stats.sweep_equivalences == r.found.size());
  }
  // Reachability at the source: an oracle over zero environments or zero
  // claims is vacuous.
  printf("  oracle: %llu environments, %llu claims (%llu not RUP)\n",
         (unsigned long long)envs, (unsigned long long)claims,
         (unsigned long long)nontrivial);
  assert(envs > 0);
  assert(claims > 0);
  // Non-RUP claims are rare on formulas this small, so only the default-length
  // run is large enough to require one.
  assert(nontrivial > 0 || rounds < 20000);
}

// --- 3. the environment is made of F's clauses -------------------------------
// Every environment clause must be a kernel clause: same literal set, same
// proof id. That is what `env ⊆ F` and the core→id mapping rest on.
void test_env_provenance() {
  std::mt19937 rng(4242);
  for (uint32_t it = 0; it < 200; it++) {
    const uint32_t nvars = 4 + rng() % 5;
    std::vector<std::vector<int>> cls;
    for (uint32_t c = 0; c < 12; c++) {
      std::vector<int> lits;
      const uint32_t size = 2 + rng() % 3;
      for (uint32_t i = 0; i < size; i++) {
        const int v = 1 + static_cast<int>(rng() % nvars);
        const int l = (rng() & 1) ? v : -v;
        if (std::find(lits.begin(), lits.end(), l) == lits.end() &&
            std::find(lits.begin(), lits.end(), -l) == lits.end())
          lits.push_back(l);
      }
      if (lits.size() >= 2)
        cls.push_back(lits);
    }
    if (cls.empty())
      continue;
    Kernel k;
    build(k, nvars, cls);
    SweepRound r;
    SweepLimits lim;
    sweep_round_begin(k, r);
    for (Var seed = 0; seed < nvars; seed++) {
      if (!sweep_env_build(k, seed, lim, r))
        continue;
      const SweepEnv &e = r.env;
      for (uint32_t c = 0; c < e.nclauses(); c++) {
        std::vector<int> got;
        for (uint32_t i = e.clause_off[c]; i < e.clause_off[c + 1]; i++)
          got.push_back(externalize(e.clause_lits[i]));
        std::sort(got.begin(), got.end());
        assert(e.clause_ids[c] != 0 && "every environment clause is cited");
        assert(e.clause_ids[c] <= cls.size());
        std::vector<int> want = cls[e.clause_ids[c] - 1];
        std::sort(want.begin(), want.end());
        assert(got == want && "environment clause differs from F's clause");
        // every variable is mapped into the sub-solver's space
        for (uint32_t i = e.clause_off[c]; i < e.clause_off[c + 1]; i++)
          assert(e.sub_of_var[var_of(e.clause_lits[i])] < e.vars.size());
      }
    }
  }
}

void test_equal_depth_binary_encounters() {
  Kernel k;
  build(k, 3, {{1, 2}, {1, 3}, {2, 3}});
  SweepRound r;
  SweepLimits lim;
  sweep_round_begin(k, r);
  assert(sweep_env_build(k, 0, lim, r));
  const SweepEnv &e = r.env;

  // The seed introduces variables 2 and 3 at the same BFS depth. Kissat then
  // copies their connecting binary from both directed watch encounters:
  // (2,3) when expanding 2 and (3,2) when expanding 3. A canonical pair-set
  // dedup loses the second clause and changes Kitten's watch/query trajectory.
  assert(e.nclauses() == 4);
  assert((e.clause_ids == std::vector<uint64_t>{1, 2, 3, 3}));
  const uint32_t a = e.clause_off[2], b = e.clause_off[3];
  assert(externalize(e.clause_lits[a]) == 2);
  assert(externalize(e.clause_lits[a + 1]) == 3);
  assert(externalize(e.clause_lits[b]) == 3);
  assert(externalize(e.clause_lits[b + 1]) == 2);
}

// --- 4. structural limits bind between whole expansion steps -----------------
void test_limits() {
  // a 6-variable clique of binaries: every seed can reach every variable
  std::vector<std::vector<int>> cls;
  for (int a = 1; a <= 6; a++)
    for (int b = a + 1; b <= 6; b++)
      cls.push_back({a, -b});
  Kernel k;
  build(k, 6, cls);
  SweepRound r;
  for (uint32_t cap = 1; cap <= 8; cap++) {
    SweepLimits lim;
    lim.max_env_clauses = cap;
    lim.max_env_vars = cap;
    sweep_round_begin(k, r);
    for (Var seed = 0; seed < 6; seed++) {
      if (!sweep_env_build(k, seed, lim, r))
        continue;
      // Kissat checks after adding a whole clause, so a binary can cross the
      // variable cap by one; it never truncates or declines that clause.
      assert(r.env.vars.size() <= cap + 1);
      for (uint32_t c = 0; c + 1 < r.env.clause_off.size(); c++)
        assert(r.env.clause_off[c + 1] - r.env.clause_off[c] == 2);
    }
  }
  // The clause cap is checked before expanding a variable, not after each of
  // its watches. One expansion therefore lands whole and may overshoot.
  SweepLimits overshoot;
  overshoot.max_env_clauses = 1;
  overshoot.max_env_vars = 100;
  sweep_round_begin(k, r);
  assert(sweep_env_build(k, 0, overshoot, r));
  assert(r.env.nclauses() == 5);
  // depth 0 keeps the environment to the seed's own clauses
  SweepLimits lim;
  lim.max_depth = 0;
  sweep_round_begin(k, r);
  assert(sweep_env_build(k, 0, lim, r));
  for (uint32_t c = 0; c < r.env.nclauses(); c++) {
    bool touches_seed = false;
    for (uint32_t i = r.env.clause_off[c]; i < r.env.clause_off[c + 1]; i++)
      touches_seed = touches_seed || var_of(r.env.clause_lits[i]) == 0;
    assert(touches_seed);
  }
}

// --- 5. an equivalence the formula already states ----------------------------
void test_known_equivalence() {
  // Detection follows Kissat's candidate pipeline even when the two binaries
  // already state the equivalence.  Duplicate suppression belongs to emission;
  // short-circuiting here changes the embedded model/watch trajectory.
  Kernel k;
  build(k, 3, {{-1, 2}, {1, -2}, {1, 3}, {-3, 2}});
  SweepRound r;
  SweepLimits lim;
  assert(sweep_detect_round(k, lim, r) >= 1);
  assert(!r.found.empty());
  assert(k.stats.sweep_known == 0);
}

// --- 6. the seed surface -----------------------------------------------------
void test_seeds() {
  Kernel k;
  build(k, 5, {{1, 2}, {-1, 3}, {4, 5}});
  std::vector<Var> seeds;
  sweep_seeds(k, seeds);
  assert(seeds.size() == 5);
  // a root-fixed variable is not a seed (its equivalences are units, V1/V2's
  // delta), nor is a retired one
  k.unit_ids[0] = ++k.next_clause_id;
  kernel_assign_unit(k, internalize(1));
  k.var_status.resize(k.nvars, VarStatus::Active); // BVE would have sized it
  k.var_status[3] = VarStatus::Eliminated;
  sweep_seeds(k, seeds);
  assert(std::find(seeds.begin(), seeds.end(), 0u) == seeds.end());
  assert(std::find(seeds.begin(), seeds.end(), 3u) == seeds.end());
  assert(seeds.size() == 3);
  // ...and sweeping one anyway is a no-op, not an assertion (totality)
  SweepRound r;
  SweepLimits lim;
  sweep_round_begin(k, r);
  assert(sweep_detect_seed(k, 0, lim, r) == 0);
  assert(sweep_detect_seed(k, 3, lim, r) == 0);

  // Dense scheduling counts each large occurrence once. The sparse watches
  // for the first two literals of a large clause remain connected in Tactix;
  // they must not be added on top of the all-literal dense index.
  Kernel ranked;
  build(ranked, 6, {{1, 3, 2}, {-1, 4, 2}, {5, 6, -2}});
  OccIndex occ;
  kernel_dense_connect(ranked, occ);
  sweep_seeds(ranked, seeds);
  const auto one = std::find(seeds.begin(), seeds.end(), 0u);
  const auto two = std::find(seeds.begin(), seeds.end(), 1u);
  assert(one != seeds.end() && two != seeds.end() && one < two);
  kernel_dense_disconnect(ranked);
}

void test_resumable_schedule() {
  const std::vector<std::vector<int>> cls = {
      {1, 2}, {-1, 3}, {-2, 4}, {-3, -4}};
  SweepLimits one_seed;
  one_seed.max_seeds = 1;

  Kernel off;
  build(off, 4, cls);
  SweepLimits off_limits = one_seed;
  off_limits.resume = false;
  sweep_apply_with_limits(off, off_limits);
  sweep_apply_with_limits(off, off_limits);
  assert(off.sweep_tail.empty());
  assert(off.stats.sweep_resumed == 0 && off.stats.sweep_completed == 0);

  Kernel filtered;
  build(filtered, 3, {{1, 2}, {-1, 2}});
  sweep_apply_with_limits(filtered, one_seed);
  assert(filtered.stats.sweep_scheduled == 1);
  assert(filtered.stats.sweep_completed == 1);
  std::vector<Var> complete_surface;
  sweep_seeds(filtered, complete_surface);
  assert(filtered.stats.sweep_units == 1);
  assert(complete_surface.size() == 2); // only the newly fixed var leaves scope

  Kernel growth;
  build(growth, 3, {{1, 2}, {1, 3}, {-1, 2}, {-1, 3}});
  SweepLimits growth_limits = one_seed;
  growth_limits.max_env_clauses = 1;
  sweep_apply_with_limits(growth, growth_limits);
  assert(growth.stats.sweep_scheduled == 0 &&
         growth.stats.sweep_completed == 1);
  sweep_apply_with_limits(growth, growth_limits);
  assert(growth.stats.sweep_limit_clauses == 2);
  assert(growth.stats.sweep_scheduled == 1);
  Kernel on;
  build(on, 4, cls);
  sweep_apply_with_limits(on, one_seed);
  // Productive seeds move their surviving representatives to the pop end
  // (the reschedule front), exactly as Kissat's schedule_inner does. The
  // original four entries remain the scheduled baseline, but completion is
  // no longer necessarily four calls after a productive first seed.
  assert(on.sweep_tail.size() == 4 && on.sweep_tail_next == 1 &&
         on.sweep_live >= 3);
  assert(on.stats.sweep_scheduled == 4 && on.stats.sweep_resumed == 0);
  (void)substitute_apply(on); // mandatory post-Sweep phase owner
  const uint32_t live_before = on.sweep_live;
  // Substitution leaves only an isolated representative. Entry revalidation
  // drains that retained seed without attempting another environment.
  assert(!kernel_var_retired(on, 0));
  assert(on.watches.size(make_lit(0, false)) == 0 &&
         on.watches.size(make_lit(0, true)) == 0);
  for (Var v = 1; v < 4; v++)
    assert(kernel_var_retired(on, v));
  sweep_apply_with_limits(on, one_seed);
  assert(on.sweep_live < live_before && on.sweep_live == 0 &&
         on.stats.sweep_resumed == 0);
  (void)substitute_apply(on);
  for (uint32_t calls = 0; !on.sweep_passes_completed && calls < 16; calls++) {
    sweep_apply_with_limits(on, one_seed);
    (void)substitute_apply(on);
  }
  assert(on.sweep_tail.empty() && on.sweep_tail_next == 0);
  assert(on.sweep_passes_completed == 2 && on.stats.sweep_completed == 2);
  assert(on.stats.sweep_limit_vars == 256 &&
         on.stats.sweep_limit_clauses == 1024 &&
         on.stats.sweep_limit_depth == 2);

  sweep_apply_with_limits(on, one_seed);
  assert(on.stats.sweep_limit_vars == 1024 &&
         on.stats.sweep_limit_clauses == 4096 &&
         on.stats.sweep_limit_depth == 3);
}

// Kissat reschedules a proved pair's REPRESENTATIVE — `schedule_inner
// (sweeper, repr_idx)` in `sweep_equivalence_candidates`, where the
// representative is the endpoint with the smaller internal index, i.e. Tactix's
// import order. Reading it off "whichever endpoint escaped retirement" happens
// to agree only while a substitution actually lands, and names nothing at all
// when the pair is declined. Both import orders are exercised because the
// representative is not a function of the external numbering.
void test_reschedules_pair_representative_by_import_order() {
  SweepLimits limits;
  limits.max_seeds = 1;
  for (uint32_t flipped = 0; flipped < 2; flipped++) {
    Kernel k;
    kernel_reserve_vars(k, 3);
    kernel_record_import(k, flipped ? 1 : 0);
    kernel_record_import(k, flipped ? 0 : 1);
    kernel_record_import(k, 2);
    kernel_add_binary_clause(k, internalize(-1), internalize(2),
                             ++k.next_clause_id);
    kernel_add_binary_clause(k, internalize(-2), internalize(1),
                             ++k.next_clause_id);
    assert(sweep_apply_with_limits(k, limits) == ApplyResult::Ok);

    const Var representative = flipped ? 1u : 0u;
    assert(!kernel_var_retired(k, representative));
    assert(!kernel_var_retired(k, flipped ? 0u : 1u));
    assert(k.stats.sweep_rescheduled == 1);
    assert(sweep_next_scheduled(k) == k.internal_to_external[representative]);
    assert(substitute_apply(k) == ApplyResult::Ok);
    assert(kernel_var_retired(k, flipped ? 0u : 1u));
  }
}

// One environment can prove several pairs, and every pair is rescheduled on
// its own representative. When those pairs share a class, only the class
// minimum survives: an intermediate representative is retired by the same
// batch and `schedule_inner` declines an inactive variable (kissat flags.c
// `kissat_mark_fixed_literal` deactivates a fixed one the same way). Reading
// the representative off the pair, as Kissat does, is what makes this case
// reachable at all — and rescheduling a retired identity would seed a variable
// that no longer occurs in F.
//
// The chain x1 = x2 = x3 is proved from a single environment, so one of the
// two pairs names x2 — which the same batch then retires into x1.
void test_reschedule_declines_a_retired_representative() {
  SweepLimits limits;
  limits.max_seeds = 1;
  Kernel k;
  kernel_reserve_vars(k, 5);
  // Four ternaries state the equivalence without handing unit propagation a
  // binary, so detection has to prove it and the pair is not already known.
  const auto equate = [&](int left, int right, int helper) {
    for (uint32_t mask = 0; mask < 4; mask++) {
      const int sign = (mask & 1) ? 1 : -1;
      const int h = (mask & 2) ? helper : -helper;
      const Lit clause[3] = {internalize(-sign * left),
                             internalize(sign * right), internalize(h)};
      kernel_add_large_clause(k, clause, 3, false, 0, ++k.next_clause_id);
    }
  };
  equate(1, 2, 4);
  equate(2, 3, 5);

  assert(sweep_apply_with_limits(k, limits) == ApplyResult::Ok);
  const Var minimum = var_of(internalize(1));
  const Var intermediate = var_of(internalize(2));
  assert(k.stats.sweep_equivalences == 2);
  assert(!kernel_var_retired(k, minimum));
  assert(!kernel_var_retired(k, intermediate));
  assert(!kernel_var_retired(k, var_of(internalize(3))));
  // Two pairs, one live representative: the retired one is declined.
  assert(k.stats.sweep_rescheduled == 1);
  // The retired identity keeps its original schedule slot, where the seed
  // loop skips it; what it must not do is take the pop end from the live
  // representative.
  assert(sweep_next_scheduled(k) == k.internal_to_external[minimum]);
  assert(substitute_apply(k) == ApplyResult::Ok);
  assert(kernel_var_retired(k, intermediate));
  assert(kernel_var_retired(k, var_of(internalize(3))));
}

// A productive dense environment is a transaction boundary, not just a
// detector boundary.  Its proved unit can force variables outside a depth-zero
// environment; Kissat propagates that trail before choosing/building the next
// seed, so those variables must never become later environments.
void test_resumable_closes_root_between_environments() {
  Kernel k;
  build(k, 6,
        {{1, 2}, {-1, 2}, {-2, 3}, {-3, 4}, {-4, 5}, {-5, 6}});
  SweepLimits limits;
  limits.max_depth = 0;
  assert(sweep_apply_with_limits(k, limits) == ApplyResult::Ok);
  for (Var v = 1; v < 6; v++)
    assert(kernel_root_value(k, make_lit(v, false)) > 0);
  assert(k.stats.sweep_environments == 1 &&
         "root consequences must close before the next environment");
}

// --- 7. an environment that refutes the formula outright ---------------------
void test_env_unsat() {
  // (1)(¬1) is caught before sweeping, so use a refutation the environment
  // finds: the four clauses over {1,2} are UNSAT and every seed sees them all.
  Kernel k;
  build(k, 3, {{1, 2}, {1, -2}, {-1, 2}, {-1, -2}});
  SweepRound r;
  SweepLimits lim;
  assert(sweep_detect_round(k, lim, r) == 0);
  assert(k.stats.sweep_env_unsat >= 1);
  assert(r.found.empty()); // S-c never concludes from an UNSAT environment
  assert(!k.inconsistent); // and never touches the kernel
}

} // namespace

// --- emission of a detected equivalence --------------------------------------
// Detection proves `a == b` inside an environment; emission must justify it
// over the main formula in a form a checker accepts, as two binaries. The
// fixture is a 4-cycle a->c->b, b->d->a, so both directions propagate to a
// conflict and both binaries are replayable.
static void test_sd_emits_rup_equivalence(void) {
  Kernel k;
  kernel_reserve_vars(k, 8);
  const Lit a = make_lit(0, true), b = make_lit(1, true);
  const Lit c = make_lit(2, true), d = make_lit(3, true);
  kernel_add_binary_clause(k, negate(a), c); // a -> c
  kernel_add_binary_clause(k, negate(c), b); // c -> b
  kernel_add_binary_clause(k, negate(b), d); // b -> d
  kernel_add_binary_clause(k, negate(d), a); // d -> a

  const uint64_t before = k.stats.sweep_binaries;
  const ApplyResult r = sweep_apply(k);
  if (r == ApplyResult::NoOp) {
    // Detection is budgeted; with no pair there is nothing to assert here.
    printf("  S-d: detection found nothing on the 4-cycle (emission untested)\n");
    return;
  }
  assert(r == ApplyResult::Ok);
  assert(k.stats.sweep_binaries >= before + 2 &&
         "an emitted equivalence is TWO binaries; one alone would state an "
         "implication the sub-solver did not prove on its own");
  assert(k.stats.sweep_binaries % 2 == 0 && "binaries are emitted in pairs");
  // Which justification carried the pair (the captured core or the replayed
  // RUP chain) is not part of this contract; that none was refused is.
  assert(k.stats.sweep_not_rup == 0);
  printf("  S-d: emitted %llu binaries (%llu via the captured core)\n",
         (unsigned long long)(k.stats.sweep_binaries - before),
         (unsigned long long)k.stats.sweep_general);
}

// A pair that is not RUP over F must be declined, leaving F unchanged;
// emitting here would write a line no checker can verify (an N2 breach).
static void test_sd_declines_non_rup(void) {
  Kernel k;
  kernel_reserve_vars(k, 8);
  // No implication structure at all: nothing is RUP, so nothing may be added.
  kernel_add_binary_clause(k, make_lit(0, true), make_lit(1, true));
  kernel_add_binary_clause(k, make_lit(2, true), make_lit(3, true));
  const size_t bins_before = k.binary_ids.size();
  const uint64_t emitted_before = k.stats.sweep_binaries;
  sweep_apply(k);
  assert(k.stats.sweep_binaries == emitted_before &&
         "nothing is RUP here; emitting would be unverifiable (N2)");
  assert(k.binary_ids.size() == bins_before && "F must be unchanged");
  printf("  S-d: non-RUP pairs declined, F unchanged\n");
}

// "Is this line RUP over F?" is a question about the FORMULA. Its answer cannot
// depend on which certificate format the run happens to be writing, so the
// primitive Sweep admits with must give one verdict in all of them. It used to
// short-circuit to `true` whenever the proof was not native LRAT, which turned
// Sweep's admission test into an unconditional yes and let it emit an
// unreplayable binary under DRAT (corpus 026).
static void test_rup_admission_is_format_independent(void) {
  // Neither direction of the fixture's `1 == 2` is RUP -- that is the premise
  // the whole general path exists for -- so `Decide` must refuse all three.
  const std::vector<std::vector<int>> non_rup = non_rup_formula();
  // ...against a control that is RUP: assume -1 and the two binaries clash.
  const std::vector<std::vector<int>> rup = {{1, 2}, {1, -2}};

  struct Mode {
    const char *name;
    bool proof;
    ProofFormat format;
  };
  const Mode modes[] = {{"no-proof", false, ProofFormat::DratAscii},
                        {"DRAT", true, ProofFormat::DratAscii},
                        {"DSR", true, ProofFormat::DsrAscii},
                        {"LRAT", true, ProofFormat::Lrat}};
  for (const Mode &mode : modes) {
    Proof proof;
    if (mode.proof)
      assert(proof.open("/dev/null", mode.format));

    Kernel hard;
    build(hard, 4, non_rup);
    if (mode.proof)
      hard.proof = &proof;
    const Lit x = internalize(1), y = internalize(2);
    const Lit entailed[2] = {negate(x), y};
    std::vector<uint64_t> chain;
    assert(!congruence_replay_rup(hard, entailed, 2, chain,
                                  RupReplay::Decide) &&
           "an entailed but non-RUP lemma must be declined in every format");
    // The opposite purpose is a deliberate asymmetry, not an oversight:
    // Congruence's own lemmas are RUP by construction, so outside LRAT -- where
    // there is no chain to read -- the replay is pure cost and is skipped.
    assert(congruence_replay_rup(hard, entailed, 2, chain,
                                 RupReplay::ChainOnly) ==
               (mode.proof && mode.format == ProofFormat::Lrat ? false : true) &&
           "ChainOnly replays exactly when a chain is written");

    Kernel easy;
    build(easy, 2, rup);
    if (mode.proof)
      easy.proof = &proof;
    const Lit unit = internalize(1);
    assert(congruence_replay_rup(easy, &unit, 1, chain, RupReplay::Decide) &&
           "a genuinely RUP lemma must be admitted in every format");
    printf("  admission: %s agrees (non-RUP declined, RUP admitted)\n",
           mode.name);
  }
}

// A RUP replay can be requested while Sweep owns a newly committed root unit.
// Applying an assumption first can satisfy a binary watched by that pending
// root literal; retracting the assumption then leaves a unit clause behind a
// cursor that still claims fixpoint.  The shared replay primitive must close
// the inherited root trail before it opens its speculative levels.
static void test_rup_replay_closes_inherited_root_debt() {
  Kernel k;
  kernel_reserve_vars(k, 2);
  const Lit root = internalize(1), implied = internalize(2);
  kernel_add_binary_clause(k, negate(root), implied, ++k.next_clause_id);
  k.unit_ids[var_of(root)] = ++k.next_clause_id;
  kernel_assign_unit(k, root);
  assert(!kernel_propagation_fixpoint(k));

  std::vector<uint64_t> chain;
  assert(congruence_replay_rup(k, &implied, 1, chain,
                               RupReplay::Decide));
  assert(k.value(implied) > 0);
  assert(kernel_propagation_fixpoint(k));
  kernel_check_invariants(k);
}

// --- the general path, and its reachability ---------------------------------
// `non_rup_formula()` carries an equivalence unit propagation cannot refute in
// either direction, so only the captured sub-solver refutation can justify it.
// The `sweep_general` assertion is the reachability proof.
static void test_se_general_path_emits(void) {
  const std::vector<std::vector<int>> cls = non_rup_formula();
  Kernel k;
  build(k, 4, cls);
  const Lit x = internalize(1), y = internalize(2);
  assert(!is_rup_binary(k, negate(x), y)); // premise: S-d cannot do this
  assert(!is_rup_binary(k, x, negate(y)));

  SweepLimits limits;
  limits.force_general_proof = true;
  const ApplyResult r = sweep_apply_exact_limits(k, limits);
  assert(r == ApplyResult::Ok && "the general path must justify what RUP cannot");
  assert(k.stats.sweep_general >= 1 &&
         "S-e NEVER FIRED -- the general path is unreachable and untested");
  assert(k.stats.sweep_binaries >= 2 && "an equivalence is two binaries");
  // Connected irredundant rewriting is immediate, but the equivalence binaries
  // and active class are the durable bridge to the following Substitute.
  assert(k.stats.substitute_vars == 0);
  // Surviving large clauses are rewritten in place at their Ref, so a
  // productive call no longer owes (or prices) a deferred arena rebuild.
  assert(k.stats.sweep_ticks_repr == 0 &&
         "in-place replacement leaves no representation debt to price");
  assert(!kernel_var_retired(k, var_of(x)) &&
         !kernel_var_retired(k, var_of(y)));
  assert(substitute_apply(k) == ApplyResult::Ok);
  assert(kernel_var_retired(k, var_of(x)) ||
         kernel_var_retired(k, var_of(y)));
  printf("  S-e: general path emitted %llu binaries for a non-RUP equivalence\n",
         (unsigned long long)k.stats.sweep_binaries);
}

// The public/random-policy path has no shared dense index. A productive seed
// substitutes inline and garbage-collects the variable-width arena; the next
// resumed seed must traverse a rebuilt occurrence snapshot rather than the old
// Ref offsets. ASan turns the pre-fix stale read into a deterministic failure.
static void test_inline_bridge_refreshes_owned_occurrences(void) {
  std::vector<std::vector<int>> cls = non_rup_formula();
  cls.push_back({5, 6, 7});
  cls.push_back({-5, 6, 7});
  cls.push_back({5, -6, 7});
  Kernel k;
  build(k, 7, cls);
  assert(k.dense == nullptr);
  // Force the later-import environment first. Kissat records all Sweep
  // representatives and the following single Substitute call retires their
  // union in compact internal-index (first-import) order.
  k.sweep_tail = {k.internal_to_external[4], k.internal_to_external[0]};
  k.sweep_tail_next = 0;
  k.sweep_incomplete = true;
  k.sweep_marked.resize(k.external_to_internal.size(), 0);
  for (const Var external : k.sweep_tail)
    k.sweep_marked[external] = 1;

  SweepLimits limits;
  limits.force_general_proof = true;
  assert(sweep_apply_exact_limits(k, limits) == ApplyResult::Ok);
  assert(k.stats.substitute_vars == 0);
  assert(k.stats.sweep_general >= 1);
  assert(substitute_apply(k) == ApplyResult::Ok);
  assert(k.stats.substitute_vars >= 1);
  for (size_t i = 1; i < k.retired_events.size(); i++)
    assert(kernel_import_var_order(k, k.retired_events[i - 1]) <
           kernel_import_var_order(k, k.retired_events[i]));
}

// The canonical dense path carries an ordered occurrence ledger across the
// whole Sweep call, and surviving large clauses are rewritten in place at
// their Ref. Two disjoint productive environments must therefore cause no
// whole-formula arena collection at all, not one bridge apiece. The
// sessionless test above retains the opposite, correctness-required behavior.
static void test_dense_call_collects_once_across_productive_environments() {
  std::vector<std::vector<int>> cls = non_rup_formula();
  for (const std::vector<int> &source : non_rup_formula()) {
    std::vector<int> shifted;
    for (const int lit : source)
      shifted.push_back(lit > 0 ? lit + 4 : lit - 4);
    cls.push_back(std::move(shifted));
  }
  Kernel k;
  build(k, 8, cls);
  OccIndex occ;
  kernel_dense_connect(k, occ);
  k.sweep_tail = {k.internal_to_external[4], k.internal_to_external[0]};
  k.sweep_tail_next = 0;
  k.sweep_incomplete = true;
  k.sweep_marked.resize(k.external_to_internal.size(), 0);
  for (const Var external : k.sweep_tail)
    k.sweep_marked[external] = 1;
  const uint64_t generation = k.arena_generation;
  SweepLimits limits;
  limits.force_general_proof = true;
  assert(sweep_apply_exact_limits(k, limits) == ApplyResult::Ok);
  assert(k.stats.sweep_equivalences >= 2);
  assert(k.stats.substitute_vars == 0);
  assert(k.arena_generation == generation);
  assert(substitute_apply(k) == ApplyResult::Ok);
  assert(k.stats.substitute_vars >= 2);
  for (size_t i = 1; i < k.retired_events.size(); i++)
    assert(kernel_import_var_order(k, k.retired_events[i - 1]) <
           kernel_import_var_order(k, k.retired_events[i]));
  kernel_dense_disconnect(k);
}

// A Sweep session without a dense ledger still rewrites its connected binary
// frontier while retaining the equivalence bridges and active class for the
// following canonical Substitute. If the session omits a losing literal, the
// connected rewrite can keep only the stable direction of a binary and lose
// its mirror -- it still propagates from the surviving side while owning no
// `binary_ids` identity -- or lose a two-moving-endpoint binary altogether.
//
// The check is the two structural invariants, not a verdict: mirrored watches
// and a named id for every live pair.
static void test_sessionless_substitution_keeps_binaries_whole(void) {
  std::vector<std::vector<int>> cls = non_rup_formula(); // 1 == 2, vars 1..4
  // One binary per shape the rewrite treats differently: a retiring endpoint
  // against a stable one in each polarity -- the stable direction is patched in
  // place and only the snapshot rebuilds the mirror -- plus a pair whose image
  // is a tautology, which must be dropped whole rather than half.
  cls.push_back({2, 5});
  cls.push_back({-2, 6});
  cls.push_back({1, -2});
  Kernel k;
  build(k, 6, cls);
  assert(k.dense == nullptr); // the state this regression is about

  SweepLimits limits;
  limits.force_general_proof = true;
  const ApplyResult r = sweep_apply_exact_limits(k, limits);
  assert(r == ApplyResult::Ok);
  assert(k.stats.sweep_equivalences >= 1 &&
         "the connected Sweep substitution under test never ran");

  size_t live_pairs = 0;
  for (Lit lit = 0; lit < 2 * k.nvars; lit++)
    for (const WatchEntry w : k.watches.entries(lit)) {
      if (!w.binary())
        continue;
      const Lit other = w.other();
      assert(kernel_binary_copies(k, other, lit, 1) == 1 &&
             "substitution left a half-watched binary");
      assert(kernel_binary_id(k, lit, other) != 0 &&
             "live binary has no proof identity");
      live_pairs++;
    }
  assert(live_pairs >= 2 && "no binary survived; nothing was checked");
  kernel_check_invariants(k);
  assert(substitute_apply(k) == ApplyResult::Ok);
  assert(k.stats.substitute_vars >= 1);
  printf("  substitution without a dense session kept %zu binary watches "
         "whole\n",
         live_pairs);
}

// --- the emitted proof, through a real checker ------------------------------
// Emitting is not the same as being checkable: a sub-solver literal decoded
// with inverted parity still leaves both correct binaries in F, so detection,
// the pair test and the verdict all look right and only an external checker
// sees the bad lemma (N2). So this writes a self-contained refutation whose
// middle is the general path's output, for drat-trim and lrat-check
// (tests/sweep_proofs.sh). Two checker-only contradictory units close the file
// after Sweep, so the checker validates the whole general-path + inline-
// substitution prefix without depending on transient binaries that the
// substitution correctly deletes.
static void emit_se_case(const char *dir) {
  const std::vector<std::vector<int>> env = non_rup_formula(); // clauses 1..8
  const uint64_t ID_XY = 9, ID_NXNY = 10;

  char path[512];
  snprintf(path, sizeof path, "%s/se.cnf", dir);
  FILE *cnf = fopen(path, "w");
  assert(cnf);
  fprintf(cnf, "p cnf 4 %u\n", static_cast<unsigned>(env.size()) + 2);
  for (const auto &c : env) {
    for (const int e : c)
      fprintf(cnf, "%d ", e);
    fprintf(cnf, "0\n");
  }
  fprintf(cnf, "1 0\n-1 0\n"); // checker-only clauses 9 and 10
  fclose(cnf);

  for (const ProofFormat format : {ProofFormat::DratAscii, ProofFormat::Lrat,
                                   ProofFormat::DsrAscii}) {
    const bool lrat = format == ProofFormat::Lrat;
    const char *suffix = lrat ? "lrat" :
                         format == ProofFormat::DsrAscii ? "dsr" : "drat";
    snprintf(path, sizeof path, "%s/se.%s", dir, suffix);
    Proof proof;
    assert(proof.open(path, format));
    Kernel k;
    // The kernel holds only clauses 1..8: detection needs a satisfiable
    // environment, so 9/10 stay out of F and the contradiction is closed by
    // hand below. The id cursor skips past them so no lemma reuses their ids.
    build(k, 4, env);
    k.next_clause_id = ID_NXNY;
    k.proof = &proof;
    const Lit x = internalize(1), y = internalize(2);
    assert(!is_rup_binary(k, negate(x), y)); // premise: only S-e can do this
    assert(!is_rup_binary(k, x, negate(y)));

    const ApplyResult r = sweep_apply(k);
    assert(r == ApplyResult::Ok && k.stats.sweep_general >= 1 &&
           "S-e must have emitted, or this case checks nothing");

    const uint64_t empty_chain[2] = {ID_XY, ID_NXNY};
    proof.add_empty(++k.next_clause_id, empty_chain, 2);
    proof.flush();
  }
  printf("emitted the S-e case to %s\n", dir);
}

static void emit_unit_case(const char *dir) {
  char path[512];
  snprintf(path, sizeof path, "%s/unit.cnf", dir);
  FILE *cnf = fopen(path, "w");
  assert(cnf);
  fprintf(cnf, "p cnf 2 3\n1 2 0\n1 -2 0\n-1 0\n");
  fclose(cnf);

  for (const ProofFormat format : {ProofFormat::DratAscii, ProofFormat::Lrat,
                                   ProofFormat::DsrAscii}) {
    const bool lrat = format == ProofFormat::Lrat;
    const char *suffix = lrat ? "lrat" :
                         format == ProofFormat::DsrAscii ? "dsr" : "drat";
    snprintf(path, sizeof path, "%s/unit.%s", dir, suffix);
    Proof proof;
    assert(proof.open(path, format));
    Kernel k;
    build(k, 2, {{1, 2}, {1, -2}}); // clause 3 stays checker-only
    k.next_clause_id = 3;
    k.proof = &proof;
    assert(sweep_apply(k) == ApplyResult::Ok && k.stats.sweep_units == 1);
    const uint64_t unit_id = k.unit_ids[var_of(internalize(1))];
    assert(unit_id > 3 && k.value(internalize(1)) > 0);
    const uint64_t empty_chain[2] = {unit_id, 3};
    proof.add_empty(++k.next_clause_id, empty_chain, 2);
    proof.flush();
  }
  printf("emitted the Sweep-unit case to %s\n", dir);
}

// Independently check the exact original-core path above.  Root units 2--4
// justify simplifying the saved original clause; the checker-only opposite
// unit is outside the host kernel and closes the complete certificate.
static void emit_original_core_unit_case(const char *dir) {
  char path[512];
  snprintf(path, sizeof path, "%s/original-core-unit.cnf", dir);
  FILE *cnf = fopen(path, "w");
  assert(cnf);
  fprintf(cnf, "p cnf 4 5\n-1 2 3 4 0\n-2 0\n-3 0\n-4 0\n1 0\n");
  fclose(cnf);

  for (const ProofFormat format : {ProofFormat::DratAscii, ProofFormat::Lrat,
                                   ProofFormat::DsrAscii}) {
    const bool lrat = format == ProofFormat::Lrat;
    const char *suffix = lrat ? "lrat" :
                         format == ProofFormat::DsrAscii ? "dsr" : "drat";
    snprintf(path, sizeof path, "%s/original-core-unit.%s", dir, suffix);
    Proof proof;
    assert(proof.open(path, format));
    Kernel k;
    build(k, 4, {{-1, 2, 3, 4}, {-2}, {-3}, {-4}});
    k.next_clause_id = 5;
    k.proof = &proof;
    SweepRound round;
    SweepLimits limits;
    sweep_round_begin(k, round);
    original_core_unit_env(round);
    SweepDirProof captured = original_core_unit_proof(k);
    sweep_capture_core_units_for_test(k, captured, round, limits);
    assert(!round.units.empty() && round.units.front().unit == internalize(-1));
    assert(sweep_emit_round_for_test(k, round, 0, limits) == ApplyResult::Ok);
    const uint64_t unit_id = k.unit_ids[var_of(internalize(-1))];
    assert(unit_id > 5 && k.value(internalize(-1)) > 0);
    const uint64_t empty_chain[2] = {unit_id, 5};
    proof.add_empty(++k.next_clause_id, empty_chain, 2);
    proof.flush();
  }
  printf("emitted the original-core-unit case to %s\n", dir);
}

// A chained emission batch whose middle winner is named by no later pair: the
// first pair's preserved bridge must carry the intermediate winner (the suffix
// image of its emitted binary), and the following canonical Substitute owns
// the complete retirement. The derived bridge images use mirror-lemma LRAT
// chains, which only an external checker validates.
static void emit_bridge_chain_case(const char *dir) {
  const std::vector<std::vector<int>> input = {
      {1, 5},  {2, 5},  {3, 6},  {4, 6},  // one occurrence per class member
      {-3, 4}, {3, -4},                    // pair x3 = x4
      {-3, 2}, {3, -2},                    // pair x3 = x2
      {-4, 1}, {4, -1},                    // pair x4 = x1
  };
  const uint64_t ID_P5 = 11, ID_NP5 = 12; // checker-only contradictory units

  char path[512];
  snprintf(path, sizeof path, "%s/bridge-chain.cnf", dir);
  FILE *cnf = fopen(path, "w");
  assert(cnf);
  fprintf(cnf, "p cnf 6 %u\n", static_cast<unsigned>(input.size()) + 2);
  for (const auto &c : input) {
    for (const int e : c)
      fprintf(cnf, "%d ", e);
    fprintf(cnf, "0\n");
  }
  fprintf(cnf, "5 0\n-5 0\n"); // checker-only clauses 11 and 12
  fclose(cnf);

  for (int fmt = 0; fmt < 2; fmt++) {
    const bool lrat = fmt == 1;
    snprintf(path, sizeof path, "%s/bridge-chain.%s", dir,
             lrat ? "lrat" : "drat");
    Proof proof;
    assert(proof.open(path, lrat ? ProofFormat::Lrat : ProofFormat::DratAscii));
    Kernel k;
    build(k, 6, input);
    k.next_clause_id = ID_NP5; // no lemma may reuse the checker-only ids
    k.proof = &proof;
    OccIndex occ;
    kernel_dense_connect(k, occ);
    SweepSubstitutionSession session;
    session.begin(k);
    const Lit one = internalize(1), two = internalize(2),
              three = internalize(3), four = internalize(4);
    assert(substitute_apply_sweep_equivalences(
               k, {{three, four}, {three, two}, {four, one}}, session) ==
           ApplyResult::Ok);
    assert(k.retired_events.empty());
    assert(substitute_apply(k) == ApplyResult::Ok);
    assert(kernel_var_retired(k, var_of(two)) &&
           kernel_var_retired(k, var_of(three)) &&
           kernel_var_retired(k, var_of(four)) &&
           "the bridge chain must let Substitute rediscover the whole class");
    (void)session.collect(k);
    kernel_dense_disconnect(k);

    const uint64_t empty_chain[2] = {ID_P5, ID_NP5};
    proof.add_empty(++k.next_clause_id, empty_chain, 2);
    proof.flush();
  }
  printf("emitted the bridge-chain case to %s\n", dir);
}

// A batch whose pair stream renames an absorbed literal maps both endpoints
// of an early bridge to intermediate members: {-6, 7} becomes {-4, 7} with
// neither x4 nor x7 the class root. Its LRAT chain needs both mirror lemmas,
// which only an external checker walks.
static void emit_bridge_two_hint_case(const char *dir) {
  const std::vector<std::vector<int>> input = {
      {3, 8},  {4, 8},  {6, 8},  {7, 8},  // one occurrence per class member
      {-6, 7}, {6, -7},                    // pair x6 = x7
      {-3, 4}, {3, -4},                    // pair x3 = x4
      {-4, 6}, {4, -6},                    // pair x4 = x6
  };
  const uint64_t ID_P8 = 11, ID_NP8 = 12; // checker-only contradictory units

  char path[512];
  snprintf(path, sizeof path, "%s/bridge-two-hint.cnf", dir);
  FILE *cnf = fopen(path, "w");
  assert(cnf);
  fprintf(cnf, "p cnf 8 %u\n", static_cast<unsigned>(input.size()) + 2);
  for (const auto &c : input) {
    for (const int e : c)
      fprintf(cnf, "%d ", e);
    fprintf(cnf, "0\n");
  }
  fprintf(cnf, "8 0\n-8 0\n"); // checker-only clauses 11 and 12
  fclose(cnf);

  for (int fmt = 0; fmt < 2; fmt++) {
    const bool lrat = fmt == 1;
    snprintf(path, sizeof path, "%s/bridge-two-hint.%s", dir,
             lrat ? "lrat" : "drat");
    Proof proof;
    assert(proof.open(path, lrat ? ProofFormat::Lrat : ProofFormat::DratAscii));
    Kernel k;
    build(k, 8, input);
    k.next_clause_id = ID_NP8; // no lemma may reuse the checker-only ids
    k.proof = &proof;
    OccIndex occ;
    kernel_dense_connect(k, occ);
    SweepSubstitutionSession session;
    session.begin(k);
    const Lit three = internalize(3), four = internalize(4),
              six = internalize(6), seven = internalize(7);
    assert(substitute_apply_sweep_equivalences(
               k, {{six, seven}, {three, four}, {four, six}}, session) ==
           ApplyResult::Ok);
    assert(k.retired_events.empty());
    assert(kernel_binary_live(k, negate(four), seven) &&
           kernel_binary_live(k, four, negate(seven)) &&
           "the early bridge must carry both intermediate members");
    assert(substitute_apply(k) == ApplyResult::Ok);
    assert(kernel_var_retired(k, var_of(four)) &&
           kernel_var_retired(k, var_of(six)) &&
           kernel_var_retired(k, var_of(seven)) &&
           !kernel_var_retired(k, var_of(three)));
    (void)session.collect(k);
    kernel_dense_disconnect(k);

    const uint64_t empty_chain[2] = {ID_P8, ID_NP8};
    proof.add_empty(++k.next_clause_id, empty_chain, 2);
    proof.flush();
  }
  printf("emitted the bridge two-hint case to %s\n", dir);
}

// All three variables remain active across Sweep's connected rewrite.
// Reusing a pre-rewrite endpoint in a later pair must preserve every original
// equivalence, even before the caller chooses to run Substitute.
static void test_sequential_equivalence_images() {
  uint64_t productive = 0;
  for (bool dense : {false, true})
    for (bool partition : {false, true})
      for (unsigned signs = 0; signs != 8; ++signs) {
        std::vector<Var> order{0, 1, 2};
        do {
          Kernel k;
          kernel_reserve_vars(k, 3);
          for (const Var v : order) kernel_record_import(k, v);
          const Lit a = make_lit(0, signs & 1);
          const Lit b = make_lit(1, signs & 2);
          const Lit c = make_lit(2, signs & 4);
          for (const auto &[x, y] :
               std::vector<std::pair<Lit, Lit>>{{a, negate(b)},
                                               {b, negate(c)},
                                               {c, negate(a)}})
            kernel_add_binary_clause(k, x, y, ++k.next_clause_id);
          OccIndex occ;
          if (dense) kernel_dense_connect(k, occ);
          SweepLimits lim;
          lim.full_partition = partition;
          // Repeating individual applications crosses fresh round/session
          // boundaries as well as the within-environment merge boundary.
          for (const Var seed : {2u, 1u, 0u, 2u}) {
            assert(sweep_try_with_limits(k, seed, lim) != ApplyResult::Unsat);
            std::vector<uint64_t> chain;
            for (const Lit x : {a, b, c})
              for (const Lit y : {a, b, c})
                if (x != y && !big_path_chain(k, x, y, chain)) {
                  fprintf(stderr, "bridge lost: dense=%d partition=%d signs=%u order=%u,%u,%u seed=%u from=%u to=%u\n", dense, partition, signs, order[0], order[1], order[2], seed, x, y);
                  assert(false && "Sweep must preserve the complete equivalence");
                }
            kernel_check_invariants(k);
          }
          productive += k.stats.sweep_binaries;
          if (dense) kernel_dense_disconnect(k);
        } while (std::next_permutation(order.begin(), order.end()));
      }
  assert(productive > 0);
}

int main(int argc, char **argv) {
  test_sequential_equivalence_images();
  if (argc > 2 && !strcmp(argv[1], "--emit")) {
    emit_se_case(argv[2]);
    emit_unit_case(argv[2]);
    emit_original_core_unit_case(argv[2]);
    emit_bridge_chain_case(argv[2]);
    emit_bridge_two_hint_case(argv[2]);
    return 0;
  }
  const uint32_t rounds =
      argc > 1 ? static_cast<uint32_t>(strtoul(argv[1], nullptr, 10)) : 20000;
  test_effort_prices_embedded_and_representation_ticks();
  test_core_prefixes_share_one_immutable_derivation();
  test_lrat_capture_replays_lifted_cube();
  test_lrat_core_prefix_uses_its_own_target_cube();
  test_unbounded_clause_limit_sizes_from_formula();
  test_dense_entry_flushes_only_irredundant_satisfied_clauses();
  test_non_rup_equivalence();
  test_unbounded_flip_rounds_observe_stop();
  test_proof_capture_limit_is_caller_controlled();
  test_seed_symmetry();
  test_full_partition_finds_nonseed_pair();
  test_known_equivalence_still_substitutes();
  test_environment_skips_nonrepresentative_bridges();
  test_equivalence_with_new_unit_forces_partner();
  test_original_core_unit_capture();
  test_env_provenance();
  test_equal_depth_binary_encounters();
  test_limits();
  test_known_equivalence();
  test_seeds();
  test_resumable_schedule();
  test_reschedules_pair_representative_by_import_order();
  test_reschedule_declines_a_retired_representative();
  test_resumable_closes_root_between_environments();
  test_env_unsat();
  test_sd_emits_rup_equivalence();
  test_sd_declines_non_rup();
  test_rup_admission_is_format_independent();
  test_rup_replay_closes_inherited_root_debt();
  test_se_general_path_emits();
  test_inline_bridge_refreshes_owned_occurrences();
  test_dense_call_collects_once_across_productive_environments();
  test_sessionless_substitution_keeps_binaries_whole();
  test_brute_force_oracle(rounds);
  printf("test_sweep: all tests passed\n");
  return 0;
}
