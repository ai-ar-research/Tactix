#undef NDEBUG
#include "frontend/parse.hpp"
#include "policies/heuristics.hpp"
#include "rules/registry.hpp"
#include <algorithm>
#include <cassert>
#include <cstdio>
#include <cstring>
#include <memory>
#include <vector>
using namespace tactix;

int main(int argc, char **argv) {
  const bool old = argc == 2 && !std::strcmp(argv[1], "--expect-old-missing");
  assert(argc == 1 || old);
  unsigned cases = 0, observed = 0, missing = 0;
  for (bool reverse : {false, true})
    for (unsigned declared : {6u, 9u})
      for (bool attached : {false, true})
        for (bool stable : {false, true}) {
          Kernel k;
          std::unique_ptr<ScopedHeuristics> owner;
          if (attached) {
            owner = std::make_unique<ScopedHeuristics>(k);
            owner->h.stable = stable;
          }
          FILE *in = std::tmpfile(); assert(in);
          std::fprintf(in, "p cnf %u 3\n", declared);
          for (unsigned i = 0; i < 6; ++i)
            std::fprintf(in, "%u ", reverse ? 6-i : i+1);
          std::fputs("0\n2 0\n-4 0\n", in); std::rewind(in);
          assert(!parse_dimacs(in, k)); std::fclose(in);
          if (!attached) owner = std::make_unique<ScopedHeuristics>(k);
          owner->h.stable = stable;
          heuristics_deactivate_inactive_vars(k);
          const unsigned ext = reverse ? 4 : 2;
          const unsigned expected = reverse ? 3 : 2;
          for (unsigned stage = 0; stage != 4; ++stage) {
            if (stage) {
              assert(kernel_compact_variables(k));
              heuristics_compact_random_order_fixed(k);
            }
            const Var v = var_of(kernel_internalize(k, ext));
            ++observed; missing += owner->h.links[v].stamp != expected;
            assert(!heuristics_var_active(k, v));
            assert(k.value(kernel_internalize(k, 2)) == 1);
            assert(k.value(kernel_internalize(k, -4)) == 1);
            if (!old) assert(owner->h.queue_stamp == (stage ? 4u : 6u));
            if (owner->h.search_idx != INVALID_VAR)
              assert(owner->h.search_stamp == owner->h.links[owner->h.search_idx].stamp);
            std::vector<int> queue;
            for (Var q = owner->h.queue_first; q != INVALID_VAR; q = owner->h.links[q].next)
              queue.push_back(kernel_externalize(k, make_lit(q, false)));
            assert(queue == (reverse ? std::vector<int>{6,5,3,1} : std::vector<int>{1,3,5,6}));
            // Numeric policy metadata cannot hide either phase, including
            // header-only identities, from M2's public action surface.
            for (const RuleVTable &rule : tactix_rules()) {
              if (std::strcmp(rule.name, "Decide")) continue;
              uint64_t actions[32];
              const unsigned n = rule.instances(k, actions, 32);
              unsigned expected_actions = 0;
              for (Var q = 0; q < k.nvars; ++q) {
                if (k.values[make_lit(q, false)]) continue;
                for (bool negative : {false, true}) {
                  ++expected_actions;
                  assert(std::find(actions, actions+n, lit_instance(k, make_lit(q, negative))) != actions+n);
                }
              }
              assert(n == expected_actions);
            }
            kernel_check_invariants(k);
          }
          ++cases;
        }
  Kernel bare;
  heuristics_seed_activation_order(bare, {});
  assert(!bare.h);
  std::printf("activation-stamp cases=%u observations=%u missing=%u\n", cases, observed, missing);
  assert(cases == 16 && observed == 64);
  return old ? missing != observed : missing != 0;
}
