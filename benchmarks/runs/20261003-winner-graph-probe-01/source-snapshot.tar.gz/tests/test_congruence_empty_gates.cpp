// Binary equivalences must reach dense cleanup even without extracted gates.
#undef NDEBUG
#include "kernel/kernel.hpp"
#include "rules/congruence/congruence.hpp"
#include "rules/registry.hpp"
#include <cassert>
#include <cstdio>
#include <cstring>
#include <unistd.h>
using namespace tactix;

int main(int argc, char **argv) {
  const bool parent = argc == 2 && !std::strcmp(argv[1], "--expect-parent");
  assert(argc == 1 || parent);
  unsigned cases = 0, mismatches = 0;
  for (bool merge : {false, true})
    for (bool entry_unit : {false, true})
      for (unsigned copies : {1u, 2u})
        for (bool reverse_import : {false, true})
          for (bool public_instance : {false, true})
            for (ProofFormat format : {ProofFormat::DratAscii, ProofFormat::Lrat}) {
              Kernel k;
              kernel_reserve_vars(k, 4);
              for (unsigned i = 0; i < 4; i++)
                kernel_record_import(k, reverse_import ? 3 - i : i);
              const Lit u = internalize(1), x = internalize(2);
              const Lit a = internalize(3), b = internalize(4);
              for (unsigned i = 0; i < copies; i++) {
                kernel_add_binary_clause(k, u, x, ++k.next_clause_id);
                kernel_add_binary_clause(k, u, negate(x), ++k.next_clause_id);
                if (merge) {
                  kernel_add_binary_clause(k, negate(a), b, ++k.next_clause_id);
                  kernel_add_binary_clause(k, a, negate(b), ++k.next_clause_id);
                }
              }
              if (entry_unit) {
                k.unit_ids[var_of(u)] = ++k.next_clause_id;
                kernel_assign_unit(k, u);
                assert(!kernel_propagate(k));
              }
              std::vector<CongGate> gates;
              congruence_extract_gates(k, gates, true);
              assert(gates.empty());
              k.level = 1;
              assert(!congruence_guard(k));
              k.level = 0;
              assert(congruence_guard(k));
              const int id = tactix_rule_id("Congruence");
              assert(id >= 0);
              const auto &rule = tactix_rules()[id];
              uint64_t instance = 0;
              assert(rule.instances(k, &instance, 1) == 1);
              char path[] = "/tmp/tactix-congruence-empty-XXXXXX";
              const int fd = mkstemp(path);
              assert(fd >= 0);
              close(fd);
              {
                Proof proof;
                assert(proof.open(path, format));
                proof.bind_variable_map(&k.internal_to_external);
                k.proof = &proof;
                const ApplyResult result = public_instance
                    ? rule.apply_instance(k, instance) : congruence_apply(k);
                assert(result == (merge || !entry_unit ? ApplyResult::Ok : ApplyResult::NoOp));
                proof.flush();
                k.proof = nullptr;
              }
              assert(!std::remove(path));
              assert(!k.inconsistent && !k.stats.congruence_unjustified);
              assert(k.stats.congruence_gates == 0);
              assert(k.stats.congruence_merges == static_cast<unsigned>(merge));
              assert(k.nvars == 4 && k.value(u) > 0);
              // No variables retire: both original models a=b=false/true
              // remain models; no reconstruction witness is needed here.
              assert(!kernel_var_retired(k, var_of(a)) && !kernel_var_retired(k, var_of(b)));
              const unsigned unit_copies = merge || entry_unit ? 0 : 1;
              const bool clean = kernel_binary_copies(k, u, x) == unit_copies &&
                  kernel_binary_copies(k, u, negate(x)) == unit_copies &&
                  (!merge || (kernel_binary_copies(k, negate(a), b) == 1 &&
                              kernel_binary_copies(k, a, negate(b)) == 1));
              mismatches += !clean;
              cases++;
            }
  assert(cases == 64);
  if (parent) {
    assert(mismatches == 32);
    std::puts("PASS: frozen parent exposes32 binary-only cleanup failures;32 controls pass");
  } else {
    assert(mismatches == 0);
    std::puts("PASS:64 binary-only Congruence cases, public/direct, proof modes, copies, import order and lazy-unit controls");
  }
}
