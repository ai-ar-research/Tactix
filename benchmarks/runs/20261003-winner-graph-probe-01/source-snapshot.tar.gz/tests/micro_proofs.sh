#!/usr/bin/env bash
# Micro-formula proof tests (N2): tiny UNSAT formulas through the real binary;
# canonical DSR accepted by dsr-trim and pinned Trestle in binary and ASCII,
# with explicit DRAT/native-LRAT compatibility coverage. Exit 77 (ctest SKIP)
# without the canonical checker pipeline.
set -euo pipefail
TACTIX="$1"
ROOT="$2"
DRAT_TRIM="${DRAT_TRIM:-$ROOT/tools/checkers/bin/drat-trim}"
LRAT_CHECK="${LRAT_CHECK:-$ROOT/tools/checkers/bin/lrat-check}"
CAKE_LPR="${CAKE_LPR:-$ROOT/tools/checkers/bin/cake_lpr}"
DSR_TRIM="${DSR_TRIM:-$ROOT/tools/checkers/bin/dsr-trim}"
SR_CHECK="${SR_CHECK:-$ROOT/tools/checkers/bin/srcheck}"
DSR_COMPRESS="${DSR_COMPRESS:-$ROOT/tools/checkers/bin/dsr-compress}"
ANALYZE_TEST="${3:-}"
CONGRUENCE_TEST="${4:-}"
RESTART_TEST="${5:-}"
FACTOR_N1_TEST="${6:-}"
ONLINE_INPROCESS_TEST="${7:-}"
for checker in "$DSR_TRIM" "$SR_CHECK"; do
  [ -x "$checker" ] \
    || { echo "native DSR checker pipeline not built — skipping"; exit 77; }
done

T="$(mktemp -d)"
trap 'rm -rf "$T"' EXIT

check_dsr() {
  # tools/bench/proof_oracle.py owns the reference DSR checking pipeline and
  # the forward audit that checks every line of these small proofs.
  local cnf="$1" proof="$2"
  python3 "${TACTIX_PROOF_ORACLE_DIR:-$ROOT/tools/bench}/proof_oracle.py" \
    check-dsr "$cnf" "$proof" --dsr-trim "$DSR_TRIM" \
    --dsr-compress "$DSR_COMPRESS" --srcheck "$SR_CHECK" --every-lemma \
    > "$T/dsr-check.out" 2>&1 \
    || { echo "FAIL: reference DSR pipeline rejected $proof"; \
         cat "$T/dsr-check.out"; return 1; }
}

make_cases() {
  # contradictory units
  printf 'p cnf 1 2\n1 0\n-1 0\n' > "$T/units.cnf"
  # classic 2-var full enumeration
  printf 'p cnf 2 4\n1 2 0\n1 -2 0\n-1 2 0\n-1 -2 0\n' > "$T/enum2.cnf"
  # A large irrelevant root trail plus a two-variable contradiction exercises
  # sparse dependency elaboration: the empty-clause chain uses only the final
  # two variables even though the checker has recorded all preceding units.
  python3 - "$T/sparse-dependencies.cnf" <<'EOF'
import sys

units = 64
with open(sys.argv[1], "w") as output:
    output.write(f"p cnf {units + 2} {units + 4}\n")
    for variable in range(1, units + 1):
        output.write(f"{variable} 0\n")
    left, right = units + 1, units + 2
    output.write(f"{left} {right} 0\n")
    output.write(f"{left} -{right} 0\n")
    output.write(f"-{left} {right} 0\n")
    output.write(f"-{left} -{right} 0\n")
EOF
  # pigeonhole PHP(3): 4 pigeons, 3 holes
  python3 - "$T/php3.cnf" <<'EOF'
import sys
holes, pigeons = 3, 4
var = lambda p, h: p * holes + h + 1
cls = [[var(p, h) for h in range(holes)] for p in range(pigeons)]
for h in range(holes):
    for p1 in range(pigeons):
        for p2 in range(p1 + 1, pigeons):
            cls.append([-var(p1, h), -var(p2, h)])
with open(sys.argv[1], "w") as f:
    f.write(f"p cnf {pigeons * holes} {len(cls)}\n")
    for c in cls:
        f.write(" ".join(map(str, c)) + " 0\n")
EOF
  # empty clause in input
  printf 'p cnf 2 2\n1 2 0\n0\n' > "$T/empty.cnf"
  # Input normalization: a repeated literal makes the stored clause differ from
  # the one the checker reads at that file position, so every chain citing its
  # id needs a restatement lemma first (frontend/parse.cpp finish_input). One
  # case per stored width; each has its own re-pointing target.
  printf 'p cnf 3 4\n-1 -1 0\n-1 2 3 0\n-2 0\n1 1 0\n' > "$T/dupunit.cnf"
  printf 'p cnf 5 6\n5 1 0\n-5 4 0\n5 -1 0\n-4 3 3 0\n-2 0\n-4 -3 0\n' \
    > "$T/dupbinary.cnf"
  printf 'p cnf 4 8\n1 1 2 3 0\n-2 0\n-3 0\n-1 4 0\n-1 -4 0\n2 3 4 0\n-4 2 0\n-4 3 0\n' \
    > "$T/duplarge.cnf"
  # A prior root unit shrinks a later input binary to a unit. The stored unit
  # needs a deferred lemma with both the prior unit and file clause as hints;
  # the following opposite unit then cites that restated id in the empty proof.
  printf 'p cnf 2 3\n1 0\n-1 2 0\n-2 0\n' > "$T/rootshrink.cnf"
  # A unit implication cascade is closed while DRAT input is still being read.
  # Its derived x3 shrinks a later ternary to binary, and the following units
  # refute during ingestion.  This exercises derived-root normalization without
  # LRAT ids; the proof replay deliberately keeps the deferred-input path,
  # while the live solver uses the same eager import as proofless solving.
  printf 'p cnf 5 6\n-1 2 0\n-2 3 0\n1 0\n-3 4 5 0\n-4 0\n-5 0\n' \
    > "$T/rootcascade.cnf"
  # The unit 1 forces 2 before the third clause is read; that satisfied
  # clause must not enter the live solver merely because LRAT is requested.
  # The independent 3/4 core makes the original-CNF proof nontrivial.
  printf 'p cnf 4 7\n-1 2 0\n1 0\n2 3 0\n3 4 0\n3 -4 0\n-3 4 0\n-3 -4 0\n' \
    > "$T/root-satisfied-lrat.cnf"
  # A later SR witness can fail if the checker retains the raw input clause
  # after pure elimination deletes its normalized replacement. Claude's two
  # minimized regressions cover root shortening and repeated literals.
  cat > "$T/sr-input-root.cnf" <<'EOF'
p cnf 9 10
-5 -6 0
-6 5 0
-6 7 0
-7 -5 0
-2 0
-7 5 0
-3 4 2 0
3 -1 0
9 8 0
6 7 0
EOF
  cat > "$T/sr-input-repeat.cnf" <<'EOF'
p cnf 16 15
11 0
5 0
-10 0
7 0
9 8 0
-8 9 0
-14 16 -14 0
-9 -13 0
-12 0
14 15 0
3 0
-2 0
-9 13 0
6 0
4 5 -1 0
EOF
  # Binary deduplication must retire every discarded physical input copy.
  sed 's/p cnf 9 10/p cnf 9 11/; /3 -1 0/a 3 -1 0' \
    "$T/sr-input-root.cnf" > "$T/sr-input-duplicate.cnf"
  # This discarded input duplicate itself shortens to the stored binary.
  sed 's/p cnf 9 10/p cnf 9 11/; /-3 4 2 0/a -3 4 2 0' \
    "$T/sr-input-root.cnf" > "$T/sr-input-normalized-duplicate.cnf"
  # Retained satisfied and tautological input clauses remain SR-safe.
  sed 's/p cnf 9 10/p cnf 9 12/; /-2 0/a -2 3 4 0\n3 -3 4 0' \
    "$T/sr-input-root.cnf" > "$T/sr-input-inert-raw.cnf"
  # Startup sparse collection: the large clause precedes the binary implication
  # that fixes x1, so input normalization cannot shorten it. Initial propagation
  # derives x1; the collector then rewrites the large clause to binary (5 6).
  printf 'p cnf 6 7\n-1 5 6 0\n-2 1 0\n2 0\n3 4 0\n3 -4 0\n-3 4 0\n-3 -4 0\n' \
    > "$T/sparsecollect.cnf"
  # a refutation found DURING input, with input clauses still to come: the
  # derived empty clause must not take an id the checker gave to clause 3 or 4
  printf 'p cnf 2 4\n1 0\n-1 0\n2 0\n-2 0\n' > "$T/midrefute.cnf"
  # cyclic xor chain, odd total parity: 1^2=1, 2^3=1, 1^3=1 sums to 0=1
  printf 'p cnf 3 6\n1 2 0\n-1 -2 0\n2 3 0\n-2 -3 0\n1 3 0\n-1 -3 0\n' \
    > "$T/xor3.cnf"
  # TransitiveReduce failed-source unit: assuming -1 reaches both 4 and -4.
  # The independent full enumeration on 5,6 keeps the whole formula UNSAT so
  # an external checker can replay the new unit chain and the search tail.
  printf 'p cnf 6 8\n1 2 0\n1 3 0\n-2 4 0\n-2 -4 0\n5 6 0\n5 -6 0\n-5 6 0\n-5 -6 0\n' \
    > "$T/transitive-failed.cnf"
  # Exact d=3,n=3 output of the StConn owner generator. Native DSR/DRAT use
  # Lucky15's crossing-sequence RUP refutation; LRAT safely falls back to CDCL.
  cat > "$T/stconn-3x3.cnf" <<'EOF'
p cnf 16 68
-15 -12 0
15 12 0
-10 15 0
10 -15 0
-7 2 0
7 -2 0
-4 -7 0
4 7 0
-16 12 0
16 -12 0
-5 1 0
5 -1 0
-11 -16 -10 0
-13 11 16 10 0
-13 -16 -10 0
13 -11 16 10 0
-13 -11 -10 0
13 11 -16 10 0
-13 -11 -16 0
13 11 16 -10 0
-3 -5 -2 0
-8 3 5 2 0
-8 -5 -2 0
8 -3 5 2 0
-8 -3 -2 0
8 3 -5 2 0
-8 -3 -5 0
8 3 5 -2 0
-9 13 0
9 -13 0
-8 4 0
8 -4 0
6 1 0
-6 -1 0
-14 11 0
14 -11 0
-6 3 0
6 -3 0
-14 -9 0
14 9 0
-10 -2 0
-10 -7 0
-15 -7 0
-15 -2 0
-16 -5 0
-16 -1 0
-12 -5 0
-12 -1 0
-13 -8 0
-11 -3 0
-13 -3 0
-13 -5 0
-13 -2 0
-11 -8 0
-11 -5 0
-11 -2 0
-16 -8 0
-16 -3 0
-16 -2 0
-10 -8 0
-10 -3 0
-10 -5 0
-9 -8 0
-9 -4 0
-13 -4 0
-14 -6 0
-14 -3 0
-11 -6 0
EOF
  # Two complete signed ternary cardinality groups require at least three
  # falsified literals in each of x1..x5 and -x1..-x5. Their lower bounds sum
  # to six although only five variables exist. Lucky16 emits the native BDD
  # cutting-planes refutation for this contradiction.
  python3 - "$T/signed-cardinality.cnf" <<'EOF'
import itertools
import sys

clauses = []
for group in (range(1, 6), range(-1, -6, -1)):
    clauses.extend(itertools.combinations(group, 3))
with open(sys.argv[1], "w") as output:
    output.write(f"p cnf 5 {len(clauses)}\n")
    for clause in clauses:
        output.write(" ".join(map(str, clause)) + " 0\n")
EOF
}

make_cases
for cnf in "$T"/*.cnf; do
  for mode in binary ascii; do
    proof="$cnf.$mode.dsr"
    if [ "$mode" = binary ]; then
      "$TACTIX" -q --dsr "$cnf" "$proof" > "$T/out" && rc=$? || rc=$?
    else
      "$TACTIX" -q --dsr --no-binary "$cnf" "$proof" > "$T/out" && rc=$? || rc=$?
    fi
    [ "$rc" -eq 20 ] || { echo "FAIL: $cnf not UNSAT (rc=$rc)"; exit 1; }
    grep -q '^s UNSATISFIABLE$' "$T/out" \
      || { echo "FAIL: $cnf missing s line"; exit 1; }
    check_dsr "$cnf" "$proof"
  done
  # The historical proof vocabulary remains available explicitly in both
  # DRAT encodings. It is a compatibility surface, not the default.
  if [ -x "$DRAT_TRIM" ]; then
    for mode in binary ascii; do
      proof="$cnf.$mode.drat"
      if [ "$mode" = binary ]; then
        "$TACTIX" -q --drat "$cnf" "$proof" > "$T/out" && rc=$? || rc=$?
      else
        "$TACTIX" -q --drat --no-binary "$cnf" "$proof" \
          > "$T/out" && rc=$? || rc=$?
      fi
      [ "$rc" -eq 20 ] || { echo "FAIL: $cnf not UNSAT under DRAT (rc=$rc)"; exit 1; }
      "$DRAT_TRIM" "$cnf" "$proof" > "$T/check" 2>&1 || true
      grep -q 's VERIFIED' "$T/check" \
        || { echo "FAIL: DRAT proof of $cnf ($mode) rejected"; cat "$T/check"; exit 1; }
    done
  fi
  # native LRAT (plan O4): hints emitted by the solver, no conversion
  if [ -x "$LRAT_CHECK" ]; then
    proof="$cnf.lrat"
    "$TACTIX" -q --lrat "$cnf" "$proof" > "$T/out" && rc=$? || rc=$?
    [ "$rc" -eq 20 ] || { echo "FAIL: $cnf not UNSAT under --lrat"; exit 1; }
    "$LRAT_CHECK" "$cnf" "$proof" > "$T/check" 2>&1 \
      || { echo "FAIL: native LRAT of $cnf rejected"; cat "$T/check"; exit 1; }
    grep -q 'c VERIFIED' "$T/check" \
      || { echo "FAIL: lrat-check gave no verdict on $cnf"; cat "$T/check"; exit 1; }
    if [ "$cnf" = "$T/root-satisfied-lrat.cnf" ] && [ -x "$CAKE_LPR" ]; then
      CML_HEAP_SIZE=24576 "$CAKE_LPR" "$cnf" "$proof" \
        > "$T/check-cake" 2>&1 \
        || { echo "FAIL: cake_lpr rejected eager-import LRAT"; \
             cat "$T/check-cake"; exit 1; }
      grep -Eq '^s VERIFIED[[:space:]]+UNSAT$' "$T/check-cake" \
        || { echo "FAIL: cake_lpr gave no eager-import verdict"; \
             cat "$T/check-cake"; exit 1; }
      : > "$T/root-satisfied-empty.lrat"
      CML_HEAP_SIZE=24576 "$CAKE_LPR" "$cnf" \
        "$T/root-satisfied-empty.lrat" > "$T/check-cake-bad" 2>&1 || true
      if grep -Eq '^s VERIFIED[[:space:]]+UNSAT$' "$T/check-cake-bad"; then
        echo "FAIL: cake_lpr accepted empty eager-import control"
        cat "$T/check-cake-bad"
        exit 1
      fi
    fi
  fi
done

# Negative control for the reference checker semantics.  A DRAT/DSR checker
# keeps a clause that is the reason of an implied unit even when the proof
# deletes it, so here -55 stays implied by -5 and (-55 v 5), and the later
# witnessed unit 55 is not a valid addition.  The reference pipeline must reject
# this shape; Tactix therefore never deletes a reason the solver does not itself
# hold as a root unit.  The independent UNSAT tail makes the fixture complete.
python3 - "$T/implied-unit-delete.cnf" <<'EOF'
import sys

clauses = [[variable] for variable in range(1, 40) if variable != 5]
clauses.append([40])
clauses.extend(([-5], [-55, 5], [56, 57], [56, -57],
                [-56, 57], [-56, -57]))
with open(sys.argv[1], "w") as output:
    output.write(f"p cnf 57 {len(clauses)}\n")
    for clause in clauses:
        output.write(" ".join(map(str, clause)) + " 0\n")
EOF
cat > "$T/implied-unit-delete.dsr" <<'EOF'
d -55 5 0
55 55 0
56 0
0
EOF
if check_dsr "$T/implied-unit-delete.cnf" "$T/implied-unit-delete.dsr" \
    > /dev/null 2>&1; then
  echo "FAIL: reference pipeline accepted a deleted implied-unit reason"
  exit 1
fi

# Prove that the checked signed-cardinality certificate above actually came
# from Lucky16.  The ordinary all-formats loop establishes native DSR/DRAT/LRAT
# compatibility; this explicit run adds reachability and a negative oracle
# control for the new proof-producing path.
cnf="$T/signed-cardinality.cnf"
proof="$T/signed-cardinality-reach.dsr"
"$TACTIX" --no-binary "$cnf" "$proof" > "$T/signed-cardinality.out" \
  && rc=$? || rc=$?
[ "$rc" -eq 20 ] \
  || { echo "FAIL: signed-cardinality fixture not UNSAT (rc=$rc)"; exit 1; }
grep -Eq '^c signedcard 1 calls, 1 recognized, 2 groups, [1-9][0-9]* BDD nodes, [1-9][0-9]* proof additions, 0 budget stops, 1 UNSAT, 0 interrupted$' \
  "$T/signed-cardinality.out" \
  || { echo "FAIL: Lucky16 did not produce the signed-cardinality proof"; \
       cat "$T/signed-cardinality.out"; exit 1; }
check_dsr "$cnf" "$proof"

lines=$(wc -l < "$proof")
head -n "$((lines / 2))" "$proof" > "$T/signed-cardinality-incomplete.dsr"
if check_dsr "$cnf" "$T/signed-cardinality-incomplete.dsr" > /dev/null 2>&1; then
  echo "FAIL: reference pipeline accepted the incomplete signed-cardinality proof"
  exit 1
fi

# Direct substitution witness: a two-row permutation adds unit -1 to the
# symmetric component. The independent no-UP refutation tail ends the proof.
# Forward checking forces dsr-trim to validate the SR line even though a
# backward trimmer could discard it as irrelevant to the final empty clause.
cat > "$T/direct-sr.cnf" <<'EOF'
p cnf 6 8
1 2 0
3 4 0
-1 -3 0
-2 -4 0
5 6 0
5 -6 0
-5 6 0
-5 -6 0
EOF
cat > "$T/direct-sr.dsr" <<'EOF'
-1 -1 3 -1 2 4 4 2 0
5 0
0
EOF
check_dsr "$T/direct-sr.cnf" "$T/direct-sr.dsr"

# Exercise the solver's typed SR application and native DSR writer together.
# The emitted certificate must contain an effective orbitopal transition and
# survive forward elaboration, which prevents backward trimming from hiding a
# malformed or ineffective SR line.
if [ -n "$ONLINE_INPROCESS_TEST" ]; then
  proof="$T/orbitopal-sr.dsr"
  "$ONLINE_INPROCESS_TEST" "$T/direct-sr.cnf" "$proof" dsr OrbitopalSR \
    > "$T/orbitopal-sr.out" && rc=$? || rc=$?
  [ "$rc" -eq 20 ] \
    || { echo "FAIL: orbitopal SR fixture not UNSAT (rc=$rc)"; \
         cat "$T/orbitopal-sr.out"; exit 1; }
  grep -Eq '^c effective structured SR transitions [1-9][0-9]*$' \
    "$T/orbitopal-sr.out" \
    || { echo "FAIL: orbitopal SR fixture made no effective transition"; \
         cat "$T/orbitopal-sr.out"; exit 1; }
  check_dsr "$T/direct-sr.cnf" "$proof"

  # A three-literal orbit requires two binary SST cuts before its representative
  # unit becomes RUP. Keep the independent two-variable contradiction only to
  # finish the certificate; forward elaboration validates every generated X7
  # tuple in the incremental chain.
  cat > "$T/sst-chain.cnf" <<'EOF'
p cnf 6 9
1 2 3 0
4 5 6 0
4 5 -6 0
4 -5 6 0
4 -5 -6 0
-4 5 6 0
-4 5 -6 0
-4 -5 6 0
-4 -5 -6 0
EOF
  proof="$T/sst-chain.dsr"
  "$ONLINE_INPROCESS_TEST" "$T/sst-chain.cnf" "$proof" dsr SstSR \
    > "$T/sst-chain.out" && rc=$? || rc=$?
  [ "$rc" -eq 20 ] \
    || { echo "FAIL: SST-chain fixture not UNSAT (rc=$rc)"; \
         cat "$T/sst-chain.out"; exit 1; }
  grep -Eq '^c effective structured SR transitions [3-9][0-9]*$|^c effective structured SR transitions [3-9]$' \
    "$T/sst-chain.out" \
    || { echo "FAIL: SST-chain fixture did not apply the complete level"; \
         cat "$T/sst-chain.out"; exit 1; }
  check_dsr "$T/sst-chain.cnf" "$proof"

  # No clause in the first four-clause component lies within its nontrivial
  # literal orbits. The two-pass producer must therefore reach a full orbit
  # cut. The fixed asymmetric UNSAT tail lets the ordinary search finish while
  # forward elaboration and Trestle validate every preceding cut tuple.
  cat > "$T/fix-and-cut.cnf" <<'EOF'
p cnf 11 39
1 3 0
2 4 0
-3 5 0
-4 6 0
7 8 9 0
-9 -10 11 0
-7 9 -11 0
-7 -9 10 0
-7 -10 11 0
7 -10 11 0
-8 10 11 0
8 10 -11 0
7 -8 -11 0
-8 -9 11 0
-8 9 10 0
7 9 -11 0
9 -10 11 0
7 -8 -9 0
7 8 -10 0
7 -10 -11 0
-7 9 -10 0
-7 -8 10 0
-8 9 -11 0
-9 10 11 0
7 -9 10 0
8 -9 11 0
-9 10 -11 0
-7 8 -10 0
-7 -9 -11 0
-7 8 -11 0
-8 9 -10 0
7 10 -11 0
8 9 -11 0
-9 -10 -11 0
-8 -9 -11 0
-7 -10 -11 0
8 9 -10 0
-7 8 -9 0
-7 8 9 0
EOF
  proof="$T/fix-and-cut.dsr"
  "$ONLINE_INPROCESS_TEST" "$T/fix-and-cut.cnf" "$proof" dsr FixAndCutSR all \
    > "$T/fix-and-cut.out" && rc=$? || rc=$?
  [ "$rc" -eq 20 ] \
    || { echo "FAIL: fix-and-cut fixture not UNSAT (rc=$rc)"; \
         cat "$T/fix-and-cut.out"; exit 1; }
  grep -Eq '^c effective structured SR transitions [1-9][0-9]*$' \
    "$T/fix-and-cut.out" \
    || { echo "FAIL: fix-and-cut fixture made no effective transition"; \
         cat "$T/fix-and-cut.out"; exit 1; }
  awk 'NR == 1 { if ($1 >= 0 || $2 <= 0 || NF <= 4) exit 1 }' "$proof" \
    || { echo "FAIL: first generated proof action was not an orbit cut"; \
         head -n 1 "$proof"; exit 1; }
  check_dsr "$T/fix-and-cut.cnf" "$proof"
fi

# An invalid witnessed step must be rejected even though the reference pipeline
# checks backward, where a lemma the refutation does not use is never examined.
# Here the refutation hangs on the witnessed unit 1: it forces 2, and (-2 v 3),
# (-2 v -3) close.  The unit is not a valid addition, because its candidate
# (-1 v 2) reduces to (2) and F & -1 & -2 has no unit propagation at all.
# Backward dsr-trim alone reports VERIFIED on this proof; Trestle, the verified
# checker and the pipeline's authority, rejects the elaborated LSR.
printf 'p cnf 5 7\n-1 2 0\n-2 3 0\n-2 -3 0\n1 4 5 0\n1 4 -5 0\n1 -4 5 0\n1 -4 -5 0\n' \
  > "$T/needed-bad-witness.cnf"
printf '1 1 0\n0\n' > "$T/needed-bad-witness.dsr"
if check_dsr "$T/needed-bad-witness.cnf" "$T/needed-bad-witness.dsr" \
    > /dev/null 2>&1; then
  echo "FAIL: reference pipeline accepted an invalid witnessed unit"
  cat "$T/dsr-check.out"
  exit 1
fi
printf -- '-2 0\n-1 0\n4 0\n0\n' > "$T/needed-bad-witness-honest.dsr"
check_dsr "$T/needed-bad-witness.cnf" "$T/needed-bad-witness-honest.dsr"

# The same defect rejects a VALID witnessed unit whose propagation closes the
# refutation: backward dsr-trim attributes the final derivation to the
# witnessed line and omits the hint groups of the clauses it used, so Trestle
# rejects the elaborated LSR.  Here unit 1 (witness 1) is valid and not RUP:
# its candidates (-1 v 4) and (-1 v 5) reduce to (4) and (5), both implied
# under -1, while F & -1 alone has no conflict by propagation.  The plain line
# is the form Tactix must not write; the general encoding (vacuous RAT on a
# fresh auxiliary, the witnessed nonunit, then the unit by RUP) verifies.  The
# plain-line expectation pins frozen checker behaviour and is what to revisit
# if the dsr-trim pin ever changes.
printf 'p cnf 8 13\n1 2 0\n1 3 0\n-2 -3 4 0\n-1 4 0\n-1 5 0\n-5 -4 6 0\n-5 -6 0\n1 5 7 0\n1 5 -7 0\n1 7 8 0\n1 7 -8 0\n1 -7 8 0\n1 -7 -8 0\n' \
  > "$T/closing-witness.cnf"
printf '1 1 0\n0\n' > "$T/closing-witness-plain.dsr"
if check_dsr "$T/closing-witness.cnf" "$T/closing-witness-plain.dsr" \
    > /dev/null 2>&1; then
  echo "NOTE: the reference pipeline now accepts a closing witnessed unit;"
  echo "      the general encoding for propagating SR clauses can be retired"
  exit 1
fi
printf -- '-9 1 0\n9 1 9 1 0\n1 0\nd 9 1 0\nd -9 1 0\n0\n' \
  > "$T/closing-witness-general.dsr"
check_dsr "$T/closing-witness.cnf" "$T/closing-witness-general.dsr"
# In that encoding the invalid unit above is refused by dsr-trim itself.
printf -- '-6 1 0\n6 1 6 1 0\n1 0\nd 6 1 0\nd -6 1 0\n0\n' \
  > "$T/needed-bad-witness-general.dsr"
if check_dsr "$T/needed-bad-witness.cnf" "$T/needed-bad-witness-general.dsr" \
    > /dev/null 2>&1; then
  echo "FAIL: reference pipeline accepted an invalid witnessed unit (general encoding)"
  exit 1
fi

# Keep the verified endpoint live as an oracle too: an incomplete final hint
# chain must not be accepted by Trestle.
cat > "$T/direct-sr-bad.lsr" <<'EOF'
9 -1 -1 3 2 -4 0 0
10 5 0 5 6 0
11 0 10 7 0
EOF
"$SR_CHECK" "$T/direct-sr.cnf" "$T/direct-sr-bad.lsr" \
  > "$T/direct-sr-bad-check.out" 2>&1 || true
grep -Eq '^s INVALID$' "$T/direct-sr-bad-check.out" \
  || { echo "FAIL: Trestle gave no rejection for the invalid LSR control"; \
       cat "$T/direct-sr-bad-check.out"; exit 1; }
if grep -Eq '^s VERIFIED[[:space:]]+UNSAT$' "$T/direct-sr-bad-check.out"; then
  echo "FAIL: Trestle reported VERIFIED for the invalid LSR control"
  cat "$T/direct-sr-bad-check.out"
  exit 1
fi

# Drive the failed-source rule path directly and require that the independently
# checked proof actually contains a TransitiveReduce unit, rather than passing
# only because the independent UNSAT component was solved without the rule.
if [ -x "$LRAT_CHECK" ]; then
  cnf="$T/transitive-failed.cnf"
  proof="$cnf.transitive.lrat"
  TACTIX_STRESS_RULES=TransitiveReduce TACTIX_V4_EARLY_EXIT=0 \
    "$TACTIX" --stress-policy --lrat "$cnf" "$proof" > "$T/out" \
    && rc=$? || rc=$?
  [ "$rc" -eq 20 ] \
    || { echo "FAIL: transitive failed-source fixture not UNSAT (rc=$rc)"; exit 1; }
  grep -Eq '^c transitive  .* [1-9][0-9]* units,' "$T/out" \
    || { echo "FAIL: transitive failed-source fixture emitted no unit"; cat "$T/out"; exit 1; }
  "$LRAT_CHECK" "$cnf" "$proof" > "$T/check" 2>&1 \
    || { echo "FAIL: native LRAT of transitive failed-source unit rejected"; \
         cat "$T/check"; exit 1; }
  grep -q 'c VERIFIED' "$T/check" \
    || { echo "FAIL: lrat-check gave no transitive-unit verdict"; \
         cat "$T/check"; exit 1; }
fi

# Analyze's level-one failed-literal path can emit more than one root unit from
# one conflict.  Drive the exact rule transition in the analysis fixture, then
# check the complete native LRAT proof against the matching original CNF.
if [ -n "$ANALYZE_TEST" ] && [ -x "$LRAT_CHECK" ]; then
  cnf="$T/failed-level-one.cnf"
  printf 'p cnf 5 6\n-1 2 0\n-2 3 0\n-2 4 0\n-3 -4 0\n1 5 0\n1 -5 0\n' \
    > "$cnf"
  proof="$cnf.lrat"
  "$ANALYZE_TEST" "$proof" > "$T/out"
  "$LRAT_CHECK" "$cnf" "$proof" > "$T/check" 2>&1 \
    || { echo "FAIL: native LRAT of level-one failed batch rejected"; \
         cat "$T/check"; exit 1; }
  grep -q 'c VERIFIED' "$T/check" \
    || { echo "FAIL: lrat-check gave no verdict on level-one failed batch"; \
         cat "$T/check"; exit 1; }
fi

# A full Restart can expose a conflict made entirely of chronological
# level-zero implications while the solver stood above root. Restart must
# discharge that conflict before any root rewrite can retire its antecedent.
if [ -n "$RESTART_TEST" ] && [ -x "$CAKE_LPR" ]; then
  cnf="$T/restart-root-conflict.cnf"
  printf 'p cnf 3 3\n-1 0\n-2 0\n1 2 0\n' > "$cnf"
  proof="$cnf.lrat"
  "$RESTART_TEST" "$proof"
  "$CAKE_LPR" "$cnf" "$proof" > "$T/check" 2>&1 \
    || { echo "FAIL: native LRAT of Restart root conflict rejected by cake_lpr"; \
         cat "$T/check"; exit 1; }
  grep -Eq '^s VERIFIED[[:space:]]+UNSAT$' "$T/check" \
    || { echo "FAIL: cake_lpr gave no Restart root-conflict verdict"; \
         cat "$T/check"; exit 1; }
  # Keep the oracle live: the same empty lemma with an incomplete hint chain
  # must be rejected.  This catches verdict parsing and checker invocation
  # mistakes in addition to checking the positive proof.
  printf '4 0 1 3 0\n' > "$T/restart-root-conflict-bad.lrat"
  "$CAKE_LPR" "$cnf" "$T/restart-root-conflict-bad.lrat" \
    > "$T/check-bad" 2>&1 || true
  if grep -Eq '^s VERIFIED[[:space:]]+UNSAT$' "$T/check-bad"; then
    echo "FAIL: cake_lpr accepted invalid Restart root-conflict control"
    cat "$T/check-bad"
    exit 1
  fi
  grep -q 'Checking failed at' "$T/check-bad" \
    || { echo "FAIL: cake_lpr gave no rejection for invalid Restart control"; \
         cat "$T/check-bad"; exit 1; }
fi

# Congruence's additive semantic surface must carry the same native proof
# obligations as its canonical closure. Each fixture has an independent enum2
# refutation tail, while the helper asserts that it first applied exactly the
# requested V6a unit, gate-degeneracy unit, or unary equivalence.
if [ -n "$CONGRUENCE_TEST" ]; then
  printf 'p cnf 4 6\n1 2 0\n1 -2 0\n3 4 0\n3 -4 0\n-3 4 0\n-3 -4 0\n' \
    > "$T/congruence-v6a.cnf"
  printf 'p cnf 7 10\n-3 4 0\n3 -4 0\n-5 3 4 0\n5 -3 4 0\n5 3 -4 0\n-5 -3 -4 0\n6 7 0\n6 -7 0\n-6 7 0\n-6 -7 0\n' \
    > "$T/congruence-gate-unit.cnf"
  printf 'p cnf 7 9\n-3 4 0\n3 -4 0\n-5 3 0\n-5 4 0\n5 -3 -4 0\n6 7 0\n6 -7 0\n-6 7 0\n-6 -7 0\n' \
    > "$T/congruence-unary.cnf"
  printf 'p cnf 4 8\n-3 1 0\n-3 2 0\n3 -1 -2 0\n-4 1 0\n-4 2 0\n4 -1 -2 0\n-3 -4 0\n3 4 0\n' \
    > "$T/congruence-clash.cnf"
  printf 'p cnf 3 6\n-3 1 0\n-3 2 0\n3 -1 -2 0\n3 1 0\n3 2 0\n-3 -1 -2 0\n' \
    > "$T/congruence-literal-clash.cnf"
  printf 'p cnf 5 12\n-5 1 2 0\n5 -1 2 0\n5 1 -2 0\n-5 -1 -2 0\n5 3 4 0\n-5 -3 4 0\n-5 3 -4 0\n5 -3 -4 0\n-1 3 0\n1 -3 0\n-2 4 0\n2 -4 0\n' \
    > "$T/congruence-literal-xor-clash.cnf"
  printf 'p cnf 7 14\n1 -3 7 0\n1 3 -7 0\n-1 -2 7 0\n-1 2 -7 0\n4 -6 -7 0\n4 6 7 0\n-4 -5 -7 0\n-4 5 7 0\n-1 4 0\n1 -4 0\n-2 5 0\n2 -5 0\n-3 6 0\n3 -6 0\n' \
    > "$T/congruence-literal-ite-clash.cnf"
  for kind in v6a gate-unit unary clash literal-clash \
              literal-xor-clash literal-ite-clash; do
    cnf="$T/congruence-$kind.cnf"
    proof="$cnf.semantic.drat"
    "$CONGRUENCE_TEST" "$cnf" "$proof" drat "$kind" \
      > "$T/out" && rc=$? || rc=$?
    [ "$rc" -eq 20 ] \
      || { echo "FAIL: semantic Congruence $kind DRAT helper (rc=$rc)"; exit 1; }
    "$DRAT_TRIM" "$cnf" "$proof" > "$T/check" 2>&1 || true
    grep -q 's VERIFIED' "$T/check" \
      || { echo "FAIL: semantic Congruence $kind DRAT rejected"; \
           cat "$T/check"; exit 1; }
    if [ -x "$LRAT_CHECK" ]; then
      proof="$cnf.semantic.lrat"
      "$CONGRUENCE_TEST" "$cnf" "$proof" lrat "$kind" \
        > "$T/out" && rc=$? || rc=$?
      [ "$rc" -eq 20 ] \
        || { echo "FAIL: semantic Congruence $kind LRAT helper (rc=$rc)"; exit 1; }
      "$LRAT_CHECK" "$cnf" "$proof" > "$T/check" 2>&1 \
        || { echo "FAIL: semantic Congruence $kind LRAT rejected"; \
             cat "$T/check"; exit 1; }
      grep -q 'c VERIFIED' "$T/check" \
        || { echo "FAIL: no semantic Congruence $kind LRAT verdict"; \
             cat "$T/check"; exit 1; }
    fi
  done
  for kind in literal-xor-clash literal-ite-clash; do
    cnf="$T/congruence-$kind.cnf"
    for mode in drat lrat; do
      [ "$mode" = drat ] || [ -x "$LRAT_CHECK" ] || continue
      proof="$cnf.canonical.$mode"
      "$CONGRUENCE_TEST" "$cnf" "$proof" "$mode" "canonical-$kind" \
        > "$T/out" && rc=$? || rc=$?
      [ "$rc" -eq 20 ] \
        || { echo "FAIL: canonical Congruence $kind $mode helper (rc=$rc)"; exit 1; }
      if [ "$mode" = drat ]; then
        "$DRAT_TRIM" "$cnf" "$proof" > "$T/check" 2>&1 || true
        grep -q 's VERIFIED' "$T/check" \
          || { echo "FAIL: canonical Congruence $kind DRAT rejected"; \
               cat "$T/check"; exit 1; }
      else
        "$LRAT_CHECK" "$cnf" "$proof" > "$T/check" 2>&1 \
          || { echo "FAIL: canonical Congruence $kind LRAT rejected"; \
               cat "$T/check"; exit 1; }
        grep -q 'c VERIFIED' "$T/check" \
          || { echo "FAIL: no canonical Congruence $kind LRAT verdict"; \
               cat "$T/check"; exit 1; }
      fi
    done
  done
fi

# ---- the same formulas with BVE in the proof. The generic stress scenario
# BVE at the root, so BVE's resolvent/deletion deltas must compose into a valid
# DRAT + native-LRAT proof: enum2 is refuted by BVE alone (the equivalence-gate
# path derives {b},{¬b}→∅), xor3/php3 mix resolvents with a search-proof tail.
for cnf in "$T/enum2.cnf" "$T/xor3.cnf" "$T/php3.cnf"; do
  for mode in binary ascii; do
    proof="$cnf.bve.$mode.dsr"
    if [ "$mode" = binary ]; then
      TACTIX_STRESS_RULES=BVE "$TACTIX" -q --stress-policy "$cnf" "$proof" > "$T/out" && rc=$? || rc=$?
    else
      TACTIX_STRESS_RULES=BVE "$TACTIX" -q --stress-policy --no-binary "$cnf" "$proof" > "$T/out" \
        && rc=$? || rc=$?
    fi
    [ "$rc" -eq 20 ] || { echo "FAIL: $cnf not UNSAT under BVE (rc=$rc)"; exit 1; }
    grep -q '^s UNSATISFIABLE$' "$T/out" \
      || { echo "FAIL: $cnf (BVE) missing s line"; exit 1; }
    check_dsr "$cnf" "$proof"
  done
  if [ -x "$LRAT_CHECK" ]; then
    proof="$cnf.bve.lrat"
    TACTIX_STRESS_RULES=BVE "$TACTIX" -q --stress-policy --lrat "$cnf" "$proof" > "$T/out" \
      && rc=$? || rc=$?
    [ "$rc" -eq 20 ] || { echo "FAIL: $cnf not UNSAT under BVE --lrat"; exit 1; }
    "$LRAT_CHECK" "$cnf" "$proof" > "$T/check" 2>&1 \
      || { echo "FAIL: native LRAT (BVE) of $cnf rejected"; cat "$T/check"; exit 1; }
    grep -q 'c VERIFIED' "$T/check" \
      || { echo "FAIL: lrat-check gave no verdict on BVE $cnf"; cat "$T/check"; exit 1; }
  fi
done
# ---- BVE through a general definition. `--bve-gates=def` masks off every
# syntactic shape, so any gate here came from the sub-solver and the resolvents
# include non-tautological gate×gate pairs -- the `resolve_gate` path nothing
# else here reaches. The counter assertion below proves that reachability.
printf 'p cnf 4 8\n1 2 0\n1 3 0\n-1 -2 4 0\n-1 -3 -4 0\n2 3 0\n-2 -3 0\n-2 -4 0\n-3 4 0\n' \
  > "$T/bvedef.cnf"
cnf="$T/bvedef.cnf"
for mode in binary ascii; do
  proof="$cnf.$mode.dsr"
  extra=""
  [ "$mode" = ascii ] && extra="--no-binary"
  # shellcheck disable=SC2086
  TACTIX_STRESS_RULES=BVE "$TACTIX" --stress-policy --bve-gates=def $extra "$cnf" "$proof" \
    > "$T/out" && rc=$? || rc=$?
  [ "$rc" -eq 20 ] || { echo "FAIL: bvedef not UNSAT (rc=$rc)"; exit 1; }
  grep -qE '^c bve-gates .*[1-9][0-9]* definition' "$T/out" \
    || { echo "FAIL: no definition gate extracted — the case is vacuous"; \
         grep '^c bve' "$T/out"; exit 1; }
  check_dsr "$cnf" "$proof"
done
if [ -x "$LRAT_CHECK" ]; then
  proof="$cnf.lrat"
  TACTIX_STRESS_RULES=BVE "$TACTIX" -q --stress-policy --bve-gates=def --lrat "$cnf" "$proof" \
    > "$T/out" && rc=$? || rc=$?
  [ "$rc" -eq 20 ] || { echo "FAIL: bvedef not UNSAT under --lrat"; exit 1; }
  "$LRAT_CHECK" "$cnf" "$proof" > "$T/check" 2>&1 \
    || { echo "FAIL: native LRAT of the definition gate rejected"; \
         cat "$T/check"; exit 1; }
  grep -q 'c VERIFIED' "$T/check" \
    || { echo "FAIL: lrat-check gave no verdict on bvedef"; cat "$T/check"; \
         exit 1; }
fi

# ---- BVE one-sided definition core. The four x-side clauses reduce to the
# no-UP enum2 refutation, so the embedded proof has to be lifted lemma by lemma
# to derive x; (not x v c) keeps a nonempty opposite side. The independent
# d/e enum2 tail makes the whole input UNSAT without pre-fixing x. Structural
# score/order selects x first under the BVE stress policy.
printf 'p cnf 6 9\n1 2 3 0\n1 2 -3 0\n1 -2 3 0\n1 -2 -3 0\n-1 4 0\n5 6 0\n5 -6 0\n-5 6 0\n-5 -6 0\n' \
  > "$T/bvedefunit.cnf"
cnf="$T/bvedefunit.cnf"
for mode in binary ascii; do
  proof="$cnf.$mode.dsr"
  extra=""
  [ "$mode" = ascii ] && extra="--no-binary"
  # shellcheck disable=SC2086
  TACTIX_STRESS_RULES=BVE "$TACTIX" --stress-policy --bve-gates=def $extra "$cnf" "$proof" \
    > "$T/out" && rc=$? || rc=$?
  [ "$rc" -eq 20 ] || { echo "FAIL: bvedefunit not UNSAT (rc=$rc)"; exit 1; }
  grep -qE '^c bve-def .* [1-9][0-9]* units$' "$T/out" \
    || { echo "FAIL: no one-sided definition unit extracted"; \
         grep '^c bve' "$T/out"; exit 1; }
  check_dsr "$cnf" "$proof"
done
if [ -x "$LRAT_CHECK" ]; then
  proof="$cnf.lrat"
  TACTIX_STRESS_RULES=BVE "$TACTIX" --stress-policy --bve-gates=def --lrat "$cnf" "$proof" \
    > "$T/out" && rc=$? || rc=$?
  [ "$rc" -eq 20 ] || { echo "FAIL: bvedefunit not UNSAT under --lrat"; exit 1; }
  "$LRAT_CHECK" "$cnf" "$proof" > "$T/check" 2>&1 \
    || { echo "FAIL: native LRAT of one-sided definition rejected"; \
         cat "$T/check"; exit 1; }
  grep -q 'c VERIFIED' "$T/check" \
    || { echo "FAIL: lrat-check gave no verdict on bvedefunit"; \
         cat "$T/check"; exit 1; }
fi

# ---- Factor (BVA) native-LRAT: dividers emit vacuous add-RAT (fresh pivot, no
# ¬x clauses yet → empty hints) and quotients emit add-RAT with one resolution
# group per divider (the resolvent (fᵢ∨rⱼ) discharged by the still-live
# original's id). The second case duplicates a grid binary, for delete-all-copies
# under LRAT. The third is a 2x3 occurrence grid whose three columns have equal
# large-clause contents but distinct ids; it pins aligned multiset hints and
# deletion. TACTIX_NO_BVE keeps BVE off the grid until Factor has run.
printf 'p cnf 7 13\n1 3 0\n1 4 0\n1 5 0\n2 3 0\n2 4 0\n2 5 0\n-1 -2 0\n-3 -4 0\n-5 -3 0\n6 7 0\n6 -7 0\n-6 7 0\n-6 -7 0\n' > "$T/factor.cnf"
printf 'p cnf 7 14\n1 3 0\n1 3 0\n1 4 0\n1 5 0\n2 3 0\n2 4 0\n2 5 0\n-1 -2 0\n-3 -4 0\n-5 -3 0\n6 7 0\n6 -7 0\n-6 7 0\n-6 -7 0\n' > "$T/factor_dup.cnf"
printf 'p cnf 6 10\n1 3 4 0\n2 3 4 0\n1 3 4 0\n2 3 4 0\n1 3 4 0\n2 3 4 0\n5 6 0\n5 -6 0\n-5 6 0\n-5 -6 0\n' > "$T/factor_dup_large.cnf"
for cnf in "$T/factor.cnf" "$T/factor_dup.cnf" "$T/factor_dup_large.cnf"; do
  for mode in binary ascii; do
    proof="$cnf.fac.$mode.dsr"
    if [ "$mode" = binary ]; then
      TACTIX_NO_BVE=1 "$TACTIX" -q "$cnf" "$proof" \
        > "$T/out" && rc=$? || rc=$?
    else
      TACTIX_NO_BVE=1 "$TACTIX" -q --no-binary "$cnf" \
        "$proof" > "$T/out" && rc=$? || rc=$?
    fi
    [ "$rc" -eq 20 ] || { echo "FAIL: $cnf not UNSAT under Factor (rc=$rc)"; exit 1; }
    grep -q '^s UNSATISFIABLE$' "$T/out" \
      || { echo "FAIL: $cnf (Factor) missing s line"; exit 1; }
    check_dsr "$cnf" "$proof"
  done
  if [ -x "$LRAT_CHECK" ]; then
    proof="$cnf.fac.lrat"
    TACTIX_NO_BVE=1 "$TACTIX" -q --lrat "$cnf" "$proof" \
      > "$T/out" && rc=$? || rc=$?
    [ "$rc" -eq 20 ] || { echo "FAIL: $cnf not UNSAT under Factor --lrat"; exit 1; }
    "$LRAT_CHECK" "$cnf" "$proof" > "$T/check" 2>&1 \
      || { echo "FAIL: native LRAT (Factor) of $cnf rejected"; cat "$T/check"; exit 1; }
    grep -q 'c VERIFIED' "$T/check" \
      || { echo "FAIL: lrat-check gave no verdict on Factor $cnf"; cat "$T/check"; exit 1; }
  fi
done

# The public exact-grid surface also admits the equality case m*n=m+n (2x2).
# Drive that opt-in action directly: the shipped canonical schedule remains
# profitability-filtered. Check its SAT projection against the original CNF,
# then its UNSAT proof in both proof formats.
if [ -n "$FACTOR_N1_TEST" ]; then
  printf 'p cnf 4 4\n1 3 0\n1 4 0\n2 3 0\n2 4 0\n' > "$T/factor_zero_sat.cnf"
  "$FACTOR_N1_TEST" "$T/factor_zero_sat.cnf" \
    "$T/factor_zero_sat.drat" drat > "$T/out" && rc=$? || rc=$?
  [ "$rc" -eq 10 ] || { echo "FAIL: zero-gain Factor SAT witness (rc=$rc)"; exit 1; }
  "$ROOT/tools/fuzz/checkmodel" "$T/factor_zero_sat.cnf" "$T/out" \
    || { echo "FAIL: zero-gain Factor model rejected"; exit 1; }

  printf 'p cnf 6 8\n1 3 0\n1 4 0\n2 3 0\n2 4 0\n5 6 0\n5 -6 0\n-5 6 0\n-5 -6 0\n' \
    > "$T/factor_zero_unsat.cnf"
  for mode in drat lrat; do
    [ "$mode" = drat ] || [ -x "$LRAT_CHECK" ] || continue
    proof="$T/factor_zero_unsat.$mode"
    "$FACTOR_N1_TEST" "$T/factor_zero_unsat.cnf" "$proof" "$mode" \
      > "$T/out" && rc=$? || rc=$?
    [ "$rc" -eq 20 ] || { echo "FAIL: zero-gain Factor UNSAT witness (rc=$rc)"; exit 1; }
    if [ "$mode" = drat ]; then
      "$DRAT_TRIM" "$T/factor_zero_unsat.cnf" "$proof" > "$T/check" 2>&1 || true
      grep -q 's VERIFIED' "$T/check" \
        || { echo "FAIL: zero-gain Factor DRAT rejected"; cat "$T/check"; exit 1; }
    else
      "$LRAT_CHECK" "$T/factor_zero_unsat.cnf" "$proof" > "$T/check" 2>&1 \
        || { echo "FAIL: zero-gain Factor LRAT rejected"; cat "$T/check"; exit 1; }
      grep -q 'c VERIFIED' "$T/check" \
        || { echo "FAIL: zero-gain Factor LRAT missing verdict"; cat "$T/check"; exit 1; }
    fi
  done
fi
# V3 rewrite chain order (corpus 019-022 family): a substituted literal whose
# representative is root-false needs that unit BEFORE the bridging lemma, since
# the unit is what makes the lemma unit. Reached through a legal random
# schedule rather than the default one, so drive that schedule explicitly.
if [ -x "$LRAT_CHECK" ]; then
  printf 'p cnf 7 7\n-4 3 1 0\n-5 4 0\n-6 2 0\n6 -2 0\n7 6 2 0\n-6 -2 0\n-7 0\n' \
    > "$T/substchain.cnf"
  "$TACTIX" -q --random-policy=1 --lrat "$T/substchain.cnf" \
    "$T/substchain.lrat" > "$T/out" && rc=$? || rc=$?
  [ "$rc" -eq 20 ] || { echo "FAIL: substchain not UNSAT (rc=$rc)"; exit 1; }
  "$LRAT_CHECK" "$T/substchain.cnf" "$T/substchain.lrat" > "$T/check" 2>&1 || true
  grep -q 'c VERIFIED' "$T/check" \
    || { echo "FAIL: native LRAT of substchain rejected"; cat "$T/check"; exit 1; }
fi

# Internal structured advice must accept unequal duplicate counts, retaining
# exact missing-image rejection and independently checked SAT/UNSAT results.
if [ -n "$ONLINE_INPROCESS_TEST" ]; then
  corpus="$ROOT/tools/fuzz/corpus/regressions/sr-unequal-duplicate-handoff"
  for case in min case; do
    for arm in production diagnostic; do
      cnf="$corpus/$case.cnf"
      proof="$T/unequal-$case-$arm.dsr"
      if [ "$arm" = production ]; then
        "$TACTIX" --dsr "$cnf" "$proof" > "$T/out" && rc=$? || rc=$?
      else
        "$ONLINE_INPROCESS_TEST" "$cnf" "$proof" dsr CombinedSR all \
          > "$T/out" && rc=$? || rc=$?
      fi
      if [ "$case" = min ]; then
        [ "$rc" -eq 10 ] || { echo "FAIL: unequal duplicate SAT (rc=$rc)"; exit 1; }
        "$ROOT/tools/fuzz/checkmodel" "$cnf" "$T/out"
      else
        [ "$rc" -eq 20 ] || { echo "FAIL: unequal duplicate UNSAT (rc=$rc)"; exit 1; }
        check_dsr "$cnf" "$proof"
      fi
    done
  done
fi

# Combined startup must retain the reference PureOnly predecessor when it
# selects individual SR sub-strategies. Check both the actual transition and
# the reconstructed model/proof against an input containing a pure variable.
if [ -n "$ONLINE_INPROCESS_TEST" ]; then
  for vertices in 4 5; do
    for sign in 1 -1; do
      cnf="$T/combined-pure-$vertices-$sign.cnf"
      python3 - "$cnf" "$vertices" "$sign" <<'PY'
import sys
path, vertices, sign = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
lit = lambda v, c: sign * (3 * v + c + 1)
clauses = []
for v in range(vertices):
    clauses.append([lit(v, c) for c in range(3)])
    clauses.extend([-lit(v, a), -lit(v, b)] for a in range(3) for b in range(a + 1, 3))
for a in range(vertices):
    for b in range(a + 1, vertices):
        if a or b == 1:
            clauses.extend([-lit(a, c), -lit(b, c)] for c in range(3))
clauses.append([sign * (3 * vertices + 1), lit(0, 0)])
with open(path, 'w') as out:
    out.write(f'p cnf {3 * vertices + 1} {len(clauses)}\n')
    for clause in clauses:
        out.write(' '.join(map(str, clause)) + ' 0\n')
PY
      "$ONLINE_INPROCESS_TEST" "$cnf" "$T/combined-pure.dsr" dsr CombinedSR all \
        > "$T/out" && rc=$? || rc=$?
      grep -q 'c structured step 94 .*progress 1' "$T/out" \
        || { echo "FAIL: CombinedSR omitted its PureOnly transition"; exit 1; }
      if [ "$vertices" = 4 ]; then
        [ "$rc" -eq 10 ] || { echo "FAIL: CombinedSR pure SAT (rc=$rc)"; exit 1; }
        "$ROOT/tools/fuzz/checkmodel" "$cnf" "$T/out"
      else
        [ "$rc" -eq 20 ] || { echo "FAIL: CombinedSR pure UNSAT (rc=$rc)"; exit 1; }
        check_dsr "$cnf" "$T/combined-pure.dsr"
      fi
    done
  done
fi

# Product-axis completion must move coupled auxiliary variables, preserve
# trace-off certificates, and extend to independently checked SAT/UNSAT tails.
if [ -n "$ONLINE_INPROCESS_TEST" ]; then
  for unsat in 0 1; do
    for sign in 1 -1; do
      cnf="$T/product-coupled-$unsat-$sign.cnf"
      python3 - "$cnf" "$unsat" "$sign" <<'PYFIXTURE'
import sys
path, unsat, sign = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
x = lambda r, c: sign * (3*r+c+1)
y = lambda c: sign * (10+c)
clauses = [[x(r,c) for c in range(3)] for r in range(3)]
clauses += [[-x(r,c), y(c)] for r in range(3) for c in range(3)]
clauses += [[-x(a,c), -x(b,c)] for c in range(3) for a in range(3) for b in range(a+1,3)]
if unsat:
    # Keep the coupled product component identical to the SAT control. A
    # clause over y changes its refinement/ULC structure and can let a row
    # producer solve before product completion is exercised.
    clauses += [[a*13, b*14] for a in (1, -1) for b in (1, -1)]
with open(path, 'w') as out:
    out.write(f'p cnf {14 if unsat else 12} {len(clauses)}\n')
    for clause in clauses:
        out.write(' '.join(map(str, clause)) + ' 0\n')
PYFIXTURE
      for trace in 0 1; do
        proof="$T/product-coupled-$trace.dsr"
        TACTIX_SR_TRACE="$trace" "$ONLINE_INPROCESS_TEST" "$cnf" "$proof" dsr OrbitopalProductSR all \
          > "$T/product-out-$trace" 2> "$T/product-trace-$trace" && rc=$? || rc=$?
        grep -Eq 'c structured totals applications [1-9][0-9]* applied [1-9]' "$T/product-out-$trace" \
          || { echo "FAIL: coupled product made no effective SR application"; exit 1; }
        if [ "$unsat" = 1 ]; then
          [ "$rc" -eq 20 ] || { echo "FAIL: coupled product UNSAT (rc=$rc)"; exit 1; }
        else
          [ "$rc" -eq 10 ] || { echo "FAIL: coupled product SAT (rc=$rc)"; exit 1; }
          "$ROOT/tools/fuzz/checkmodel" "$cnf" "$T/product-out-$trace"
        fi
      done
      grep -Eq 'product_axis_check.*pure[[:space:]]0' "$T/product-trace-1" \
        || { echo "FAIL: product control did not require permutation completion"; exit 1; }
      grep -Eq 'product_axes_completed.*row_valid[[:space:]]1.*column_valid[[:space:]]1' "$T/product-trace-1" \
        || { echo "FAIL: product control did not complete both axes"; exit 1; }
      cmp "$T/product-coupled-0.dsr" "$T/product-coupled-1.dsr" \
        || { echo "FAIL: product tracing changed the certificate"; exit 1; }
      if [ "$unsat" = 1 ]; then
        check_dsr "$cnf" "$T/product-coupled-1.dsr"
      fi
    done
  done
fi

# A canonical SCC image can become unit only after replacing an inactive
# source endpoint by a representative fixed since Tarjan froze the map.  Keep
# the complete fuzz reproducer here: the parent emitted (-28 v -66) but never
# published -66, and a much later BVE resolvent exposed the stale root closure.
if [ -x "$DSR_TRIM" ] && [ -x "$SR_CHECK" ]; then
  corpus="$ROOT/tools/fuzz/corpus/regressions/034-substitute-root-fixed-binary-image-unit/case.cnf"
  proof="$T/substitute-root-fixed-binary-image-unit.dsr"
  "$TACTIX" -q --random-policy=296716882 "$corpus" "$proof" \
    > "$T/substitute-root-fixed-binary-image-unit.out" && rc=$? || rc=$?
  [ "$rc" -eq 20 ] \
    || { echo "FAIL: Substitute root-fixed binary image (rc=$rc)"; exit 1; }
  check_dsr "$corpus" "$proof"
fi

# A growth-declined BVE candidate keeps the unit resolvents it learned, so the
# canonical round's entry schedule and root closure are stale from that point.
# The minimized fuzz reproducer drives the random policy through such a round;
# it must end there, and the reconstructed model must satisfy the input.
corpus="$ROOT/tools/fuzz/corpus/regressions/035-bve-round-stale-schedule-fixed-pivot/case.cnf"
"$TACTIX" -q --random-policy=296725965 "$corpus" \
  > "$T/bve-round-stale-schedule.out" && rc=$? || rc=$?
[ "$rc" -eq 10 ] \
  || { echo "FAIL: BVE round stale-schedule fixed pivot (rc=$rc)"; exit 1; }
"$ROOT/tools/fuzz/checkmodel" "$corpus" "$T/bve-round-stale-schedule.out" \
  || { echo "FAIL: BVE round stale-schedule model rejected"; exit 1; }

echo "micro_proofs OK"
