#include "rules/ternary/ternary.hpp"

#include "proof/proof.hpp"
#include "rules/propagate/propagate.hpp"

#include <algorithm>
#include <cassert>
#include <limits>
#include <vector>

namespace tactix {

namespace {

// A ternary candidate: the clause plus its three literals, snapshotted so the
// pair loop never re-reads the arena, which `kernel_add_large_clause` may
// reallocate (the same hazard bve.cpp records).
struct Tern {
  Ref ref;
  uint64_t id;
  Lit l[3];
};

bool root_open(const Kernel &k, Lit l) { return k.values[l] == 0; }

bool has_lit(const Clause *c, Lit t) {
  for (const Lit l : *c)
    if (l == t)
      return true;
  return false;
}

// Ternary, irredundant, all three literals unassigned at the drained root. A
// root-true literal makes the clause satisfied; a root-false one makes it
// really a shorter clause, and resolving the stale ternary form would emit a
// weaker consequence than the formula already has.
bool ternary_candidate(const Kernel &k, const Clause *c) {
  if (c->garbage() || c->redundant() || c->size != 3)
    return false;
  return root_open(k, c->lits[0]) && root_open(k, c->lits[1]) &&
         root_open(k, c->lits[2]);
}

// Collect the ternary clauses containing `l`. Dense fast-path when the shared
// index is attached (kissat dense.c analogue); otherwise one arena scan, the
// round-local path every inprocessing rule keeps for N1 standalone use.
void collect(const Kernel &k, Lit l, std::vector<Tern> &out) {
  out.clear();
  auto take = [&](Ref ref, const Clause *c) {
    Tern t;
    t.ref = ref;
    t.id = c->id();
    t.l[0] = c->lits[0];
    t.l[1] = c->lits[1];
    t.l[2] = c->lits[2];
    out.push_back(t);
  };
  if (k.dense) {
    k.dense->with_large(l, [&](auto refs) {
      for (const Ref ref : refs) {
        const Clause *c = clause_at(k.arena, ref);
        if (ternary_candidate(k, c))
          take(ref, c);
      }
    });
    return;
  }
  for (Ref ref = 0; ref < k.arena.size();) {
    const Clause *c = clause_at(k.arena, ref);
    const uint32_t words = clause_actual_words(c);
    if (ternary_candidate(k, c) && has_lit(c, l))
      take(ref, c);
    ref += words;
  }
}

// Is the exact ternary {a,b,c} already present? Scans one occurrence list,
// cadical's `ternary_find_ternary_clause` shape.
bool ternary_exists(const Kernel &k, Lit a, Lit b, Lit c) {
  auto same = [&](const Clause *x) {
    return has_lit(x, a) && has_lit(x, b) && has_lit(x, c);
  };
  if (k.dense) {
    return k.dense->with_large(a, [&](auto refs) {
      for (const Ref ref : refs) {
        const Clause *x = clause_at(k.arena, ref);
        if (!x->garbage() && x->size == 3 && same(x))
          return true;
      }
      return false;
    });
  }
  for (Ref ref = 0; ref < k.arena.size();) {
    const Clause *x = clause_at(k.arena, ref);
    const uint32_t words = clause_actual_words(x);
    if (!x->garbage() && x->size == 3 && same(x))
      return true;
    ref += words;
  }
  return false;
}

// Resolve `c` (contains pivot) with `d` (contains ¬pivot) on pivot. Returns
// false when the resolvent is tautological or would exceed three literals —
// cadical's `hyper_ternary_resolve` rejections, minus the "already present"
// test, which the caller does (it differs by resolvent size).
bool resolve(const Tern &c, const Tern &d, Lit pivot, std::vector<Lit> &res) {
  res.clear();
  for (const Lit l : c.l)
    if (l != pivot)
      res.push_back(l);
  assert(res.size() == 2);
  for (const Lit l : d.l) {
    if (l == negate(pivot))
      continue;
    if (l == res[0] || l == res[1])
      continue;
    if (l == negate(res[0]) || l == negate(res[1]))
      return false; // tautological
    if (res.size() == 3)
      return false; // would be quaternary
    res.push_back(l);
  }
  return true;
}

bool add_resolvent(Kernel &k, const Tern &positive, const Tern &negative,
                   const std::vector<Lit> &res) {
  if (res.size() == 2) {
    if (kernel_binary_live(k, res[0], res[1]))
      return false;
  } else if (ternary_exists(k, res[0], res[1], res[2])) {
    return false;
  }
  // RUP from its two parents, in checker-propagation order: negating the
  // resolvent falsifies every literal of `positive` but the pivot, so it forces
  // the pivot and `negative` is then falsified (the E1 resolvent argument).
  const bool lrat = k.proof && k.proof->lrat();
  const uint64_t id = ++k.next_clause_id;
  const uint64_t chain[2] = {positive.id, negative.id};
  if (k.proof)
    k.proof->add_rup(lrat ? id : 0, res.data(),
                     static_cast<uint32_t>(res.size()),
                     lrat ? chain : nullptr, lrat ? 2 : 0);
  if (res.size() == 2) {
    kernel_add_binary_clause(k, res[0], res[1], id);
    ++k.stats.ternary_binaries;
  } else {
    kernel_add_large_clause(k, res.data(), 3, /*redundant=*/true,
                            /*glue=*/3, id);
    ++k.stats.ternary_resolvents;
  }
  return true;
}

struct TernaryChoice {
  Tern positive;
  Tern negative;
  std::vector<Lit> resolvent;
};

void semantic_choices(Kernel &k, std::vector<TernaryChoice> &out) {
  out.clear();
  std::vector<Lit> pivots;
  ternary_pivots(k, pivots, nullptr, /*complete=*/true);
  std::vector<Tern> positive, negative;
  std::vector<Lit> resolvent;
  for (const Lit pivot : pivots) {
    collect(k, pivot, positive);
    collect(k, negate(pivot), negative);
    for (const Tern &c : positive)
      for (const Tern &d : negative) {
        if (!resolve(c, d, pivot, resolvent))
          continue;
        if (resolvent.size() == 2) {
          if (kernel_binary_live(k, resolvent[0], resolvent[1]))
            continue;
        } else if (ternary_exists(k, resolvent[0], resolvent[1],
                                  resolvent[2])) {
          continue;
        }
        out.push_back({c, d, resolvent});
      }
  }
}

} // namespace

uint64_t ternary_percent_limit(uint64_t base, uint32_t percent) {
  if (!percent)
    return 0;
  constexpr uint64_t maximum = std::numeric_limits<uint64_t>::max();
  const uint64_t quotient = base / 100;
  const uint64_t remainder = base % 100;
  if (quotient > maximum / percent)
    return maximum;
  const uint64_t high = quotient * percent;
  const uint64_t low = remainder * static_cast<uint64_t>(percent) / 100;
  return high > maximum - low ? maximum : high + low;
}

RuleEligibility ternary_guard(const Kernel &k) {
  RuleEligibility result;
  return result.fact("consistent", !k.inconsistent)
      .fact("root-level", k.level == 0);
}

void ternary_pivots(const Kernel &k, std::vector<Lit> &out,
                    uint64_t *total_clauses, bool complete) {
  out.clear();
  const uint32_t nlits = 2 * k.nvars;
  std::vector<uint32_t> tern(nlits, 0);
  uint64_t clauses = 0;
  // one pass to count ternary occurrences per literal; a pivot needs at least
  // one on each side for a pair to exist. The same pass totals live clauses,
  // the base for the max-add governor below (as cadical's htrs_limit is)
  for (Ref ref = 0; ref < k.arena.size();) {
    const Clause *c = clause_at(k.arena, ref);
    const uint32_t words = clause_actual_words(c);
    if (!c->garbage())
      clauses++;
    if (ternary_candidate(k, c))
      for (const Lit l : *c)
        tern[l]++;
    ref += words;
  }
  clauses += k.binary_ids.size();
  if (total_clauses)
    *total_clauses = clauses;
  const uint32_t occ_lim = k.ternary_occ_limit;
  for (Lit l = 0; l < nlits; l += 2) // positive literal of each variable
    if (tern[l] && tern[negate(l)] &&
        // cadical ternary.cpp:247 — a pivot in a dense neighbourhood is skipped
        // on BOTH polarities before any resolution work is attempted.
        (complete ||
         !(occ_lim && (tern[l] > occ_lim || tern[negate(l)] > occ_lim))))
      out.push_back(l);
}

ApplyResult ternary_try(Kernel &k, Lit pivot) {
  if (k.values[pivot] != 0)
    return ApplyResult::NoOp;
  std::vector<Tern> pos, neg;
  collect(k, pivot, pos);
  collect(k, negate(pivot), neg);
  k.stats.ternary_ticks += pos.size() + neg.size();
  if (pos.empty() || neg.empty())
    return ApplyResult::NoOp;

  std::vector<Lit> res;
  bool added = false;
  // §6 termination polled per pair, not per outer clause: `ternary_exists`
  // scans a whole occurrence list (the entire arena when no dense index is
  // attached), so one pair is the largest unit worth running to completion.
  bool interrupted = false;
  for (const Tern &c : pos) {
    if (interrupted)
      break;
    for (const Tern &d : neg) {
      // Nothing is half-added here: each resolvent's `add_rup` and its kernel
      // add are one unit, and `res` is scratch. Aborting means the rule derived
      // fewer consequences, which is always sound.
      if (kernel_rule_interrupt(k, k.stats.ternary_interrupted)) {
        interrupted = true;
        break;
      }
      k.stats.ternary_ticks++;
      if (!resolve(c, d, pivot, res))
        continue;
      added |= add_resolvent(k, c, d, res);
    }
  }
  return added ? ApplyResult::Ok : ApplyResult::NoOp;
}

ApplyResult ternary_apply(Kernel &k) {
  std::vector<Lit> pivots;
  uint64_t total_clauses = 0;
  ternary_pivots(k, pivots, &total_clauses);
  bool added = false;
  // Budget-aware batch rule (EffortSpec budget_aware): stop mid-round when the
  // policy's ledger in this rule's currency is spent. Unbudgeted, one round can
  // add enough redundant clauses to turn a fast solve into a timeout.
  const uint64_t tick_start = k.stats.ternary_ticks;
  // Growth governor (cadical `ternarymaxadd`, ternary.cpp:387): the ticks
  // budget bounds work, not output, and this rule's failure mode is output —
  // the resolvent count runs away once BCE stops shrinking its candidate pool.
  const uint64_t add_start =
      k.stats.ternary_resolvents + k.stats.ternary_binaries;
  const uint64_t add_limit =
      ternary_percent_limit(total_clauses, k.ternary_max_add_percent);
  // Repetition filter over the touched-epoch substrate; cadical keeps the same
  // thing as a per-variable `ternary` flag (ternary.cpp:258-266). A pivot with
  // no new material resolves the same pairs to the same already-present
  // resolvents, rejected at full P·N cost. Deletion is not consulted, because
  // removing a ternary can only shrink the pair set. It cannot wedge: this
  // rule's own resolvents are adds, so a productive round arms the next one.
  // N1: `ternary_pivots` and `ternary_try` stay complete.
  const bool filter = k.touch_filter;
  const uint64_t snapshot = k.touch_epoch;
  const uint64_t wm = k.ternary_touch_mark;
  size_t stopped_at = pivots.size();
  for (size_t pi = 0; pi < pivots.size(); pi++) {
    const Lit p = pivots[pi];
    if (kernel_work_budget_exceeded(k,
                                    k.stats.ternary_ticks - tick_start)) {
      stopped_at = pi;
      break;
    }
    if (add_limit &&
        (k.stats.ternary_resolvents + k.stats.ternary_binaries) - add_start >=
            add_limit) {
      stopped_at = pi;
      break;
    }
    // §6 termination, which neither governor above implies: both are
    // effort/output ceilings a policy may set to 0. Cut at the same point so
    // the untried tail goes through the same re-arm path.
    if (kernel_rule_interrupt(k, k.stats.ternary_interrupted)) {
      stopped_at = pi;
      break;
    }
    if (filter && !kernel_touched_since(k, var_of(p), wm)) {
      k.stats.ternary_mark_skipped++;
      continue;
    }
    const ApplyResult r = ternary_try(k, p);
    if (r == ApplyResult::Unsat)
      return r;
    added |= (r == ApplyResult::Ok);
  }
  // Resume: re-arm the pivots this round never reached, then advance the
  // watermark. Both cut paths above leave a tail, and the add-limit one is
  // reachable under DefaultPolicy, unlike C1/C2's.
  for (size_t pi = filter ? stopped_at : pivots.size(); pi < pivots.size();
       pi++) {
    if (!kernel_touched_since(k, var_of(pivots[pi]), wm))
      continue;
    kernel_touch_var(k, var_of(pivots[pi]));
    k.stats.ternary_rearmed++;
  }
  if (filter)
    k.ternary_touch_mark = snapshot;
  if (added)
    k.stats.ternary_rounds++;
  return added ? ApplyResult::Ok : ApplyResult::NoOp;
}

static uint32_t ternary_instances(Kernel &k, uint64_t *out, uint32_t cap) {
  std::vector<Lit> pivots;
  ternary_pivots(k, pivots, nullptr, /*complete=*/true);
  const uint32_t n =
      std::min<uint32_t>(cap, static_cast<uint32_t>(pivots.size()));
  for (uint32_t i = 0; i < n; i++)
    out[i] = lit_instance(k, pivots[i]);
  return n;
}

static ApplyResult ternary_apply_instance(Kernel &k, uint64_t inst) {
  // D-LEVEL: drain the root closure (no-op at a fixpoint); a conflict refutes.
  if (inprocess_reach_root(k))
    return ApplyResult::Unsat;
  if (inst == INSTANCE_CANONICAL)
    return ternary_apply(k);
  Lit pivot;
  if (!lit_of_instance(k, inst, &pivot))
    return ApplyResult::NoOp;
  return ternary_try(k, pivot);
}

static uint64_t ternary_choice_instance(const TernaryChoice &choice) {
  assert(choice.positive.ref != INVALID_REF &&
         choice.negative.ref != INVALID_REF);
  return (static_cast<uint64_t>(choice.positive.ref) << 32) |
         choice.negative.ref;
}

static uint32_t ternary_semantic_instances(Kernel &k, uint64_t *out,
                                           uint32_t cap) {
  std::vector<TernaryChoice> choices;
  semantic_choices(k, choices);
  const uint32_t count = std::min<uint32_t>(
      cap, static_cast<uint32_t>(choices.size()));
  for (uint32_t i = 0; i < count; ++i)
    out[i] = ternary_choice_instance(choices[i]);
  return count;
}

static ApplyResult ternary_apply_semantic_instance(Kernel &k, uint64_t inst) {
  if (inprocess_reach_root(k))
    return ApplyResult::Unsat;
  if (inst == INSTANCE_CANONICAL)
    return ternary_apply(k);
  std::vector<TernaryChoice> choices;
  semantic_choices(k, choices);
  for (const TernaryChoice &choice : choices) {
    if (ternary_choice_instance(choice) != inst)
      continue;
    return add_resolvent(k, choice.positive, choice.negative,
                         choice.resolvent)
               ? ApplyResult::Ok
               : ApplyResult::NoOp;
  }
  return ApplyResult::NoOp;
}

TACTIX_REGISTER_RULE(HyperTernaryRes, RuleTier::Inprocess, ternary_guard,
                     ternary_apply, ternary_instances, ternary_apply_instance,
                     ternary_semantic_instances,
                     ternary_apply_semantic_instance);

} // namespace tactix
