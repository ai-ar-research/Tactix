// See substitute.hpp for the rule's contract. The SCC pass is transliterated
// from kissat decompose.c/substitute.c and cadical decompose.cpp (iterative
// Tarjan), deliberately not CryptoMiniSat's recursive sccfinder: its
// max_scc_depth early-return silently drops deep SCCs, a completeness loss,
// whereas an explicit work stack survives arbitrarily deep chains.
#include "rules/substitute/substitute.hpp"
#include "strategy/substitute_execution.hpp"

#include "diagnostics/event_trace.hpp"
#include "diagnostics/rule_journal.hpp"
#include "rules/propagate/propagate.hpp"

#include "kernel/watch.hpp"
#include "proof/proof.hpp"

#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <deque>
#include <numeric>
#include <unordered_map>
#include <unordered_set>
#include <utility>

#ifdef TACTIX_ENABLE_EVENT_TRACE
#include <sys/resource.h>
#include <unistd.h>
#endif

namespace tactix {

// Single in-place binary-substitution pass (Kissat substitute_binaries port)
// for the non-session DRAT path, replacing the former image-array pipeline.

namespace {

// Allocation-boundary tracing is compiled only into semantic-trace builds.
// Substitute owns several literal-indexed tables; on giant formulas the last
// successful line identifies which dense allocation crossed the memory limit.
#ifdef TACTIX_ENABLE_EVENT_TRACE
void substitute_stage_trace(const Kernel &k, const char *stage,
                            size_t first = 0, size_t second = 0,
                            size_t third = 0) {
  static FILE *out = nullptr;
  static bool initialized = false;
  if (!initialized) {
    initialized = true;
    const char *path = std::getenv("TACTIX_SUBSTITUTE_MEMORY_TRACE");
    if (path && *path) {
      out = std::fopen(path, "w");
      if (out)
        std::setvbuf(out, nullptr, _IOLBF, 0);
    }
  }
  if (!out)
    return;
  struct rusage usage {};
  getrusage(RUSAGE_SELF, &usage);
  unsigned long virtual_pages = 0;
  if (FILE *statm = std::fopen("/proc/self/statm", "r")) {
    (void)std::fscanf(statm, "%lu", &virtual_pages);
    std::fclose(statm);
  }
  const unsigned long virtual_kib =
      virtual_pages * static_cast<unsigned long>(sysconf(_SC_PAGESIZE) / 1024);
  std::fprintf(out,
               "%s\trss_kib=%ld\tvm_kib=%lu\tvars=%u\tarena_words=%zu\t"
               "watch_words=%zu\twatch_capacity=%zu\tfirst=%zu\tsecond=%zu\t"
               "third=%zu\n",
               stage, usage.ru_maxrss, virtual_kib, k.nvars, k.arena.size(),
               k.watches.arena.size(), k.watches.arena.capacity(), first,
               second, third);
}
#else
inline void substitute_stage_trace(const Kernel &, const char *, size_t = 0,
                                   size_t = 0, size_t = 0) {}
#endif

} // namespace

RuleEligibility substitute_guard(const Kernel &k) {
  // Quiescent root. No ¬conflict_valid conjunct: a pure F-rewrite is sound
  // regardless of a recorded conflict (D-SPLIT-3, `docs/calculus.md` §7).
  RuleEligibility result;
  return result.fact("consistent", !k.inconsistent)
      .fact("root-level", k.level == 0);
}

SccResult substitute_find_sccs(const Kernel &k, bool collect_instances,
                               bool account_work) {
  const Lit nlits = static_cast<Lit>(2 * k.nvars);
  SccResult res;
  substitute_stage_trace(k, "scc-entry", nlits);
  res.repr.assign(nlits, INVALID_LIT);
  substitute_stage_trace(k, "scc-repr", res.repr.size(),
                         res.repr.capacity());
  if (nlits == 0)
    return res;

  // The DFS index and the low-link of one literal are read together at every
  // step of the search, so they share a record instead of living in two
  // formula-wide arrays that cost two cache lines per visit.
  struct SccNode {
    uint32_t dfs = 0; // 1-based DFS index; 0 = unvisited
    uint32_t low = 0;
  };
  std::vector<SccNode> node(nlits);
  substitute_stage_trace(k, "scc-dfs", node.size(), node.capacity());
  std::vector<Lit> tstack; // Tarjan's component stack
  uint32_t next = 1;

  // explicit DFS work stack: (node, resume point in the node's watch list)
  struct Frame {
    Lit v;
    WatchIter it;
  };
  std::vector<Frame> work;
  const auto charge = [&](uint64_t ticks) {
    if (account_work)
      k.stats.substitute_ticks += ticks;
  };

  // Kissat substitute.c builds the implication SCC graph from ACTIVE
  // variables only.  Retired identities can remain addressable and stale
  // binaries can mention them, but they must not be substituted a second time:
  // that would enqueue a duplicate deactivation for an already-disconnected
  // decision variable.
  auto active = [&](Lit l) {
    return k.values[l] == 0 && !kernel_var_retired(k, var_of(l));
  };
  // Out-edges of p are the binary watches of negate(p): (negate(p) ∨ q) is
  // exactly p → q. The watch arena is never mutated here, so a suspended
  // iterator stays valid across the whole DFS.
  auto out_edges = [&](Lit p) { return k.watches.entries(negate(p)); };

  // `kernel_vars_in_import_order` clears and refills, so pre-sizing here only
  // pays for a zero fill the call throws away.
  std::vector<Var> roots;
  kernel_vars_in_import_order(k, roots);
  substitute_stage_trace(k, "scc-roots", roots.size(), roots.capacity());
  for (const Var root_var : roots) {
    for (uint32_t root_sign = 0; root_sign < 2; root_sign++) {
      const Lit root = make_lit(root_var, root_sign != 0);
      if (node[root].dfs != 0 || !active(root))
        continue;
      node[root].dfs = node[root].low = next++;
      const uint32_t mark_root = node[root].dfs;
      bool failed_root = false;
      tstack.push_back(root);
      charge(1 + kernel_cache_lines(k.watches.size(negate(root))));
      work.push_back({root, out_edges(root).begin()});

      while (!work.empty()) {
        const Lit v = work.back().v;
        const WatchIter e = out_edges(v).end();
        WatchIter it = work.back().it;
        bool descended = false;
        for (; it != e; ++it) {
          const WatchEntry w = *it;
          if (!w.binary())
            continue;
          const Lit q = w.other();
          if (!active(q))
            continue; // edge into a root-fixed literal: not a node
          if (node[q].dfs == 0) {
            // tree edge: save v's resume point (past this edge), descend into q
            work.back().it = ++it;
            node[q].dfs = node[q].low = next++;
            tstack.push_back(q);
            charge(1 + kernel_cache_lines(k.watches.size(negate(q))));
            // may reallocate `work`; touch it no more
            work.push_back({q, out_edges(q).begin()});
            descended = true;
            break;
          }
          // `repr` is written exactly when a component leaves Tarjan's stack,
          // so a visited literal with no representative is still on-stack.
          // Reusing that output state avoids a dense byte per literal without
          // changing DFS order or the low-link recurrence.
          if (res.repr[q] == INVALID_LIT && node[q].dfs < node[v].low)
            node[v].low = node[q].dfs; // frond to an on-stack node
        }
        if (descended)
          continue;
        work.back().it = it;

        // Kissat's iterative DFS rescans a finished literal's watch list to
        // fold its reach value (substitute.c, the INVALID_LIT pop branch) and
        // charges that second scan's cache lines as well.  Tarjan folds the
        // low-link during the single scan above; charge the reference's
        // second scan so the round's substitute_ticks, and with them the
        // 10-per-mille second-round test, match kissat's.
        charge(1 + kernel_cache_lines(k.watches.size(negate(v))));
        if (node[v].low == node[v].dfs) {
          // v roots an SCC: pop the component off tstack
          size_t start = tstack.size();
          do {
            --start;
          } while (tstack[start] != v);
          Lit rep = tstack[start];
          uint64_t rep_order = kernel_import_lit_order(k, rep);
          for (size_t i = start + 1; i < tstack.size(); i++) {
            const uint64_t order = kernel_import_lit_order(k, tstack[i]);
            if (order < rep_order) {
              rep = tstack[i];
              rep_order = order;
            }
          }
          const size_t members = tstack.size() - start;
          for (size_t i = start; i < tstack.size(); i++) {
            const Lit m = tstack[i];
            res.repr[m] = rep;
          }
          if (members > 1) {
            res.nontrivial_count++;
            if (collect_instances)
              res.nontrivial_reps.push_back(rep);
          }
          for (size_t i = start; i < tstack.size(); i++) {
            const Lit m = tstack[i];
            const Lit mirror_rep = res.repr[negate(m)];
            if (mirror_rep == rep) { // l and ¬l share the SCC
              res.contradiction = true;
              if (res.contradiction_lit == INVALID_LIT)
                res.contradiction_lit = m; // x with ¬x in this SCC
              break;
            }
            // If the mirror SCC was completed during this root's DFS, root
            // reaches both m and ¬m.  Thus root is failed and ¬root is a
            // unit.  Kissat records at most one such witness per DFS root.
            if (!failed_root && mirror_rep != INVALID_LIT &&
                node[negate(m)].dfs >= mark_root) {
              res.failed_units.push_back(negate(root));
              res.failed_witness.push_back(m);
              failed_root = true;
            }
          }
          tstack.resize(start);
        }

        // return from v to its parent: fold v's low-link up, then pop v
        const Lit done = v;
        work.pop_back();
        if (!work.empty()) {
          const Lit parent = work.back().v;
          if (node[done].low < node[parent].low)
            node[parent].low = node[done].low;
        }
      }
    }
  }
  if (collect_instances)
    std::sort(res.nontrivial_reps.begin(), res.nontrivial_reps.end(),
              [&](Lit a, Lit b) {
                return kernel_import_lit_order(k, a) <
                       kernel_import_lit_order(k, b);
              });
  substitute_stage_trace(k, "scc-complete", res.nontrivial_count,
                         res.failed_units.size(), tstack.capacity());
  return res;
}

// One directed implication chain `from -> ... -> to` as clause ids in forward
// order (LRAT only; the caller guards on k.proof->lrat()). An edge p -> q is
// the clause (¬p ∨ q). A root-true intermediate is entered through its proved
// unit id instead of an edge; this keeps Congruence bridges total after root
// propagation has removed that literal from the active BIG. Root-false nodes
// cannot extend a propagation chain. Returns false if no chain exists, which
// never happens for two active members of one SCC but keeps direct calls total.
//
// Chain order is load-bearing: for the RUP unit {to} the checker assumes the
// path's start literal true and unit-propagates the edges in order, so edge
// (¬p ∨ q) with p true forces q. A shuffled chain leaves a hint non-unit and
// the checker rejects.
bool big_path_chain(const Kernel &k, Lit from, Lit to,
                    std::vector<uint64_t> &chain) {
  const Lit nlits = static_cast<Lit>(2 * k.nvars);
  // Persistent scratch: three fill-initialized O(nlits) vectors here meant one
  // large memset per bridge, the per-call linear-scratch hazard.
  // parent/parent_edge need no clearing — they are read only behind the `seen`
  // guard and every marked literal writes both first — and `seen` restores
  // all-zero in O(marked), since every marked literal is queued except `to`.
  static thread_local std::vector<Lit> parent;
  static thread_local std::vector<uint64_t> parent_edge;
  static thread_local std::vector<uint8_t> seen;
  static thread_local std::vector<Lit> queue;
  if (seen.size() < static_cast<size_t>(nlits)) {
    parent.resize(nlits);
    parent_edge.resize(nlits);
    seen.resize(nlits, 0);
  }
  queue.clear();
  queue.push_back(from);
  seen[from] = 1;
  bool found = false;
  for (size_t qi = 0; qi < queue.size() && !found; qi++) {
    const Lit cur = queue[qi];
    const Lit nl = negate(cur); // edges cur -> q are the binary watches of ¬cur
    for (const WatchEntry w : k.watches.entries(nl)) {
      if (!w.binary())
        continue;
      const Lit q = w.other();
      if (k.values[q] < 0 || kernel_var_retired(k, var_of(q)) || seen[q])
        continue;
      seen[q] = 1;
      parent[q] = cur;
      if (k.values[q] > 0) {
        const uint64_t unit_id = k.unit_ids[var_of(q)];
        if (!unit_id) {
          seen[q] = 0;
          continue;
        }
        parent_edge[q] = unit_id;
      } else
        parent_edge[q] =
            kernel_binary_id(k, nl, q); // clause (¬cur ∨ q) = cur->q
      if (q == to) {
        found = true;
        break;
      }
      queue.push_back(q);
    }
  }
  const auto restore_seen = [&] {
    for (const Lit l : queue)
      seen[l] = 0;
    seen[to] = 0; // marked without being queued when found
  };
  if (!found) {
    restore_seen();
    return false;
  }
  chain.clear();
  for (Lit cur = to; cur != from; cur = parent[cur])
    chain.push_back(parent_edge[cur]);
  std::reverse(chain.begin(), chain.end());
  restore_seen();
  return true;
}

namespace {

// x ≡ ¬x: emit the refutation (`docs/calculus.md` V3).
// {¬x} is RUP (assume x; the path x -> ¬x propagates ¬x) and {x} likewise via
// ¬x -> x, and the two resolve to the empty clause. Uses add_rup rather than
// add_derived_unit, which emits nothing in DRAT, because these are
// failed-literal units the DRAT checker must see. Self-contained: not M1's.
void emit_unsat(Kernel &k, Lit x) {
  const bool lrat = k.proof && k.proof->lrat();
  const Lit nx = negate(x);
  std::vector<uint64_t> chain_nx, chain_x;
  if (lrat) {
    // {¬x}: chain = path x -> ¬x; {x}: chain = path ¬x -> x
    const bool ok1 = big_path_chain(k, x, nx, chain_nx);
    const bool ok2 = big_path_chain(k, nx, x, chain_x);
    assert(ok1 && ok2 && "x≡¬x SCC must have both directed paths");
    (void)ok1;
    (void)ok2;
  }
  const uint64_t id_nx = ++k.next_clause_id;
  const uint64_t id_x = ++k.next_clause_id;
  const uint64_t id_e = ++k.next_clause_id;
  if (k.proof) {
    k.proof->add_rup(id_nx, &nx, 1, chain_nx.data(),
                     static_cast<uint32_t>(chain_nx.size()));
    k.proof->add_rup(id_x, &x, 1, chain_x.data(),
                     static_cast<uint32_t>(chain_x.size()));
    const uint64_t empty_chain[2] = {id_nx, id_x};
    k.proof->add_empty(id_e, empty_chain, 2);
  }
  k.inconsistent = true;
}

// Emit and close the failed-root units discovered as a by-product of the SCC
// DFS. For unit ¬root, assuming root follows two binary implication paths to
// witness and ¬witness. Concatenating those paths is therefore an LRAT RUP
// chain; DRAT needs no explicit antecedents. All proof lines are emitted before
// assignments so every path is read from the same active graph.
ApplyResult apply_failed_root_units(Kernel &k, const SccResult &r) {
  if (r.failed_units.empty())
    return ApplyResult::NoOp;
  const bool lrat = k.proof && k.proof->lrat();
  PendingUnits pending;
  pending.init(k);
  std::vector<uint64_t> first, second, chain;
  std::unordered_set<uint64_t> seen_ids;
  for (size_t pos = r.failed_units.size(); pos-- > 0;) {
    const Lit unit = r.failed_units[pos]; // reference pops its unit stack
    if (k.value(unit) > 0)
      continue;
    assert(k.value(unit) == 0 && "failed DFS roots are active at discovery");
    chain.clear();
    if (lrat) {
      const Lit root = negate(unit), witness = r.failed_witness[pos];
      first.clear();
      second.clear();
      const bool first_ok =
          root == witness || big_path_chain(k, root, witness, first);
      const bool second_ok = root == negate(witness) ||
                             big_path_chain(k, root, negate(witness), second);
      assert(first_ok && second_ok &&
             "failed-root witness must have both implication paths");
      if (!first_ok || !second_ok)
        continue;
      seen_ids.clear();
      for (const uint64_t id : first)
        if (seen_ids.insert(id).second)
          chain.push_back(id);
      for (const uint64_t id : second)
        if (seen_ids.insert(id).second)
          chain.push_back(id);
    }
    const uint64_t id = ++k.next_clause_id;
    if (k.proof)
      k.proof->add_rup(lrat ? id : 0, &unit, 1,
                       lrat ? chain.data() : nullptr,
                       lrat ? static_cast<uint32_t>(chain.size()) : 0);
    if (pending.record(k, unit, id) == PendingUnits::Outcome::Refuted)
      return ApplyResult::Unsat;
  }
  for (const Lit unit : pending.units) {
    if (k.value(unit) > 0)
      continue;
    if (k.value(unit) < 0) {
      pending.refute(k, unit); // the preceding propagation already refuted
      return ApplyResult::Unsat;
    }
    pending.commit(k, unit);
    kernel_assign_unit(k, unit);
    if (inprocess_reach_root(k))
      return ApplyResult::Unsat;
  }
  return pending.units.empty() ? ApplyResult::NoOp : ApplyResult::Ok;
}

// The equivalent-literal rewrite. `sub[l]` marks the non-representative
// SCC-member literals to rewrite (l → r.repr[l]); the caller selects them, as
// the whole round or as one requested SCC plus its mirror. Emits the transient
// equivalence lemmas {¬l, r.repr[l]}, rewrites every large and binary
// occurrence add-before-delete, deletes the lemmas, pushes the reconstruction
// witnesses once per substituted variable, and asserts any collapsed root units
// un-propagated (M1 owns the cascade, the Probe/Vivify batch discipline).
// Returns Unsat on an empty rewrite, Ok if anything changed, NoOp otherwise.

// Members still eligible for proof-equivalence lemmas and variable retirement.
// Root-fixed or retired members have left the active implication graph and are
// declined here, matching Kissat's `add_representative_equivalences`. The full
// frozen SCC map remains separately authoritative for physical clause rewrite.
inline bool substitution_member_live(const Kernel &k,
                                     const std::vector<uint8_t> &members,
                                     Lit l) {
  return l < members.size() && members[l] && k.values[l] == 0 &&
         !kernel_var_retired(k, var_of(l));
}

} // namespace

// The ledger slot naming `ref` in `lit`'s stream, or null when the session never
// indexed it. Callers must test the result before writing through it: the
// ledger is maintained by this session alone, so a failed lookup is a session
// invariant violation, and `erase(end())` or `erase(begin() - 1)` would
// memmove outside the allocation and turn that slip into heap corruption far
// from its cause. The stream must already be
// materialized (`prime_large`): building it here would read the watches and
// `Kernel::dense` after the kernel's rewrite, where the source is garbage,
// unindexed, or already shadowed by its binary image.
SweepSubstitutionSession::DenseOccurrence *
SweepSubstitutionSession::find_large(const Kernel &k, Lit lit, Ref ref) {
  if (!dense_enabled)
    return nullptr;
  const auto found = dense_occurrences.find(lit);
  assert(found != dense_occurrences.end() && found->second.initialized &&
         "sweep ledger stream materialized after the kernel rewrite");
  if (found == dense_occurrences.end() || !found->second.initialized)
    return nullptr;
  std::vector<DenseOccurrence> &ordered = occurrences(k, lit);
  for (DenseOccurrence &occurrence : ordered)
    if (!occurrence.binary && occurrence.payload == ref)
      return &occurrence;
  assert(false && "sweep ledger lost a large occurrence");
  return nullptr;
}

void SweepSubstitutionSession::erase_large(const Kernel &k, Lit lit, Ref ref) {
  DenseOccurrence *const at = find_large(k, lit, ref);
  if (!at)
    return;
  std::vector<DenseOccurrence> &ordered = dense_occurrences[lit].entries;
  ordered.erase(ordered.begin() + (at - ordered.data()));
}

void SweepSubstitutionSession::begin(const Kernel &k) {
  changed = false;
  reset_transaction();
  for (const Lit lit : dense_initialized_lits) {
    DenseOccurrenceList &list = dense_occurrences[lit];
    list.entries.clear();
    list.initialized = false;
  }
  dense_initialized_lits.clear();
  for (const Lit lit : ledger_dirty)
    ledger_dirty_mark[lit] = 0;
  ledger_dirty.clear();
  dirty_binary_owners.clear();
  dense_enabled = k.dense;
}

// One scan of each distinct owner's binary prefix answers every image that
// pushes onto it. Scanning per image instead costs the owner's degree each
// time, and a substituted class sends every retired literal's binaries to the
// same representative, so that degree is the number of images already done.
void SweepSubstitutionSession::classify_existing_binaries(
    const Kernel &k, const std::vector<Lit> &owners,
    const std::vector<Lit> &others, std::vector<uint8_t> &out) {
  const size_t n = owners.size();
  out.assign(n, 0);
  if (!n)
    return;
  const size_t nlits = 2 * static_cast<size_t>(k.nvars);
  if (live_epoch.size() < nlits)
    live_epoch.resize(nlits, 0);
  std::vector<uint32_t> order(n);
  for (size_t i = 0; i < n; i++)
    order[i] = static_cast<uint32_t>(i);
  std::sort(order.begin(), order.end(), [&](uint32_t a, uint32_t b) {
    return owners[a] < owners[b];
  });
  size_t at = 0;
  while (at < n) {
    const Lit owner = owners[order[at]];
    size_t end = at;
    while (end < n && owners[order[end]] == owner)
      end++;
    if (++live_generation == 0) {
      std::fill(live_epoch.begin(), live_epoch.end(), 0);
      live_generation = 1;
    }
    const bool stop_at_large = k.watches.heads[owner].binaries_first();
    for (const WatchEntry w : k.watches.entries(owner)) {
      if (!w.binary()) {
        if (stop_at_large)
          break;
        continue;
      }
      live_epoch[w.other()] = live_generation;
    }
    for (size_t i = at; i < end; i++) {
      const uint32_t image = order[i];
      out[image] =
          static_cast<uint8_t>(live_epoch[others[image]] == live_generation);
    }
    at = end;
  }
}

void SweepSubstitutionSession::mark_ledger_dirty(Lit lit) {
  if (ledger_dirty_mark.size() <= lit)
    ledger_dirty_mark.resize(static_cast<size_t>(lit) + 1, 0);
  if (ledger_dirty_mark[lit])
    return;
  ledger_dirty_mark[lit] = 1;
  ledger_dirty.push_back(lit);
}

std::vector<SweepSubstitutionSession::DenseOccurrence> &
SweepSubstitutionSession::occurrences(const Kernel &k, Lit lit) {
  assert(dense_enabled && k.dense);
  assert(lit < 2 * static_cast<size_t>(k.nvars));
  mark_ledger_dirty(lit);
  DenseOccurrenceList &list = dense_occurrences[lit];
  std::vector<DenseOccurrence> &ordered = list.entries;
  if (list.initialized)
    return ordered;
  assert(ordered.empty());
  list.initialized = true;
  dense_initialized_lits.push_back(lit);
  ordered.reserve(k.watches.size(lit) + k.dense->large_size(lit));
  if (k.dense->track_order) {
    // Eliminate already owns the exact mixed connected stream.  Reusing it is
    // essential when a free N1 schedule runs Sweep/Substitute and BVE in one
    // dense scope: rebuilding a binary-prefix/large-suffix approximation here
    // loses the in-place and delayed positions this session exists to retain.
    for (const OccIndex::Entry occurrence : k.dense->ordered[lit]) {
      if (occurrence.binary) {
        ordered.push_back({true, occurrence.payload});
#ifdef TACTIX_ENABLE_EVENT_TRACE
        event_trace_binary_lifecycle(k, "sweep-ledger-begin", lit,
                                     occurrence.payload, 0, 0);
#endif
        continue;
      }
      const Clause *clause = clause_at(k.arena, occurrence.payload);
      if (clause->garbage() || clause->redundant() ||
          std::find(clause->begin(), clause->end(), lit) == clause->end())
        continue;
      ordered.push_back({false, occurrence.payload});
    }
  } else {
    for (const WatchEntry watch : k.watches.entries(lit))
      if (watch.binary()) {
        ordered.push_back({true, watch.other()});
#ifdef TACTIX_ENABLE_EVENT_TRACE
        event_trace_binary_lifecycle(k, "sweep-ledger-begin", lit,
                                     watch.other(), 0, 0);
#endif
      }
    for (const Ref ref : k.dense->large[lit]) {
      const Clause *clause = clause_at(k.arena, ref);
      if (!clause->garbage() && !clause->redundant())
        ordered.push_back({false, ref});
    }
  }
  return ordered;
}

void SweepSubstitutionSession::publish_dense_order(Kernel &k,
                                                   const std::vector<Lit> &lits) {
  if (!dense_enabled || !k.dense || !k.dense->track_order)
    return;
  assert(!k.bve_occurrence_count_image);
  for (const Lit lit : lits) {
    const DenseOccurrenceList &source = dense_occurrences[lit];
    assert(source.initialized);
    k.dense->ordered.clear(lit);
    for (const DenseOccurrence occurrence : source.entries) {
      if (occurrence.binary) {
        k.dense->ordered.push(lit, OccIndex::Entry::from_binary(
                                       static_cast<Lit>(occurrence.payload)));
      } else {
        const Ref ref = static_cast<Ref>(occurrence.payload);
        k.dense->ordered.push(lit, OccIndex::Entry::from_large(ref));
      }
    }
  }
}

void SweepSubstitutionSession::prime_equivalence(const Kernel &k, Lit a,
                                                  Lit b) {
  if (!dense_enabled)
    return;
  for (const Lit lit : {a, negate(a), b, negate(b)})
    (void)occurrences(k, lit);
}

// Debug oracle for the incremental publication above: the dense index must
// hold exactly what republishing every initialized stream would write. A
// stream mutated outside `occurrences` would escape the dirty set and leave a
// stale ordering for the next environment, which is invisible in a release
// build until a much later divergence.
bool SweepSubstitutionSession::sync_publication_is_complete(const Kernel &k) {
  if (!dense_enabled || !k.dense || !k.dense->track_order)
    return true;
  for (const Lit lit : dense_initialized_lits) {
    const DenseOccurrenceList &source = dense_occurrences[lit];
    const auto published = k.dense->ordered[lit];
    const auto large = k.dense->ordered.large_refs(lit);
    auto next_large = large.begin();
    size_t at = 0, at_large = 0;
    for (const DenseOccurrence occurrence : source.entries) {
      if (at == published.size())
        return false;
      const OccIndex::Entry &entry = published[at++];
      if (entry.binary != occurrence.binary ||
          entry.payload != occurrence.payload)
        return false;
      if (!occurrence.binary) {
        if (next_large == large.end() ||
            *next_large++ != static_cast<Ref>(occurrence.payload))
          return false;
        ++at_large;
      }
    }
    if (at != published.size() || at_large != large.size() ||
        next_large != large.end())
      return false;
  }
  return true;
}

void SweepSubstitutionSession::sync_new_binaries(
    Kernel &k,
    const std::vector<std::pair<Lit, Lit>> &equivalences) {
  if (!dense_enabled) {
    dirty_binary_owners.clear(); // no ledger to re-pose; end the transaction
    return;
  }
  // A dirty owner's binary substream is the transaction's prediction of the
  // physical rewrite, and the physical outcome may supersede it.  Only for
  // such an owner is a ledger-only binary an expected residue; everywhere
  // else it is a producer that bypassed the session.
  std::sort(dirty_binary_owners.begin(), dirty_binary_owners.end());
  dirty_binary_owners.erase(
      std::unique(dirty_binary_owners.begin(), dirty_binary_owners.end()),
      dirty_binary_owners.end());
  const auto dirty = [&](Lit lit) {
    return std::binary_search(dirty_binary_owners.begin(),
                              dirty_binary_owners.end(), lit);
  };
  (void)dirty; // assertion-only in release builds
  std::vector<Lit> touched;
  touched.reserve(4 * equivalences.size() + dirty_binary_owners.size() +
                  ledger_dirty.size());
  for (const auto &eq : equivalences)
    touched.insert(touched.end(),
                   {eq.first, negate(eq.first), eq.second, negate(eq.second)});
  touched.insert(touched.end(), dirty_binary_owners.begin(),
                 dirty_binary_owners.end());
  if (k.dense->track_order)
    touched.insert(touched.end(), ledger_dirty.begin(), ledger_dirty.end());
  std::sort(touched.begin(), touched.end());
  touched.erase(std::unique(touched.begin(), touched.end()), touched.end());
  // Mutation provenance already marks both the source owner and the target
  // owner of every move, each owner rewritten in place, and both endpoints of
  // every large-to-binary collapse. Expanding once more through all of their
  // neighbors is therefore redundant and can turn a local equivalence into a
  // near-whole-formula scan on a high-degree graph.
  for (const Lit lit : touched) {
    assert(lit < 2 * static_cast<size_t>(k.nvars));
    // The watch lists are the authority on which binaries exist; the ledger
    // only adds Kissat's dense stream order on top of them. Reconcile both
    // directions so the two agree exactly afterwards. The physical sub-list can
    // be permuted relative to the ledger by a prior inline substitution, so
    // match the multiset rather than a prefix.
    const size_t nlits = 2 * static_cast<size_t>(k.nvars);
    if (sync_epoch.size() < nlits) {
      sync_epoch.resize(nlits, 0);
      sync_count.resize(nlits, 0);
    }
    if (++sync_generation == 0) {
      std::fill(sync_epoch.begin(), sync_epoch.end(), 0);
      sync_generation = 1;
    }
    sync_touched.clear();
    std::vector<DenseOccurrence> &stream = occurrences(k, lit);
    size_t stale = 0;
    for (const DenseOccurrence occurrence : stream)
      if (occurrence.binary) {
        const Lit other = static_cast<Lit>(occurrence.payload);
        if (sync_epoch[other] != sync_generation) {
          sync_epoch[other] = sync_generation;
          sync_count[other] = 0;
          sync_touched.push_back(other);
          stale++;
        }
        sync_count[other]++;
      }
    for (const WatchEntry watch : k.watches.entries(lit)) {
      if (!watch.binary())
        continue;
      const Lit other = watch.other();
      if (sync_epoch[other] == sync_generation && sync_count[other]) {
        if (!--sync_count[other])
          stale--;
        continue;
      }
      // Only unmatched watches are new, in the creation order observed here.
      stream.push_back({true, watch.other()});
#ifdef TACTIX_ENABLE_EVENT_TRACE
      event_trace_binary_lifecycle(
          k, "sweep-ledger-adopt", lit, watch.other(),
          kernel_binary_id(k, lit, watch.other()), 1);
#endif
    }
    // Every producer of a binary updates this ledger, so on a stream the
    // transaction never mutated nothing may be left: a residue there means a
    // binary was published behind the session's back.  On a dirty stream the
    // residue is the superseded prediction.  Either way purge it rather than
    // let a phantom clause reach a later environment, since the ledger must
    // not claim a clause the formula no longer contains.
    assert((!stale || dirty(lit)) &&
           "sweep ledger holds a binary absent from the watches");
    if (stale) {
#ifdef TACTIX_ENABLE_EVENT_TRACE
      for (const Lit other : sync_touched)
        if (sync_count[other])
          event_trace_binary_lifecycle(
              k, "sweep-ledger-purge", lit, other,
              kernel_binary_id(k, lit, other),
              static_cast<uint32_t>(
                  std::min(sync_count[other], size_t{UINT32_MAX})));
#endif
      purge_stale_binaries(lit);
    }
    // Propagation reads physical watches, not the environment ledger. Publish
    // the same binary order to both consumers after reconciling membership.
    // Only permute binary words: large watches, counts, proof identities and
    // capacities stay unchanged, and no allocation can invalidate this slice.
    auto next_binary = stream.begin();
    uint32_t *word = k.watches.begin(lit);
    const uint32_t *const end = k.watches.end(lit);
    while (word != end) {
      const Watch watch{*word};
      if (!watch.binary()) {
        word += 2;
        continue;
      }
      while (next_binary != stream.end() && !next_binary->binary)
        ++next_binary;
      assert(next_binary != stream.end());
      *word++ = binary_watch(static_cast<Lit>(next_binary->payload)).raw;
      ++next_binary;
    }
    while (next_binary != stream.end() && !next_binary->binary)
      ++next_binary;
    assert(next_binary == stream.end());
  }
  publish_dense_order(k, touched);
  // Every stream this batch could have changed has been reconciled and
  // republished, so the next batch starts from an empty changed set.
  for (const Lit lit : ledger_dirty)
    ledger_dirty_mark[lit] = 0;
  ledger_dirty.clear();
  assert(sync_publication_is_complete(k) &&
         "a ledger stream changed outside the reconciled set");
  dirty_binary_owners.clear();
}

void SweepSubstitutionSession::repose_emitted_equivalence(
    const Kernel &k, Lit a, Lit b) {
  if (!dense_enabled)
    return;
  const auto repose = [&](Lit owner, Lit other) {
    auto &stream = occurrences(k, owner);
    for (size_t i = stream.size(); i; --i) {
      const auto entry = stream[i - 1];
      if (!entry.binary || entry.payload != other)
        continue;
      std::rotate(stream.begin() + (i - 1), stream.begin() + i, stream.end());
      break;
    }
  };
  repose(negate(a), b);
  repose(b, negate(a));
  repose(a, negate(b));
  repose(negate(b), a);
}

void SweepSubstitutionSession::purge_stale_binaries(Lit lit) {
  std::vector<DenseOccurrence> &ordered = dense_occurrences[lit].entries;
  size_t kept = 0;
  for (const DenseOccurrence occurrence : ordered) {
    if (occurrence.binary) {
      const Lit other = static_cast<Lit>(occurrence.payload);
      if (sync_epoch[other] == sync_generation && sync_count[other]) {
        sync_count[other]--;
        continue;
      }
    }
    ordered[kept++] = occurrence;
  }
  ordered.resize(kept);
}

void SweepSubstitutionSession::reset_transaction() {
  delayed_moves.clear();
  retiring.clear();
  retiring_repr.clear();
  retiring_rank.clear();
  retiring_position.clear();
  equivalence_bridges.clear();
}

// A retiring literal's large occurrences move with its binaries, but only the
// clause rewrite knows what each one became, so the stream index is stored
// under the pair that identifies it while the stream is still intact.
static uint64_t sweep_stream_key(Lit lit, Ref source) {
  return (static_cast<uint64_t>(lit) << 32) | source;
}

// The retiring literal whose stream releases this clause to `representative`.
// Kissat introduces a representative into a clause during the first
// `substitute_connected_clauses` call that rewrites one of the clause's own
// literals to it; every later call for the same clause finds it already
// watched and appends nothing. Tactix rewrites the whole class at once, so
// pick that same first call: the lowest-ranked retiring member of the source
// clause whose representative is this one.
bool SweepSubstitutionSession::move_origin(const Clause &old,
                                           Lit representative, Ref source,
                                           bool final_binary,
                                           uint32_t &rank,
                                           uint32_t &position) const {
  rank = UINT32_MAX;
  for (const Lit lit : old) {
    const auto found = retiring_rank.find(lit);
    if (found == retiring_rank.end() ||
        retiring_repr[found->second] != representative)
      continue;
    // A surviving large occurrence is appended by the first retiring member
    // that introduces the representative.  If later members of the same
    // clause retire, Kissat sees the representative already watched and keeps
    // that first position.  A final binary has the opposite owner: it is born
    // only when the last duplicate is removed and the large clause reaches
    // size two, so it belongs to the latest retiring member's mixed stream.
    // The distinction is representation semantics, independent of Sweep's
    // caller-owned effort or cadence.
    if (rank == UINT32_MAX ||
        (final_binary ? found->second > rank : found->second < rank))
      rank = found->second;
  }
  if (rank == UINT32_MAX)
    return false;
  const auto at = retiring_position.find(sweep_stream_key(retiring[rank],
                                                          source));
  // A redundant source clause never entered the dense stream, so its collapse
  // has no recorded position; it follows that literal's other occurrences.
  position = at == retiring_position.end() ? UINT32_MAX : at->second;
  return true;
}

void SweepSubstitutionSession::push_move(const Kernel &k, const Clause &old,
                                         Lit representative, Ref source,
                                         DenseOccurrence image) {
  if (image.binary)
    dirty_binary_owners.push_back(representative);
  uint32_t rank = 0, position = 0;
  if (move_origin(old, representative, source, image.binary, rank, position))
    delayed_moves.push_back({representative, rank, position, image});
  else
    occurrences(k, representative).push_back(image);
}

void SweepSubstitutionSession::rewrite_binary_occurrences(
    const Kernel &k, const std::vector<std::pair<Lit, Lit>> &map,
    const std::vector<Lit> &sources,
    const std::vector<EquivalenceBridge> &bridges) {
  reset_transaction();
  for (const EquivalenceBridge &bridge : bridges) {
    assert(bridge.a != INVALID_LIT && bridge.b != INVALID_LIT &&
           bridge.target_a != INVALID_LIT && bridge.target_b != INVALID_LIT);
    assert(bridge.target_a != bridge.target_b &&
           bridge.target_a != negate(bridge.target_b));
    equivalence_bridges.emplace(kernel_binary_key(bridge.a, bridge.b),
                                bridge);
  }
  dirty_binary_owners.clear();
  // Ask the rewrite's own member question rather than the requested class map:
  // a member already root-fixed or retired is declined by `do_substitution`,
  // and mirroring it here would move ledger entries the watch lists keep.
  const auto requested_image = [&](Lit l) {
    const auto it = std::lower_bound(
        map.begin(), map.end(), l,
        [](const std::pair<Lit, Lit> &entry, Lit needle) {
          return entry.first < needle;
        });
    return it != map.end() && it->first == l ? it->second : l;
  };
  const auto member_live = [&](Lit l) {
    return requested_image(l) != l && k.values[l] == 0 &&
           !kernel_var_retired(k, var_of(l));
  };
  // The retiring list is the transaction's membership, not a view of the dense
  // ledger: `do_substitution` reads it to decide which watch lists to snapshot
  // before it drops every binary incident to a retiring literal. Record it even
  // when this session holds no ledger (Sweep with the dense occurrence index
  // disconnected), or that rewrite loses each mirror while the opposite
  // direction survives in place, leaving a half-watched clause that still
  // propagates but has no proof identity.
  for (const Lit source : sources) {
    if (!member_live(source))
      continue; // declined here exactly as the rewrite declines it
    if (retiring_rank.emplace(source,
                              static_cast<uint32_t>(retiring.size())).second) {
      retiring.push_back(source);
      retiring_repr.push_back(requested_image(source));
    }
  }
  if (!dense_enabled)
    return; // no dense stream to re-pose; the membership above still stands
  // A binary changes iff at least one endpoint retires.  The retiring owner's
  // directed stream names every opposite endpoint, hence the exact set of
  // directed owners whose entries can change is {retiring literals} union
  // {their binary neighbors}. Kissat walks precisely these connected streams;
  // scanning every imported literal here made each productive Sweep seed
  // O(F) even though the semantic transaction was local.
  std::vector<Lit> affected_owners;
  for (const Lit source : retiring) {
    affected_owners.push_back(source);
    for (const DenseOccurrence occurrence : occurrences(k, source))
      if (occurrence.binary)
        affected_owners.push_back(static_cast<Lit>(occurrence.payload));
  }
  std::sort(affected_owners.begin(), affected_owners.end(),
            [&](Lit a, Lit b) {
              const uint64_t oa = kernel_import_lit_order(k, a);
              const uint64_t ob = kernel_import_lit_order(k, b);
              return oa != ob ? oa < ob : a < b;
            });
  affected_owners.erase(
      std::unique(affected_owners.begin(), affected_owners.end()),
      affected_owners.end());
  for (const Lit owner : affected_owners) {
    const auto rank = retiring_rank.find(owner);
    const bool retires = rank != retiring_rank.end();
    std::vector<DenseOccurrence> &ordered = occurrences(k, owner);
    size_t kept = 0;
    for (size_t at = 0; at < ordered.size(); at++) {
      DenseOccurrence occurrence = ordered[at];
      if (!occurrence.binary) {
        if (retires)
          retiring_position.emplace(
              sweep_stream_key(owner, static_cast<Ref>(occurrence.payload)),
              static_cast<uint32_t>(at));
        ordered[kept++] = occurrence;
        continue;
      }
      const Lit other = static_cast<Lit>(occurrence.payload);
      Lit target_owner, target_other;
      if (!equivalence_bridge_targets(owner, other, &target_owner,
                                      &target_other)) {
        target_owner = member_live(owner) ? requested_image(owner) : owner;
        target_other = member_live(other) ? requested_image(other) : other;
      }
      if (target_owner == target_other ||
          target_owner == negate(target_other)) {
        // This directed occurrence is actually removed. Identity entries
        // are intentionally not dirty: marking every binary merely because
        // the transaction visited it turns a local reconciliation into a
        // whole-formula scan after every productive Sweep seed.
        dirty_binary_owners.push_back(owner);
#ifdef TACTIX_ENABLE_EVENT_TRACE
        event_trace_binary_lifecycle(
            k, "sweep-ledger-drop", owner, other,
            kernel_binary_id(k, owner, other),
            kernel_binary_copies(k, owner, other));
#endif
        continue;
      }
      if (target_owner == owner) {
        if (target_other != other) {
          dirty_binary_owners.push_back(owner);
#ifdef TACTIX_ENABLE_EVENT_TRACE
          event_trace_binary_lifecycle(
              k, "sweep-ledger-rewrite", owner, other,
              kernel_binary_id(k, owner, other),
              kernel_binary_copies(k, owner, other));
          event_trace_binary_lifecycle(k, "sweep-ledger-target", owner,
                                       target_other, 0, 0);
#endif
        }
        occurrence.payload = target_other;
        ordered[kept++] = occurrence;
      } else {
        // Every literal the rewrite retires lost exactly one merge, so the
        // caller's source list names it. Keep an unranked move reachable
        // rather than dropping it: membership is the ledger's contract and
        // order is only the pose.
        assert(retires && "sweep ledger moved an unranked source stream");
        dirty_binary_owners.push_back(owner);
        dirty_binary_owners.push_back(target_owner);
#ifdef TACTIX_ENABLE_EVENT_TRACE
        event_trace_binary_lifecycle(
            k, "sweep-ledger-move", owner, other,
            kernel_binary_id(k, owner, other),
            kernel_binary_copies(k, owner, other));
        event_trace_binary_lifecycle(k, "sweep-ledger-target", target_owner,
                                     target_other, 0, 0);
#endif
        delayed_moves.push_back({target_owner,
                                 retires ? rank->second : UINT32_MAX,
                                 static_cast<uint32_t>(at),
                                 {true, target_other}});
      }
    }
    ordered.resize(kept);
  }
}

bool SweepSubstitutionSession::substitutes(Lit lit) const {
  return retiring_rank.find(lit) != retiring_rank.end();
}

uint32_t SweepSubstitutionSession::retiring_index(Lit lit) const {
  const auto it = retiring_rank.find(lit);
  assert(it != retiring_rank.end());
  return it->second;
}

Lit SweepSubstitutionSession::representative(Lit lit) const {
  const auto it = retiring_rank.find(lit);
  return it == retiring_rank.end() ? lit : retiring_repr[it->second];
}

bool SweepSubstitutionSession::equivalence_bridge_targets(Lit a, Lit b,
                                                          Lit *target_a,
                                                          Lit *target_b) const {
  const auto found = equivalence_bridges.find(kernel_binary_key(a, b));
  if (found == equivalence_bridges.end())
    return false;
  const EquivalenceBridge &bridge = found->second;
  // The undirected key is injective on literal pairs, so the query names the
  // stored pair; only its orientation can differ.
  if (a == bridge.a) {
    assert(b == bridge.b);
    *target_a = bridge.target_a;
    *target_b = bridge.target_b;
  } else {
    assert(a == bridge.b && b == bridge.a);
    *target_a = bridge.target_b;
    *target_b = bridge.target_a;
  }
  return true;
}

void SweepSubstitutionSession::flush_moves(const Kernel &k) {
#ifndef TACTIX_ENABLE_EVENT_TRACE
  (void)k;
#endif
  // One retiring literal's `delayed` stack is flushed before the next literal
  // is walked, so a representative sees each source's occurrences contiguously
  // and in that source's own encounter order, binaries and large clauses
  // interleaved exactly as the single watch stream met them.
  std::stable_sort(delayed_moves.begin(), delayed_moves.end(),
                   [](const DelayedMove &a, const DelayedMove &b) {
                     if (a.source != b.source)
                       return a.source < b.source;
                     return a.position < b.position;
                   });
  for (const DelayedMove &move : delayed_moves) {
#ifdef TACTIX_ENABLE_EVENT_TRACE
    if (move.source < retiring.size())
      event_trace_sweep_rewrite_occurrence(
          k, retiring[move.source], move.representative, move.position,
          move.image.binary, move.image.payload);
    if (move.image.binary && move.source < retiring.size())
      event_trace_sweep_rewrite_binary(
          k, retiring[move.source], move.representative, move.position,
          static_cast<Lit>(move.image.payload));
#endif
    occurrences(k, move.representative).push_back(move.image);
  }
  reset_transaction();
}

void SweepSubstitutionSession::prime_large(const Kernel &k, Ref source) {
  if (!dense_enabled)
    return;
  const Clause *const old = clause_at(k.arena, source);
  if (old->redundant() || old->garbage())
    return; // dense Sweep indexes live irredundant clauses only
  // Output-sensitive: only a clause the rewrite actually touches reaches
  // here, and each of its literals is materialized at most once per call.
  for (const Lit lit : *old)
    (void)occurrences(k, lit);
}

void SweepSubstitutionSession::remove_large(Kernel &k, Ref source) {
  const Clause *const old = clause_at(k.arena, source);
  if (old->redundant())
    return; // dense Sweep indexes irredundant clauses only
  // Membership leaves every attached kernel view at once (`large` and the
  // mixed stream): the ledger publishes ORDER later, but a kernel primitive
  // locating this literal's next rewrite reads both views before that.
  for (const Lit lit : *old) {
    if (k.dense)
      kernel_dense_remove_large_occurrence(k, lit, source);
    if (dense_enabled)
      erase_large(k, lit, source);
  }
}

void SweepSubstitutionSession::collapse_large_to_binary(Kernel &k, Ref source,
                                                         Lit a, Lit b,
                                                         bool append_a,
                                                         bool append_b) {
  const Clause *const old = clause_at(k.arena, source);
  // Kissat's dense stream holds every binary but only the irredundant large
  // clauses, so a redundant source has no large occurrence to retire — while
  // the binary the kernel just published is a real member of that stream and
  // must still be recorded, or the next environment cannot see the clause.
  const bool indexed = !old->redundant();
  dirty_binary_owners.push_back(a);
  dirty_binary_owners.push_back(b);
#ifdef TACTIX_ENABLE_EVENT_TRACE
  event_trace_binary_lifecycle(k, "sweep-ledger-collapse-target", a, b,
                               kernel_binary_id(k, a, b),
                               kernel_binary_copies(k, a, b));
  event_trace_binary_collapse(k, source, a, b);
#endif
  if (indexed)
    for (const Lit lit : *old) {
      if (k.dense)
        kernel_dense_remove_large_occurrence(k, lit, source);
      if (!dense_enabled)
        continue;
      DenseOccurrence *const at = find_large(k, lit, source);
      if (!at)
        continue;
      // The endpoint the substitution introduced takes Kissat's appended
      // `delayed` watch; the endpoint that survived from the source clause
      // takes its in-place replacement (`kissat_substitute_large_watch`).
      if (lit == a && !append_a)
        *at = {true, b};
      else if (lit == b && !append_b)
        *at = {true, a};
      else {
        std::vector<DenseOccurrence> &ordered = occurrences(k, lit);
        ordered.erase(ordered.begin() + (at - ordered.data()));
      }
    }
  if (!dense_enabled)
    return;
  const auto rewritten_in_place = [&](Lit lit, bool append) {
    if (append || !indexed)
      return false;
    return std::find(old->begin(), old->end(), lit) != old->end();
  };
  if (!rewritten_in_place(a, append_a))
    push_move(k, *old, a, source, {true, b});
  if (!rewritten_in_place(b, append_b))
    push_move(k, *old, b, source, {true, a});
}

void SweepSubstitutionSession::rewrite_large_in_place(const Kernel &k,
                                                       Ref source,
                                                       const Lit *image,
                                                       uint32_t size) {
  const Clause *const old = clause_at(k.arena, source);
  if (old->redundant() || !dense_enabled)
    return;
  // Connected rewrites retain long runs in source order. Keep a private
  // successful-search cursor to avoid rescanning each retained prefix.
  // Wrap on misses so arbitrary images still get exact full-range membership;
  // neither range is mutated while these ledger updates run.
  const auto membership = [](const Lit *begin, const Lit *end) {
    return [begin, end, next = begin](Lit lit) mutable {
      const Lit *found = std::find(next, end, lit);
      if (found == end) {
        found = std::find(begin, next, lit);
        if (found == next)
          return false;
      }
      next = found + 1;
      return true;
    };
  };
  auto image_holds = membership(image, image + size);
  auto source_held = membership(old->begin(), old->end());
  // Only a literal that leaves the image loses its stream slot; a retained
  // literal keeps its entry untouched, so its stream is never searched.
  // Searching every literal made each rewrite cost the sum of all its
  // literals' stream lengths (Rank 22: 270 s in `find_large` at identical
  // Sweep work; see benchmarks/reports/2026-09-02-unit-cost-and-fidelity-stack.md).
  for (const Lit lit : *old) {
    if (image_holds(lit))
      continue;
    DenseOccurrence *const at = find_large(k, lit, source);
    if (!at)
      continue;
    std::vector<DenseOccurrence> &ordered = occurrences(k, lit);
    ordered.erase(ordered.begin() + (at - ordered.data()));
  }
  for (uint32_t i = 0; i < size; i++)
    if (!source_held(image[i]))
      push_move(k, *old, image[i], source, {false, source});
}

uint64_t SweepSubstitutionSession::collect(Kernel &k) {
  // A free N1 schedule can keep Eliminate's ordered image connected while
  // Sweep runs.  Publish even for a semantically NoOp call: lazy garbage
  // cleanup and duplicate compaction are representation changes, and the next
  // BVE/Walk consumer must not inherit the pre-transaction mirrors.
  publish_dense_order(k, dense_initialized_lits);
  if (!changed)
    return 0;
  // Surviving large clauses now keep their Ref and allocation span.  Clauses
  // that collapse or disappear are ordinary lazy garbage, which every arena
  // and watch consumer already skips and a later kernel collection reclaims.
  // Thus Sweep has no representation debt to settle at its call boundary.
  // Keeping this boundary method makes the rule/strategy interface explicit
  // while avoiding a whole-formula compaction that Kissat does not perform.
  (void)k;
  changed = false;
  return 0;
}

namespace {

ApplyResult do_substitution(Kernel &k, SccResult &r,
                            std::vector<uint8_t> &&sub,
                            SweepSubstitutionSession *session = nullptr) {
  const bool lrat = k.proof && k.proof->lrat();
  const Lit nlits = static_cast<Lit>(2 * k.nvars);
  substitute_stage_trace(k, "rewrite-entry", nlits, r.nontrivial_count);
  // Canonical substitution rewrites the stable binary watches in place and
  // appends the retired endpoints' mirrors to their representatives
  // (substitute.c:294-363): wholesale edits of the physical watch lists that
  // bypass the kernel add/delete primitives.  Kissat never substitutes under
  // a dense image, but a free N1 schedule can keep Eliminate's mixed stream
  // attached across this call (random_policy.cpp attaches one for the whole
  // walk), and BVE consumes that stream, so a stale binary entry there is a
  // phantom clause.  Republish the image from the canonical physical result
  // at the rule boundary, the same representation boundary Congruence closes
  // in kernel_canonicalize_binary_watches.  The Sweep session path owns its
  // ledger and republishes per batch; DefaultPolicy attaches the mixed stream
  // only inside Eliminate, where this rule never runs.
  struct RepublishAttachedMixedStream {
    Kernel &k;
    const bool active;
    ~RepublishAttachedMixedStream() {
      if (active)
        kernel_rebuild_dense_occurrences(k);
    }
  } republish{k, !session && k.dense && k.dense->track_order};
  // A member can already be root-fixed here: the caller's map predates the
  // round's failed root units. Kissat skips exactly those when it adds proof
  // equivalences and later retires variables (`add_representative_equivalences`
  // checks ACTIVE), but `substitute_binaries` and `substitute_clauses` still
  // apply the complete immutable representative map. Keep those two concepts
  // separate: `mapped_sub` owns physical rewriting, while `live_sub` owns
  // equivalence lemmas, reconstruction witnesses, and variable retirement.
  // Snapshot, never a live test: the phases below assert units, so a live
  // predicate could hold while (D) rewrites a variable away and fail by the
  // time (F) owes it a witness — retired-without-witness answers a wrong SAT.
  std::vector<uint8_t> mapped_sub;
  std::vector<uint8_t> live_sub;
  if (!session) {
    mapped_sub = std::move(sub);
    live_sub = mapped_sub;
    for (Lit l = 0; l < nlits; l++)
      live_sub[l] =
          static_cast<uint8_t>(substitution_member_live(k, live_sub, l));
  }
  substitute_stage_trace(k, "rewrite-live-sub", live_sub.size(),
                         live_sub.capacity());
  const auto substitutable = [&](Lit l) {
    return session ? session->substitutes(l)
                   : l < nlits && static_cast<bool>(live_sub[l]);
  };
  const auto mapped = [&](Lit l) {
    return session ? session->substitutes(l)
                   : l < nlits && static_cast<bool>(mapped_sub[l]);
  };
  const auto representative = [&](Lit l) {
    return session ? session->representative(l) : r.repr[l];
  };
  // Kissat-style combined substitution image for the non-session path: the
  // literal l maps to its representative if substituted, else to itself
  // (r.repr[] alone is INVALID_LIT for unmapped literals, so the guard is
  // required). The hot rewrite loop reads this single array for `mp` instead of
  // re-evaluating mapped()+representative() -- two lambdas, each a session
  // branch plus bounds check -- per literal (report 3.89). Sweep sessions
  // rewrite a small frontier of a giant formula, so an nlits image is not
  // built for them; they keep the lambda path.
  std::vector<Lit> image;
  if (!session) {
    image.resize(nlits);
    for (Lit l = 0; l < nlits; l++)
      image[l] = static_cast<bool>(mapped_sub[l]) ? r.repr[l] : l;
  }
  const auto for_each_substitutable = [&](const auto &fn) {
    if (session)
      for (const Lit l : session->retiring_sources())
        fn(l);
    else
      for (Lit l = 0; l < nlits; l++)
        if (substitutable(l))
          fn(l);
  };

  // (B) transient equivalence lemmas {¬l, repr[l]}, one per member literal,
  // derived before any binary mutation so big_path_chain reads the intact
  // graph. RUP: assume l, ¬repr[l]; the path l→…→repr[l] forces repr[l].
  // Clause ids are antecedents only in LRAT. DRAT ignores them, so avoid a
  // 16-byte-per-variable zero table on the production proof path.
  std::vector<uint64_t> lemma;
  if (lrat)
    lemma.assign(session ? session->retiring_sources().size() : nlits, 0);
  const auto lemma_index = [&](Lit l) {
    return session ? static_cast<size_t>(session->retiring_index(l))
                   : static_cast<size_t>(l);
  };
  const auto lemma_id = [&](Lit l) { return lemma[lemma_index(l)]; };
  for_each_substitutable([&](Lit l) {
    const Lit s = representative(l);
    std::vector<uint64_t> chain;
    if (lrat) {
      const bool ok = big_path_chain(k, l, s, chain);
      assert(ok && "SCC members are strongly connected");
      (void)ok;
    }
    const uint64_t id = ++k.next_clause_id;
    if (lrat)
      lemma[lemma_index(l)] = id;
    if (k.proof) {
      const Lit lits2[2] = {negate(l), s};
      if (lrat)
        k.proof->add_rup(id, lits2, 2, chain.data(),
                         static_cast<uint32_t>(chain.size()));
      else
        k.proof->add_rup(0, lits2, 2, nullptr, 0);
    }
  });
  substitute_stage_trace(k, "rewrite-lemmas", lemma.size(), lemma.capacity());

  // Canonical Substitute benefits from a literal-indexed byte table.  Sweep
  // rewrites a small connected frontier many times on giant formulas, so a
  // sparse set avoids allocating/zeroing 2*nvars for every equivalence.
  std::vector<uint8_t> seen;
  std::unordered_set<Lit> sparse_seen;
  if (session)
    sparse_seen.reserve(2 * session->retiring_sources().size());
  else
    seen.assign(nlits, 0);
  const auto seen_contains = [&](Lit l) {
    return session ? sparse_seen.find(l) != sparse_seen.end()
                   : static_cast<bool>(seen[l]);
  };
  const auto seen_mark = [&](Lit l) {
    if (session)
      sparse_seen.insert(l);
    else
      seen[l] = 1;
  };
  const auto seen_clear = [&](Lit l) {
    if (session)
      sparse_seen.erase(l);
    else
      seen[l] = 0;
  };
  substitute_stage_trace(k, "rewrite-seen", seen.size(), seen.capacity());
  // Batched root units + opposite-sign refutation: the shared kernel idiom
  // (PendingUnits, kernel.hpp).
  PendingUnits pending;
  substitute_stage_trace(k, "rewrite-pending-begin", k.nvars);
  pending.init(k);
  substitute_stage_trace(k, "rewrite-pending-end", pending.units.size(),
                         pending.ids.size(), pending.units.capacity());
  bool changed = false;

  // Record a size-collapsed root unit `u`, deduping per variable within the
  // round. Returns true iff `u` contradicts a unit already derived this round,
  // in which case the two resolve to ∅ and the caller returns Unsat. Without
  // this, a batch deriving both `x` and `¬x` would assert the first and
  // silently drop the second, losing the conflict.
  auto record_unit = [&](Lit u, uint64_t id) -> bool {
    if (k.value(u) > 0)
      return false;
    if (k.value(u) < 0) {
      kernel_emit_empty_from_pair(k, id, k.unit_ids[var_of(u)]);
      return true;
    }
    return pending.record(k, u, id) == PendingUnits::Outcome::Refuted;
  };

  // Kissat substitutes binaries first, then assigns and propagates every unit
  // they produced before it starts the large-clause pass.  Process the batch
  // in stack-pop order, propagating after each assignment, and reset the table
  // so large-clause units form the second independent batch.
  auto flush_units = [&]() -> bool {
    for (auto it = pending.units.rbegin(); it != pending.units.rend(); ++it) {
      const Lit u = *it;
      if (k.value(u) > 0)
        continue;
      if (k.value(u) < 0) {
        pending.refute(k, u); // ¬u became root-true since the record
        return true;
      }
      pending.commit(k, u); // the id is this variable's identity from here
      kernel_assign_unit(k, u);
      if (inprocess_reach_root(k))
        return true;
    }
    pending.init(k);
    return false;
  };

  // Rewrite one literal sequence: apply repr, strip root-false literals (their
  // unit ids join `chain`), detect root-true/tautology. Fills `out` with the
  // kept active literals and `chain` with the antecedent ids, without the
  // original clause id — the caller appends that. Returns true iff the rewrite
  // is satisfied or tautological, in which case the caller only deletes.
  std::vector<uint32_t> sweep_origin_rank;
  auto rewrite_lits = [&](const Lit *lits, uint32_t size, std::vector<Lit> &out,
                          std::vector<uint64_t> &chain) -> bool {
    out.clear();
    chain.clear();
    sweep_origin_rank.clear();
    const bool connected_large = session && size > 2;
    bool satisfied = false;
    for (uint32_t i = 0; i < size; i++) {
      const Lit m = lits[i];
      // Non-session reads the precomputed image (one load); the ternary
      // short-circuits so the lambdas are not evaluated off the session path.
      const Lit mp = session ? (mapped(m) ? representative(m) : m) : image[m];
      if (k.value(mp) > 0) { // root-true → clause satisfied
        satisfied = true;
        break;
      }
      if (k.value(mp) < 0) { // root-false → strip (cite its unit)
        // Propagation order, not literal order: the representative's unit is
        // what makes the bridging lemma unit, so it precedes it. A checker
        // rejects a hint that is not unit at its turn, and the reverse order
        // is exactly that (the D-CONG-LRAT lesson).
        if (lrat) {
          if (substitutable(m)) {
            chain.push_back(k.unit_ids[var_of(mp)]);
            chain.push_back(lemma_id(m));
          } else {
            // This map member became root-fixed while SCC detection was
            // finishing. Kissat still rewrites it, but needs no transient
            // equivalence: the source literal's own root unit justifies
            // removing it from the original clause directly.
            assert(!mapped(m) || k.value(m) < 0);
            chain.push_back(k.unit_ids[var_of(m)]);
          }
        }
        continue;
      }
      if (substitutable(m) && lrat)
        chain.push_back(lemma_id(m));
      const uint32_t origin_rank = connected_large && mapped(m)
                                       ? session->retiring_index(m) + 1
                                       : 0;
      if (seen_contains(mp)) { // duplicate literal
        // Connected substitution discards the resident representative, keeping
        // the retiring occurrence's position. Later merge-forest origins win
        // batched collisions; proof hints retain their independent order.
        if (connected_large) {
          const auto prior = std::find(out.begin(), out.end(), mp);
          const size_t at = static_cast<size_t>(prior - out.begin());
          if (origin_rank > sweep_origin_rank[at]) {
            out.erase(prior);
            sweep_origin_rank.erase(sweep_origin_rank.begin() + at);
            out.push_back(mp);
            sweep_origin_rank.push_back(origin_rank);
          }
        }
        continue;
      }
      if (seen_contains(negate(mp))) { // mp and ¬mp both present → tautology
        satisfied = true;
        break;
      }
      seen_mark(mp);
      out.push_back(mp);
      if (connected_large)
        sweep_origin_rank.push_back(origin_rank);
    }
    for (const Lit l : out)
      seen_clear(l); // unmark
    if (satisfied) {
      out.clear();
      return true;
    }
    if (lrat) { // a duplicated member literal would push its lemma twice
      // In place, never by sorting: the order is the proof. Every other chain
      // here sorts pairs keyed by trail position (probe.cpp emit_unit_chain),
      // which is propagation order; sorting bare ids is not.
      size_t kept = 0;
      for (size_t rd = 0; rd < chain.size(); rd++) {
        bool duplicate = false;
        for (size_t j = 0; j < kept && !duplicate; j++)
          duplicate = chain[j] == chain[rd];
        if (!duplicate)
          chain[kept++] = chain[rd];
      }
      chain.resize(kept);
    }
    return false;
  };

  // (D) rewrite large clauses. The canonical pass streams to a captured
  // original arena end, just as Kissat's `all_clauses` traversal does. Every
  // surviving large image is written back into that source allocation; only
  // unit/binary collapses retire the large record.
  std::vector<Lit> out;
  std::vector<uint64_t> chain;
  size_t large_visited = 0, large_touched = 0;
  bool traced_large_replacement = false;
  const auto rewrite_large_ref = [&](Ref ref) -> ApplyResult {
    Clause *c = clause_at(k.arena, ref);
    if (!large_visited++)
      substitute_stage_trace(k, "rewrite-large-first-ref", ref, c->size,
                             k.arena.capacity());
    // Touched iff some literal is substituted or root-assigned. The old form
    // also computed `mp = mapped(m) ? representative(m) : m` and tested
    // `k.value(mp)`, but that term is redundant: when mapped(m) the `||`
    // short-circuits before it, and when not, mp == m so k.value(mp) ==
    // k.value(m), already tested. Dropping it removes a representative() lookup
    // and a value read per literal of every large clause -- the hottest
    // substitution scan (report 3.89). Session-hoisted so the non-session path
    // reads mapped_sub[] directly (clause literals are < nlits) instead of the
    // lambda's session branch + bounds check.
    bool touched = false;
    if (session) {
      for (const Lit m : *c)
        if (mapped(m) || k.value(m) != 0) {
          touched = true;
          break;
        }
    } else {
      for (const Lit m : *c)
        if (mapped_sub[m] || k.value(m) != 0) {
          touched = true;
          break;
        }
    }
    if (!touched)
      return ApplyResult::Ok;
    if (!large_touched++)
      substitute_stage_trace(k, "rewrite-large-first-touched", ref, c->size,
                             k.arena.capacity());
    // Every ledger update below locates this clause by its pre-rewrite pose,
    // and the kernel primitives (delete, collapse, in-place replace) run
    // before some of those updates. Materialize its literals' streams now,
    // while the watches and `Kernel::dense` still hold the source.
    if (session)
      session->prime_large(k, ref);
    const bool credundant = c->redundant();
    const uint32_t cglue = c->glue();
    const uint64_t cid = c->id();
    const bool sat = rewrite_lits(c->lits, c->size, out, chain);
    if (large_touched <= 5)
      substitute_stage_trace(k, "rewrite-large-first-image", out.size(),
                             out.capacity(), chain.capacity());
    if (sat) { // satisfied/tautology -> delete only (deletions are proof-free)
      if (session)
        session->remove_large(k, ref);
      kernel_delete_clause(k, c); // cid == c->id()
      changed = true;
      return ApplyResult::Ok;
    }
    const uint64_t id = ++k.next_clause_id;
    if (k.proof) {
      if (lrat) {
        chain.push_back(cid); // original clause closes the RUP chain
        k.proof->add_rup(id, out.data(), static_cast<uint32_t>(out.size()),
                         chain.data(), static_cast<uint32_t>(chain.size()));
      } else {
        k.proof->add_rup(0, out.data(), static_cast<uint32_t>(out.size()),
                         nullptr, 0);
      }
    }
    changed = true;
    // Both Kissat substitution paths overwrite surviving large images in the
    // source allocation (`substitute.c:substitute_clauses` and
    // `sweep.c:substitute_connected_clauses`). Besides keeping the Ref and
    // allocation span, this retains header state such as Vivify's leftover
    // priority bit. Unit and binary terminals still use the shared collapse
    // path below.
    // The two callers intentionally inherit glue differently. Kissat's
    // canonical substitute.c overwrites the clause without touching glue,
    // while Sweep's connected rewrite promotes an oversized glue to
    // new_size-1 (sweep.c:1004-1008). Keeping the shared physical rewrite
    // primitive must not erase that rule-level lifecycle distinction.
    const bool trace_replacement = !traced_large_replacement;
    if (trace_replacement) {
      substitute_stage_trace(k, "rewrite-large-first-replace", ref,
                             k.arena.size(), k.arena.capacity());
      traced_large_replacement = true;
    }
    const uint32_t replacement_glue =
        credundant
            ? (session ? kernel_shrunken_glue(
                             k, cglue, static_cast<uint32_t>(out.size()))
                       : cglue)
            : 0;
    ReplaceOutcome replacement;
    if (out.size() >= 3) {
      if (session)
        session->rewrite_large_in_place(k, ref, out.data(),
                                        static_cast<uint32_t>(out.size()));
      // Pinned Kissat has deliberately different consumer wiring here.
      // sweep.c::substitute_connected_clauses marks every surviving literal
      // in an irredundant image, while substitute.c::substitute_clauses only
      // overwrites it and does not call mark_added_literals.  Do not let the
      // shared representation primitive erase that distinction.
      kernel_replace_large_clause_in_place(
          k, ref, id, out.data(), static_cast<uint32_t>(out.size()),
          replacement_glue, session ? "sweep_substitute" : "substitute",
          /*mark_added_material=*/session != nullptr);
      replacement = ReplaceOutcome::Large;
    } else {
      // Canonical substitution retires the whole original large clause on a
      // binary collapse. Shared replacement already marks disappearing
      // literals; complete native removal advice for retained free endpoints.
      // Connected Sweep and surviving large rewrites have different wiring.
      if (!session && !credundant && out.size() == 2)
        for (const Lit old : *c)
          if (!k.value(old) &&
              std::find(out.begin(), out.end(), old) != out.end())
            kernel_mark_bve_retry(k, var_of(old),
                                  "substitute-collapse-binary", c);
      replacement = kernel_replace_clause(
          k, c, id, out.data(), static_cast<uint32_t>(out.size()), credundant,
          replacement_glue, nullptr);
    }
    switch (replacement) {
    case ReplaceOutcome::Refuted: // all-false rewrite (unreachable at a
      return ApplyResult::Unsat;  // quiescent root)
    case ReplaceOutcome::Unit:
      if (record_unit(out[0], id))
        return ApplyResult::Unsat;
      break;
    default:
      break;
    }
    if (session) {
      if (replacement == ReplaceOutcome::Binary) {
        bool append_first = false, append_second = false;
        for (const Lit old_lit : *clause_at(k.arena, ref))
          if (mapped(old_lit)) {
            append_first |= representative(old_lit) == out[0];
            append_second |= representative(old_lit) == out[1];
          }
        session->collapse_large_to_binary(k, ref, out[0], out[1],
                                          append_first, append_second);
      } else if (replacement == ReplaceOutcome::Unit ||
                 replacement == ReplaceOutcome::Refuted) {
        session->remove_large(k, ref);
      }
    }
    if (trace_replacement)
      substitute_stage_trace(k, "rewrite-large-first-replaced",
                             replacement == ReplaceOutcome::Large ? ref
                                                                  : INVALID_REF,
                             k.arena.size(), k.arena.capacity());
    return ApplyResult::Ok;
  };

  const auto make_large_image = [&](Ref ref) {
    const Clause *c = clause_at(k.arena, ref);
    bool touched = false;
    for (const Lit m : *c) {
      const Lit mp = mapped(m) ? representative(m) : m;
      if (mapped(m) || k.value(m) != 0 || k.value(mp) != 0) {
        touched = true;
        break;
      }
    }
    return touched && !rewrite_lits(c->lits, c->size, out, chain);
  };

  // Derive each image before mutating anything so the rewritten clauses' two
  // watch slices cannot hit an amortized doubling in the memory-critical pass.
  // Surviving large images stay in their source allocations and therefore
  // require no clause-arena reservation. `visit` enumerates the same immutable
  // refs in both calls.
  const auto reserve_large_replacements = [&](const auto &visit) {
    // Sweep owns an exact connected snapshot and publishes its mixed dense
    // order at the call boundary. It performs no arena collection there.
    // Exact formula-wide reservation would be unrelated work for each proved
    // equivalence; only binary watch growth remains output-sensitive here.
    if (session)
      return;
    size_t watch_words = 0;
    visit([&](Ref ref) {
      if (!make_large_image(ref))
        return;
      if (out.size() == 2)
        watch_words += 2;
      else if (out.size() >= 3) {
        watch_words += 4;
      }
    });
    substitute_stage_trace(k, "rewrite-large-reserve-plan", 0,
                           watch_words, k.arena.capacity());
    if (watch_words) {
      k.watches.begin_batch_reserve();
      visit([&](Ref ref) {
        if (!make_large_image(ref))
          return;
        if (out.size() == 2) {
          k.watches.reserve_batch_word(out[0]);
          k.watches.reserve_batch_word(out[1]);
        } else if (out.size() >= 3) {
          k.watches.reserve_batch_word(out[0]);
          k.watches.reserve_batch_word(out[0]);
          k.watches.reserve_batch_word(out[1]);
          k.watches.reserve_batch_word(out[1]);
        }
      });
      // Pack exactly while dense rewrite scratch is live. The first later
      // relocation establishes bounded global headroom on demand.
      k.watches.finish_batch_reserve(false);
    }
    substitute_stage_trace(k, "rewrite-large-reserved", k.arena.capacity(),
                           k.watches.arena.size(),
                           k.watches.arena.capacity());
  };

  auto rewrite_large_clauses = [&]() -> ApplyResult {
  substitute_stage_trace(k, "rewrite-large-begin", k.arena.size(),
                         k.arena.capacity());
  // Kissat's Sweep stays in dense mode and `substitute_connected_clauses`
  // visits only the retiring literal's unified binary/irredundant stream.
  // Redundant clauses are deliberately absent and are consumed by the
  // immediately following canonical Substitute. A search-time fallback to the
  // complete arena is therefore both semantically non-reference and O(F) per productive
  // environment.  The session names the exact retiring frontier; collect its
  // irredundant refs sparsely without an arena-sized membership bitmap.
  // Every clause reached below loses each retired literal, so those literals'
  // dense lists are consumed whole: mark them and clear once at the end
  // instead of searching and erasing per clause.
  const auto bulk_clear_dense = [&](const auto &literals) {
    if (!k.dense)
      return;
    for (const Lit l : literals)
      k.dense->clear_large(l);
  };
  if (session && k.dense) {
    std::vector<uint8_t> &bulk = k.dense_bulk_scratch;
    if (bulk.size() < static_cast<size_t>(nlits))
      bulk.assign(static_cast<size_t>(nlits), 0);
    for (const Lit l : session->retiring_sources())
      bulk[l] = 1;
    k.dense_bulk_cleared = &bulk;
    struct Restore {
      Kernel &k;
      std::vector<uint8_t> &bulk;
      const std::vector<Lit> &sources;
      ~Restore() {
        k.dense_bulk_cleared = nullptr;
        for (const Lit l : sources)
          bulk[l] = 0;
      }
    } restore{k, bulk, session->retiring_sources()};
    std::vector<Ref> refs;
    for (const Lit l : session->retiring_sources()) {
      k.dense->with_large(l, [&](auto occurrences) {
        for (const Ref ref : occurrences) {
          const Clause *c = clause_at(k.arena, ref);
          if (!c->garbage())
            refs.push_back(ref);
        }
      });
    }
    std::sort(refs.begin(), refs.end()); // preserve current arena traversal
    refs.erase(std::unique(refs.begin(), refs.end()), refs.end());
    const auto visit = [&](const auto &fn) {
      for (const Ref ref : refs)
        fn(ref);
    };
    reserve_large_replacements(visit);
    for (const Ref ref : refs)
      if (rewrite_large_ref(ref) == ApplyResult::Unsat)
        return ApplyResult::Unsat;
    bulk_clear_dense(session->retiring_sources());
  } else {
    const Ref original_end = static_cast<Ref>(k.arena.size());
    const auto visit = [&](const auto &fn) {
      for (Ref ref = 0; ref < original_end;) {
        const Clause *c = clause_at(k.arena, ref);
        const uint32_t words = clause_actual_words(c);
        if (!c->garbage())
          fn(ref);
        ref += words;
      }
    };
    reserve_large_replacements(visit);
    struct Restore {
      Kernel &k;
      ~Restore() { k.dense_bulk_cleared = nullptr; }
    } restore{k};
    if (k.dense)
      k.dense_bulk_cleared = &mapped_sub;
    for (Ref ref = 0; ref < original_end;) {
      const Clause *c = clause_at(k.arena, ref);
      const uint32_t words = clause_actual_words(c);
      if (!c->garbage() && rewrite_large_ref(ref) == ApplyResult::Unsat)
        return ApplyResult::Unsat;
      ref += words;
    }
    if (k.dense) {
      std::vector<Lit> retired;
      for (Lit l = 0; l < nlits; l++)
        if (mapped_sub[l])
          retired.push_back(l);
      bulk_clear_dense(retired);
    }
  }
  return ApplyResult::Ok;
  };

  // (C) rewrite BINARY clauses.  Preserve the complete clause multiset and
  // import traversal order in both proof and no-proof modes.  Identical proof
  // clauses cannot all be named by `binary_ids` (the latest id wins), but they
  // do not need separate names: emit one proof image per distinct target pair
  // and let every identical internal watch copy share that live id.  This keeps
  // the formula seen by the following SCC/Sweep passes byte-for-byte aligned
  // with the no-proof/Kissat path without weakening DRAT or LRAT.
  std::vector<Var> variable_order;
  std::vector<uint8_t> canonical_binary_affected;
  substitute_stage_trace(k, "rewrite-variable-order", variable_order.size(),
                         variable_order.capacity());
  if (!session) {
    kernel_vars_in_import_order(k, variable_order);
    // Canonical Substitute changes only binaries incident to a retiring
    // literal.  Name those source owners and their mirror owners first, then
    // retain the existing global import-order traversal over precisely that
    // induced population.  This preserves the former candidate and per-list
    // order byte-for-byte while avoiding a scan and later compaction of every
    // unrelated watch list—particularly important for root-cleanup rounds
    // whose SCC map produces no binary image.  Kissat's in-place substitution
    // has the same connected-stream boundary.
    canonical_binary_affected.assign(nlits, 0);
    for (const Var variable : variable_order)
      for (uint32_t sign = 0; sign < 2; sign++) {
        const Lit lit = make_lit(variable, sign != 0);
        if (!mapped(lit))
          continue;
        canonical_binary_affected[lit] = 1;
        for (const WatchEntry watch : k.watches.entries(lit))
          if (watch.binary())
            canonical_binary_affected[watch.other()] = 1;
      }
  }

  struct BinaryImage {
    Lit source_a, source_b;
    // Bridge endpoints when the source is a preserved equivalence binary:
    // the emitted pair under every later merge, not the final representative.
    Lit bridge_target_a = INVALID_LIT;
    Lit bridge_target_b = INVALID_LIT;
  };
  struct ExpandedBinaryImage {
    Lit source_a, source_b;
    Lit target_a, target_b;
    bool tautological;
  };
  const auto make_image = [&](Lit lit, Lit other) {
    BinaryImage image{lit, other, INVALID_LIT, INVALID_LIT};
    if (session)
      (void)session->equivalence_bridge_targets(
          lit, other, &image.bridge_target_a, &image.bridge_target_b);
    return image;
  };
  const auto expand_image = [&](const BinaryImage &source) {
    if (source.bridge_target_a != INVALID_LIT)
      return ExpandedBinaryImage{
          source.source_a, source.source_b, source.bridge_target_a,
          source.bridge_target_b,
          source.bridge_target_a == negate(source.bridge_target_b)};
    const Lit a = mapped(source.source_a)
                      ? representative(source.source_a)
                      : source.source_a;
    const Lit b = mapped(source.source_b)
                      ? representative(source.source_b)
                      : source.source_b;
    return ExpandedBinaryImage{source.source_a, source.source_b, a, b,
                               a == negate(b)};
  };
  bool refuted = false;
  // Canonical substitution edits watches directly rather than using the
  // binary-delete primitive. Retain each disappearing physical copy until
  // the binary-unit batch reaches root closure, then publish removal advice
  // in source import order (Kissat substitute_binaries::delayed_deleted).
  // Surviving rewrites are not removals; connected Sweep owns its own marks.
  std::vector<std::pair<Lit, Lit>> removed_binaries;
  // The non-session DRAT path ports Kissat's single in-place `substitute_binaries`
  // pass (kissat/src/substitute.c:276) instead of the image-array pipeline below.
  // LRAT (needs per-pair antecedent ids) and Sweep sessions (bridge targets) keep
  // the image path.
  const bool kissat_single_pass = !session && !lrat;
  if (kissat_single_pass) {
    // ---- Kissat substitute_binaries port ------------------------------------
    // One pass over each affected literal's watch list: `lit==repr` keeps or
    // rewrites the entry in place; `lit!=repr` moves the pair to `repr`'s list
    // via a per-lit `delayed` stack appended only AFTER the walk, so no push
    // relocates the list being scanned (grow() re-indexes offsets, but the raw
    // p/q/end pointers are not). DRAT and the pair identity are emitted once per
    // undirected pair under the import-order owner guard, so the resulting
    // formula, binary_ids and next_clause_id COUNT match the image path; only
    // the DRAT line interleaving and the id assignment ORDER differ (checkable,
    // and search-invariant). Metadata bookkeeping mirrors WatchLists::compact.
    const auto import_owner = [&](Lit a, Lit b) {
      return kernel_import_lit_order(k, a) < kernel_import_lit_order(k, b);
    };
    std::vector<Lit> delayed_targets; // repr_other words to move to repr_lit
    std::vector<uint8_t> delayed_publish;
    std::vector<Lit> touched_units;   // seen marks to clear at the end
    for (const Var variable : variable_order)
      for (uint32_t sign = 0; sign < 2; sign++) {
        const Lit lit = make_lit(variable, sign != 0);
        if (!canonical_binary_affected[lit])
          continue;
        const Lit repr_lit = image[lit];
        const Lit not_repr_lit = negate(repr_lit);
        delayed_targets.clear();
        delayed_publish.clear();
        uint32_t *const base = k.watches.begin(lit);
        uint32_t *q = base;
        const uint32_t *p = base;
        const uint32_t *const stop = k.watches.end(lit);
        const uint32_t old_size = k.watches.heads[lit].size;
        uint32_t kept_binaries = 0;
        bool kept_has_large = false, kept_binaries_first = true;
        while (p != stop) {
          const Watch w{*p};
          if (!w.binary()) { // large watch: two words, keep verbatim
            *q++ = *p++;
            *q++ = *p++;
            kept_has_large = true;
            continue;
          }
          const Lit other = w.other();
          ++p;
          const Lit repr_other = image[other];
          const bool is_owner = import_owner(lit, other);
          const auto proof_del_source = [&] {
            if (is_owner && k.proof) {
              const Lit lits2[2] = {lit, other};
              k.proof->del(k.next_clause_id, kernel_binary_id(k, lit, other),
                           lits2, 2);
            }
          };
          if (repr_other == not_repr_lit) { // tautology: drop this direction
            changed = true;
            if (is_owner)
              removed_binaries.emplace_back(lit, other);
            proof_del_source();
            continue;
          }
          if (repr_other == repr_lit) { // collapses to the unit repr_lit
            changed = true;
            if (is_owner)
              removed_binaries.emplace_back(lit, other);
            // Add the unit while the source pair is still live (its RUP cites
            // the source), then delete the source -- the image path's
            // add-pass-then-delete-pass order.
            if (is_owner && !seen_contains(repr_lit)) {
              seen_mark(repr_lit);
              touched_units.push_back(repr_lit);
              const uint64_t id = ++k.next_clause_id;
              if (k.proof)
                k.proof->add_rup(0, &repr_lit, 1, nullptr, 0);
              if (record_unit(repr_lit, id))
                refuted = true;
            }
            proof_del_source();
            continue;
          }
          if (lit == repr_lit && other == repr_other) { // unchanged: keep
            *q++ = w.raw;
            ++kept_binaries;
            kept_binaries_first = kept_binaries_first && !kept_has_large;
            continue;
          }
          // Genuine surviving rewrite to (repr_lit, repr_other).
          changed = true;
          if (is_owner && k.proof) {
            const Lit lits2[2] = {repr_lit, repr_other};
            k.proof->add_rup(0, lits2, 2, nullptr, 0);
          }
          proof_del_source();
          if (lit == repr_lit) { // stable owner: rewrite in place, survives
            kernel_rearm_binary_clause(k, repr_lit, repr_other);
            *q++ = binary_watch(repr_other).raw;
            ++kept_binaries;
            kept_binaries_first = kept_binaries_first && !kept_has_large;
          } else { // mapped owner: move to repr_lit's list, publish once/pair
            delayed_targets.push_back(repr_other);
            const bool moved_other = (other != repr_other);
            delayed_publish.push_back(
                static_cast<uint8_t>(!moved_other || is_owner));
          }
        }
        // Finalize lit's compacted list (WatchLists::compact bookkeeping).
        WatchHead &head = k.watches.heads[lit];
        const uint32_t new_size = static_cast<uint32_t>(q - base);
        head.size = new_size;
        k.watches.holes += old_size - new_size;
        head.set_layout(kept_binaries, kept_binaries_first);
        // Append the moved directions to repr_lit's list (may relocate that
        // slice only; lit's list is already finalized and re-read by offset).
        for (size_t i = 0; i < delayed_targets.size(); i++) {
          const Lit repr_other = delayed_targets[i];
          if (delayed_publish[i]) {
            // The binary-liveness index is maintained exactly (add at publish,
            // remove at delete) and is the same no-false-negative prefilter
            // kernel_binary_live trusts: if it rejects the pair, neither
            // direction is live, so skip both O(degree) watch scans. Proof-
            // neutral (already_live only sets new_pair), so a stale hit only
            // costs the scan it would have cost anyway.
            const bool already_live =
                (k.binary_liveness &&
                 !k.binary_liveness->maybe(
                     kernel_binary_key(repr_lit, repr_other)))
                    ? false
                    : (kernel_binary_copies(k, repr_lit, repr_other, 1) ||
                       kernel_binary_copies(k, repr_other, repr_lit, 1));
            k.watches.push_binary(repr_lit, repr_other);
            const uint64_t id = ++k.next_clause_id;
            kernel_publish_binary_clause(k, repr_lit, repr_other, id,
                                         !already_live);
          } else {
            k.watches.push_binary(repr_lit, repr_other);
          }
        }
      }
    for (const Lit unit : touched_units)
      seen_clear(unit);
  } else {
  // Targets are a pure function of the immutable representative map. Store
  // only the source pair, and use segmented storage so growing a giant image
  // does not momentarily hold both old and doubled contiguous buffers.
  std::vector<BinaryImage> images;
  // Substitution, canonical or Sweep-inline, rewrites only clauses incident to
  // a non-representative literal.  Unconnected binaries cannot change.  Keep
  // them in place instead of copying the complete binary formula into
  // BinaryImage/set/map structures and rebuilding every watch list.
  const bool connected_only = true;
  const auto snapshot_undirected = [&](Lit lit) {
      // The owner's import rank is constant across its whole watch list.
      const uint64_t lit_order = kernel_import_lit_order(k, lit);
      for (const WatchEntry w : k.watches.entries(lit)) {
        if (!w.binary())
          continue;
        const Lit other = w.other();
        // A pair with two retiring endpoints appears in both source streams;
        // retain one orientation per physical copy. With one stable endpoint
        // only the retiring stream is traversed and therefore owns the image
        // regardless of the stable endpoint's import rank.
        if (mapped(other) && lit_order >= kernel_import_lit_order(k, other))
          continue;
        images.push_back(make_image(lit, other));
#ifdef TACTIX_ENABLE_RULE_JOURNAL
        const ExpandedBinaryImage noted = expand_image(images.back());
        rule_journal_note_binary_rewrite(k, lit, other, noted.target_a,
                                         noted.target_b);
#endif
      }
  };
  if (session) {
    // The session contract names every retiring literal. Its directed watch
    // streams are the exact connected binary frontier, matching Kissat's
    // `substitute_connected_clauses`; no unrelated imported owner is visited.
    for (const Lit lit : session->retiring_sources())
      snapshot_undirected(lit);
  } else {
    for (const Var variable : variable_order)
      for (uint32_t sign = 0; sign < 2; sign++) {
        const Lit lit = make_lit(variable, sign != 0);
        if (!canonical_binary_affected[lit])
          continue;
        const uint64_t lit_order = kernel_import_lit_order(k, lit);
        for (const WatchEntry w : k.watches.entries(lit)) {
          if (!w.binary() ||
              lit_order >= kernel_import_lit_order(k, w.other()))
            continue;
          const Lit other = w.other();
          if (connected_only && !mapped(lit) && !mapped(other))
            continue;
          images.push_back({lit, other});
#ifdef TACTIX_ENABLE_RULE_JOURNAL
          const Lit a = mapped(lit) ? representative(lit) : lit;
          const Lit b = mapped(other) ? representative(other) : other;
          rule_journal_note_binary_rewrite(k, lit, other, a, b);
#endif
        }
      }
  }
  if (!session)
    for (const BinaryImage &stored : images) {
      const ExpandedBinaryImage image = expand_image(stored);
      if (image.tautological || image.target_a == image.target_b)
        removed_binaries.emplace_back(image.source_a, image.source_b);
    }
  substitute_stage_trace(k, "rewrite-images", images.size(), 0,
                         sizeof(BinaryImage));

  // `seen` is otherwise clear between large-clause rewrites. Reuse it to
  // deduplicate collapsed binary units and retain only the touched literals
  // for O(produced units) restoration; a tree node per unit can exceed the
  // binary image itself on highly congruent formulas.
  std::vector<Lit> emitted_units;
  const auto first_emitted_unit = [&](Lit unit) {
    if (seen_contains(unit))
      return false;
    seen_mark(unit);
    emitted_units.push_back(unit);
    return true;
  };
  std::vector<uint64_t> target_keys, target_ids;
  if (!lrat) {
    // DRAT names clauses by their literals, not by ids.  Stream the transformed
    // multiset exactly as Kissat does instead of sorting two global key arrays
    // merely to recover the LRAT identity of each distinct target.  On giant
    // binary formulas those arrays and their comparison sorts dominate both
    // Substitute's memory and wall time.  Duplicate source clauses deliberately
    // produce duplicate target clauses, preserving the internal multiset.
    for (const BinaryImage &stored : images) {
      const ExpandedBinaryImage image = expand_image(stored);
      const bool changed_image =
          image.tautological || image.target_a == image.target_b ||
          kernel_binary_key(image.source_a, image.source_b) !=
              kernel_binary_key(image.target_a, image.target_b);
      changed = changed || changed_image;
      if (image.tautological)
        continue;

      if (image.target_a == image.target_b) {
        if (!first_emitted_unit(image.target_a))
          continue;
        const uint64_t id = ++k.next_clause_id;
        if (k.proof)
          k.proof->add_rup(0, &image.target_a, 1, nullptr, 0);
        if (record_unit(image.target_a, id))
          refuted = true;
        continue;
      }

      if (changed_image && k.proof) {
        const Lit lits2[2] = {image.target_a, image.target_b};
        k.proof->add_rup(0, lits2, 2, nullptr, 0);
      }
    }

    if (k.proof)
      for (const BinaryImage &stored : images) {
        const ExpandedBinaryImage image = expand_image(stored);
        const bool changed_image =
            image.tautological || image.target_a == image.target_b ||
            kernel_binary_key(image.source_a, image.source_b) !=
                kernel_binary_key(image.target_a, image.target_b);
        if (!changed_image)
          continue;
        const Lit lits2[2] = {image.source_a, image.source_b};
        k.proof->del(k.next_clause_id, 0, lits2, 2);
      }
  } else {
    std::vector<uint64_t> source_keys;
    source_keys.reserve(images.size());
    target_keys.reserve(images.size());
    for (const BinaryImage &stored : images) {
      const ExpandedBinaryImage image = expand_image(stored);
      const uint64_t source =
          kernel_binary_key(image.source_a, image.source_b);
      source_keys.push_back(source);
      if (!image.tautological && image.target_a != image.target_b)
        target_keys.push_back(
            kernel_binary_key(image.target_a, image.target_b));
    }
    const auto sort_unique = [](std::vector<uint64_t> &keys) {
      std::sort(keys.begin(), keys.end());
      keys.erase(std::unique(keys.begin(), keys.end()), keys.end());
    };
    sort_unique(source_keys);
    sort_unique(target_keys);
    const auto contains = [](const std::vector<uint64_t> &keys, uint64_t key) {
      return std::binary_search(keys.begin(), keys.end(), key);
    };
    const auto key_index = [](const std::vector<uint64_t> &keys, uint64_t key) {
      const auto it = std::lower_bound(keys.begin(), keys.end(), key);
      assert(it != keys.end() && *it == key);
      return static_cast<size_t>(it - keys.begin());
    };

    // LRAT needs one live named antecedent per distinct pair.  A target pair
    // already present as a source retains that proof clause; a genuinely new
    // target is derived once and duplicate watches share its id.
    target_ids.assign(target_keys.size(), 0);
    for (size_t i = 0; i < target_keys.size(); i++)
      if (contains(source_keys, target_keys[i]))
        target_ids[i] = k.binary_ids.at(target_keys[i]);

    for (const BinaryImage &stored : images) {
      const ExpandedBinaryImage image = expand_image(stored);
      const bool changed_image =
          image.tautological || image.target_a == image.target_b ||
          kernel_binary_key(image.source_a, image.source_b) !=
              kernel_binary_key(image.target_a, image.target_b);
      changed = changed || changed_image;
      if (image.tautological)
        continue;

      const uint64_t source =
          kernel_binary_key(image.source_a, image.source_b);
      std::vector<uint64_t> ch;
      if (stored.bridge_target_a != INVALID_LIT) {
        // A transformed bridge's endpoints can be intermediate class members,
        // so the source-literal lemmas (which map to the final representative)
        // are not unit along this clause. The mirror lemmas of the image
        // endpoints close the RUP directly: each forces its own class root,
        // and the two roots are complementary. A root endpoint has no lemma
        // and needs none — its assumed negation is the forced literal.
        assert(image.target_a != image.target_b && !image.tautological);
        if (substitutable(negate(image.target_a)))
          ch.push_back(lemma_id(negate(image.target_a)));
        if (substitutable(negate(image.target_b)))
          ch.push_back(lemma_id(negate(image.target_b)));
        assert(!ch.empty() && "a changed bridge image joins two class trees");
      } else {
        const Lit satisfied =
            k.value(image.target_a) > 0
                ? image.target_a
                : k.value(image.target_b) > 0 ? image.target_b : INVALID_LIT;
        if (satisfied != INVALID_LIT) {
          // A failed SCC root can fix a map member and its representative
          // before rewriting. The target binary is then RUP from the target's
          // root unit alone; no equivalence lemma was (or should be) emitted.
          ch.push_back(k.unit_ids[var_of(satisfied)]);
        } else {
          const auto append_changed_endpoint = [&](Lit source_lit,
                                                   Lit target_lit) {
            if (source_lit == target_lit)
              return;
            if (substitutable(source_lit)) {
              ch.push_back(lemma_id(source_lit));
            } else {
              assert(mapped(source_lit));
              assert(k.value(source_lit) < 0);
              assert(k.value(target_lit) < 0);
              ch.push_back(k.unit_ids[var_of(source_lit)]);
            }
          };
          append_changed_endpoint(image.source_a, image.target_a);
          append_changed_endpoint(image.source_b, image.target_b);
          ch.push_back(k.binary_ids.at(source));
        }
      }

      if (image.target_a == image.target_b) {
        if (!first_emitted_unit(image.target_a))
          continue;
        const uint64_t id = ++k.next_clause_id;
        k.proof->add_rup(id, &image.target_a, 1, ch.data(),
                         static_cast<uint32_t>(ch.size()));
        if (record_unit(image.target_a, id))
          refuted = true;
        continue;
      }

      const uint64_t target =
          kernel_binary_key(image.target_a, image.target_b);
      const size_t target_index = key_index(target_keys, target);
      if (target_ids[target_index])
        continue;
      const Lit lits2[2] = {image.target_a, image.target_b};
      const uint64_t id = ++k.next_clause_id;
      k.proof->add_rup(id, lits2, 2, ch.data(),
                       static_cast<uint32_t>(ch.size()));
      target_ids[target_index] = id;
    }

    // Retire only distinct source clauses absent from the final image.  Older
    // duplicate LRAT copies may stay in the checker because one id cannot name
    // several input copies.
    std::vector<uint8_t> deleted(source_keys.size(), 0);
    for (const BinaryImage &stored : images) {
      const ExpandedBinaryImage image = expand_image(stored);
      const uint64_t source =
          kernel_binary_key(image.source_a, image.source_b);
      const size_t source_index = key_index(source_keys, source);
      if (contains(target_keys, source) || deleted[source_index])
        continue;
      deleted[source_index] = 1;
      const Lit lits2[2] = {image.source_a, image.source_b};
      k.proof->del(k.next_clause_id,
                   kernel_binary_id(k, image.source_a, image.source_b), lits2,
                   2);
    }
  }
  substitute_stage_trace(k, "rewrite-binary-proof", emitted_units.size(),
                         emitted_units.capacity());
  for (const Lit unit : emitted_units)
    seen_clear(unit);
  std::vector<Lit>().swap(emitted_units);

  // A direction owned by a representative is rewritten in place, one pass per
  // owner, as in substitute.c:328-340; only the mirror on the retired endpoint
  // moves. Rebuilding both directions instead moves the stable one to the tail
  // and changes a later antecedent. A scan per image is quadratic in the
  // owner's degree and equivalent to this pass: the canonical target is a pure
  // function of the neighbour and an image exists for every pair whose
  // neighbour is mapped, duplicates included. The session path keeps the
  // per-image form because its bridge targets depend on the image.
  if (!session) {
    size_t stable_rewrites = 0;
    for (const Var variable : variable_order)
      for (uint32_t sign = 0; sign < 2; sign++) {
        const Lit stable = make_lit(variable, sign != 0);
        if (!canonical_binary_affected[stable] || mapped(stable))
          continue;
        uint32_t *p = k.watches.begin(stable);
        uint32_t *const end = k.watches.end(stable);
        while (p != end) {
          const Watch watch{*p};
          if (!watch.binary()) {
            p += 2;
            continue;
          }
          const Lit other = watch.other();
          if (mapped(other)) {
            const Lit target = representative(other);
            // The unit and tautological images are retired elsewhere and must
            // keep their source entry until then.
            if (target != stable && target != negate(stable)) {
              kernel_rearm_binary_clause(k, stable, target);
              *p = binary_watch(target).raw;
              stable_rewrites++;
            }
          }
          p++;
        }
      }
#ifndef NDEBUG
    // The pass must rewrite exactly the images the per-image scans did.
    size_t stable_images = 0;
    for (const BinaryImage &stored : images) {
      const ExpandedBinaryImage image = expand_image(stored);
      if (image.tautological || image.target_a == image.target_b)
        continue;
      stable_images +=
          (image.source_a == image.target_a) != (image.source_b == image.target_b);
    }
    assert(stable_rewrites == stable_images &&
           "stable-direction pass and the binary image disagree");
#endif
    (void)stable_rewrites;
  } else {
    for (const BinaryImage &stored : images) {
      const ExpandedBinaryImage image = expand_image(stored);
      if (image.tautological || image.target_a == image.target_b)
        continue;
      const bool stable_a = image.source_a == image.target_a;
      const bool stable_b = image.source_b == image.target_b;
      if (stable_a == stable_b)
        continue;
      const Lit stable = stable_a ? image.source_a : image.source_b;
      const Lit old_other = stable_a ? image.source_b : image.source_a;
      const Lit new_other = stable_a ? image.target_b : image.target_a;
      uint32_t *p = k.watches.begin(stable);
      uint32_t *const end = k.watches.end(stable);
      [[maybe_unused]] bool rewritten = false;
      while (p != end) {
        Watch watch{*p};
        if (watch.binary()) {
          if (watch.other() == old_other) {
            // Preserve the first physical copy's position and leave later
            // duplicates untouched (docs/implementation-notes.md §5).
            kernel_rearm_binary_clause(k, stable, new_other);
            *p = binary_watch(new_other).raw;
            rewritten = true;
            break;
          }
          p++;
        } else {
          p += 2;
        }
      }
      assert(rewritten);
    }
  }
  substitute_stage_trace(k, "rewrite-stable-directions");

#ifdef TACTIX_ENABLE_EVENT_TRACE
  for (const BinaryImage &stored : images) {
    const ExpandedBinaryImage image = expand_image(stored);
    const bool changed_image =
        image.tautological || image.target_a == image.target_b ||
        kernel_binary_key(image.source_a, image.source_b) !=
            kernel_binary_key(image.target_a, image.target_b);
    if (changed_image)
      event_trace_binary_lifecycle(
          k, image.tautological ? "sweep-physical-tautology"
                               : image.target_a == image.target_b
                                     ? "sweep-physical-unit"
                                     : "sweep-physical-rewrite",
          image.source_a, image.source_b,
          kernel_binary_id(k, image.source_a, image.source_b),
          kernel_binary_copies(k, image.source_a, image.source_b));
  }
#endif

  // Proof and clause identity use the one-image-per-undirected-clause order
  // above.  Sparse reconstruction is directed in Kissat: each retired
  // literal appends its own watch sequence to its representative only after
  // that complete source list has been visited (substitute.c:294-363).  Reuse
  // the released image storage for those directed moves so two retired
  // endpoints can land in their two independently correct destination orders.
  std::vector<Lit> affected_binary_owners;
  // Bridge entries that already carry their final endpoints must survive the
  // directed snapshot and compaction below: an unchanged bridge keeps both
  // directions, and a one-moved-endpoint bridge keeps exactly the stable
  // direction the in-place pass just rewrote (its mirror is rebuilt after
  // compaction).  Protection is counted per directed entry, one unit per
  // bridge image, never by literal pair: an ordinary binary whose pair merely
  // coincides with a bridge target was rewritten or deleted by the proof pass
  // above, and retaining it by pair identity leaves the kernel holding a live
  // clause whose every checker copy is later consumed — the DRAT population
  // then under-runs and a later lemma citing the survivor fails RUP.

  // Sorted (key, count) pairs, not a hash map: Sweep calls this once per
  // productive environment, so a per-call map allocates per distinct bridge.
  std::vector<std::pair<uint64_t, uint32_t>> bridge_keep_snapshot;
  std::vector<std::pair<uint64_t, uint32_t>> bridge_keep_compact;
  const auto bridge_keep_add = [](std::vector<std::pair<uint64_t, uint32_t>> &v,
                                  uint64_t key) { v.emplace_back(key, 1u); };
  const auto bridge_keep_coalesce =
      [](std::vector<std::pair<uint64_t, uint32_t>> &v) {
        std::sort(v.begin(), v.end(),
                  [](const std::pair<uint64_t, uint32_t> &a,
                     const std::pair<uint64_t, uint32_t> &b) {
                    return a.first < b.first;
                  });
        size_t kept = 0;
        for (size_t i = 0; i < v.size(); i++) {
          if (kept && v[kept - 1].first == v[i].first)
            v[kept - 1].second += v[i].second;
          else
            v[kept++] = v[i];
        }
        v.resize(kept);
      };
  const auto bridge_keep_find =
      [](std::vector<std::pair<uint64_t, uint32_t>> &v,
         uint64_t key) -> uint32_t * {
    const auto it = std::lower_bound(
        v.begin(), v.end(), key,
        [](const std::pair<uint64_t, uint32_t> &a, uint64_t b) {
          return a.first < b;
        });
    return it != v.end() && it->first == key ? &it->second : nullptr;
  };
  const auto directed_entry_key = [](Lit from, Lit to) {
    return (static_cast<uint64_t>(from) << 32) | to;
  };
  if (session) {
    affected_binary_owners.reserve(2 * images.size());
    for (const BinaryImage &image : images) {
      affected_binary_owners.push_back(image.source_a);
      affected_binary_owners.push_back(image.source_b);
    }
    std::sort(affected_binary_owners.begin(),
              affected_binary_owners.end());
    affected_binary_owners.erase(
        std::unique(affected_binary_owners.begin(),
                    affected_binary_owners.end()),
        affected_binary_owners.end());
    for (const BinaryImage &stored : images) {
      if (stored.bridge_target_a == INVALID_LIT)
        continue;
      const ExpandedBinaryImage image = expand_image(stored);
      assert(!image.tautological && image.target_a != image.target_b);
      const bool stable_a = image.source_a == image.target_a;
      const bool stable_b = image.source_b == image.target_b;
      if (stable_a && stable_b) {
        // Untouched bridge: both physical directions stay in place.
        bridge_keep_add(bridge_keep_snapshot,
                        directed_entry_key(image.target_a, image.target_b));
        bridge_keep_add(bridge_keep_snapshot,
                        directed_entry_key(image.target_b, image.target_a));
      } else if (stable_a != stable_b) {
        // The in-place pass rewrote the stable direction to the bridge
        // endpoints; only that entry exists before the rebuild below.
        const Lit stable = stable_a ? image.target_a : image.target_b;
        const Lit moved = stable_a ? image.target_b : image.target_a;
        bridge_keep_add(bridge_keep_snapshot,
                        directed_entry_key(stable, moved));
      }
      // Both endpoints moved: nothing survives compaction; both directions
      // are rebuilt from the directed images after it.
    }
    bridge_keep_coalesce(bridge_keep_snapshot);
    bridge_keep_compact = bridge_keep_snapshot;
  }
  std::vector<BinaryImage>().swap(images);
  const auto snapshot_directed = [&](Lit lit) {
    assert(mapped(lit));
    for (const WatchEntry watch : k.watches.entries(lit)) {
      if (!watch.binary())
        continue;
      if (session) {
        uint32_t *const keep = bridge_keep_find(
            bridge_keep_snapshot, directed_entry_key(lit, watch.other()));
        if (keep && *keep) {
          --*keep;
          continue;
        }
      }
      images.push_back(make_image(lit, watch.other()));
    }
  };
  if (session) {
    // Sweep retires one source at a time in equivalence-emission order.  The
    // session already computed that order to replay its logical dense stream;
    // use the same order for the physical watch mirrors that search will later
    // consume.  Import-order reconstruction gave the next Sweep environments
    // the right ledger but left search with a different binary propagation
    // order once sparse mode resumed.
    for (const Lit lit : session->retiring_sources())
      snapshot_directed(lit);
#ifndef NDEBUG
    // Contract, not an optimization: the compaction below drops EVERY binary
    // incident to a substitutable literal, and only a snapshotted direction is
    // rebuilt.  A literal the session fails to name therefore loses its mirror
    // while the opposite direction survives, rewritten in place — a
    // half-watched clause that still propagates but owns no proof identity.
    {
      std::vector<uint8_t> named(nlits, 0);
      for (const Lit lit : session->retiring_sources())
        named[lit] = 1;
      for (Lit l = 0; l < nlits; l++)
        assert((!mapped(l) || named[l]) &&
               "sweep session omitted a substitutable literal");
    }
#endif
  } else {
    for (const Var variable : variable_order)
      for (uint32_t sign = 0; sign < 2; sign++) {
        const Lit lit = make_lit(variable, sign != 0);
        if (mapped(lit))
          snapshot_directed(lit);
      }
  }
  substitute_stage_trace(k, "rewrite-directed-images", images.size(), 0,
                         sizeof(BinaryImage));

  if (connected_only) {
    // Every snapshotted image is exactly one binary with at least one marked
    // endpoint. Remove moved/retired directions in one pass over each watch
    // list. A stable direction rewritten above now has representative
    // endpoints and stays at its original position.
    const auto compact_owner = [&](Lit lit) {
        k.watches.compact(lit, [&](WatchEntry watch) {
          if (!watch.binary())
            return true;
          if (session) {
            // Same first-N consumption order as the snapshot above: the lists
            // are untouched between the two passes, so identical counters
            // protect identical entries.
            uint32_t *const keep = bridge_keep_find(
                bridge_keep_compact, directed_entry_key(lit, watch.other()));
            if (keep && *keep) {
              --*keep;
              return true;
            }
          }
          return !mapped(lit) && !mapped(watch.other());
        });
    };
    if (session)
      for (const Lit lit : affected_binary_owners)
        compact_owner(lit);
    else
      for (const Var variable : variable_order)
        for (uint32_t sign = 0; sign < 2; sign++)
          if (canonical_binary_affected[make_lit(variable, sign != 0)])
            compact_owner(make_lit(variable, sign != 0));
  } else {
    for (const Var variable : variable_order)
      for (uint32_t sign = 0; sign < 2; sign++)
        k.watches.compact(make_lit(variable, sign != 0),
                          [](WatchEntry w) { return !w.binary(); });
  }
  substitute_stage_trace(k, "rewrite-binary-compact", k.watches.arena.size(),
                         k.watches.holes);
  std::vector<Var>().swap(variable_order);
  std::vector<uint8_t>().swap(canonical_binary_affected);
  if (session)
    sparse_seen.clear();
  else
    std::vector<uint8_t>().swap(seen);
  substitute_stage_trace(k, "rewrite-binary-scratch-released");
  // Every forthcoming mirror is known from the immutable image. Pack the
  // current prefixes once into exact final per-literal slices; ordinary pushes
  // below then fill reserved words without global arena growth or relocation.
  if (!session) {
    k.watches.begin_batch_reserve();
    for (const BinaryImage &stored : images) {
      const ExpandedBinaryImage image = expand_image(stored);
      if (image.tautological || image.target_a == image.target_b)
        continue;
      assert(mapped(image.source_a));
      k.watches.reserve_batch_word(image.target_a);
    }
    k.watches.finish_batch_reserve(false);
  }
  substitute_stage_trace(k, "rewrite-binary-reserved", k.watches.arena.size(),
                         k.watches.arena.capacity());
  // Pre-pass: the pair's presence before this batch's first push, grouped by
  // owner, and the first image of each unordered pair. Together they answer
  // the per-image question the scan below used to ask twice.
  std::vector<uint8_t> preexisting;
  std::vector<uint8_t> mirror_seen;
  if (session) {
    std::vector<Lit> owners, others;
    std::vector<uint64_t> keys;
    owners.reserve(images.size());
    others.reserve(images.size());
    keys.reserve(images.size());
    for (const BinaryImage &stored : images) {
      const ExpandedBinaryImage image = expand_image(stored);
      const bool skip = image.tautological || image.target_a == image.target_b;
      owners.push_back(skip ? 0 : image.target_a);
      others.push_back(skip ? 0 : image.target_b);
      keys.push_back(skip ? 0
                          : kernel_binary_key(image.target_a, image.target_b));
    }
    // The compaction above removes a mapped binary only from the owners it
    // touched, so a pair can survive in one endpoint's list and not the
    // other's. Both directions are therefore asked, exactly as the per-image
    // scan did.
    std::vector<uint8_t> mirror_existing;
    session->classify_existing_binaries(k, owners, others, preexisting);
    session->classify_existing_binaries(k, others, owners, mirror_existing);
    for (size_t i = 0; i < preexisting.size(); i++)
      preexisting[i] = static_cast<uint8_t>(preexisting[i] | mirror_existing[i]);
    mirror_seen.assign(images.size(), 0);
    std::vector<uint32_t> by_key(images.size());
    for (size_t i = 0; i < by_key.size(); i++)
      by_key[i] = static_cast<uint32_t>(i);
    std::sort(by_key.begin(), by_key.end(), [&](uint32_t a, uint32_t b) {
      return keys[a] != keys[b] ? keys[a] < keys[b] : a < b;
    });
    for (size_t i = 1; i < by_key.size(); i++)
      if (keys[by_key[i]] == keys[by_key[i - 1]])
        mirror_seen[by_key[i]] = 1;
  }
  size_t image_index = 0;
  size_t rebuilt_images = 0;
  for (const BinaryImage &stored : images) {
    const ExpandedBinaryImage image = expand_image(stored);
    const size_t this_image = image_index++;
    if (image.tautological || image.target_a == image.target_b)
      continue;
    const bool moved_other = image.source_b != image.target_b;
    const bool publish =
        !moved_other || kernel_import_lit_order(k, image.source_a) <
                            kernel_import_lit_order(k, image.source_b);
    uint64_t id = 0;
    if (lrat) {
      const uint64_t target =
          kernel_binary_key(image.target_a, image.target_b);
      const auto it = std::lower_bound(target_keys.begin(), target_keys.end(),
                                       target);
      assert(it != target_keys.end() && *it == target);
      id = target_ids[static_cast<size_t>(it - target_keys.begin())];
      assert(id);
    } else if (publish)
      id = ++k.next_clause_id;
    const bool already_live =
        session ? (preexisting[this_image] || mirror_seen[this_image])
                : (kernel_binary_copies(k, image.target_a, image.target_b, 1) ||
                   kernel_binary_copies(k, image.target_b, image.target_a, 1));
    assert(!session ||
           already_live ==
               (kernel_binary_copies(k, image.target_a, image.target_b, 1) ||
                kernel_binary_copies(k, image.target_b, image.target_a, 1)));
    k.watches.push_binary(image.target_a, image.target_b);
#ifdef TACTIX_ENABLE_EVENT_TRACE
    event_trace_binary_lifecycle(k, "sweep-physical-target", image.target_a,
                                 image.target_b, id,
                                 kernel_binary_copies(k, image.target_a,
                                                      image.target_b));
#endif
    if (publish)
      kernel_publish_binary_clause(k, image.target_a, image.target_b, id,
                                   !already_live);
#ifdef TACTIX_ENABLE_EVENT_TRACE
    if (!(++rebuilt_images % 1000000))
      substitute_stage_trace(k, "rewrite-binary-progress", rebuilt_images,
                             k.watches.arena.size(), k.watches.holes);
#else
    ++rebuilt_images;
#endif
  }
  substitute_stage_trace(k, "rewrite-binary-end", rebuilt_images,
                         k.watches.arena.size(), k.watches.holes);
  std::vector<BinaryImage>().swap(images);
  } // end image-path binary substitution (else of kissat_single_pass)
  if (session)
    sparse_seen.clear();
  else
    seen.assign(nlits, 0);
  substitute_stage_trace(k, "rewrite-large-scratch-restored", seen.size());
  const bool binary_refuted = refuted || flush_units();
  for (const auto &[a, b] : removed_binaries) {
    for (const Lit lit : {a, b}) {
      // In this root-only transformation, a value now present means the
      // unit batch fixed the endpoint. Native removal marks skip fixed vars.
      if (k.value(lit))
        continue;
      kernel_mark_bve_retry(k, var_of(lit), "substitute-delete-binary");
      kernel_removed_var(k, var_of(lit));
    }
    event_trace_binary_lifecycle(k, "substitute-delete-binary", a, b, 0, 0);
  }
  std::vector<std::pair<Lit, Lit>>().swap(removed_binaries);
  if (binary_refuted)
    return ApplyResult::Unsat;
  if (rewrite_large_clauses() == ApplyResult::Unsat)
    return ApplyResult::Unsat;
  substitute_stage_trace(k, "rewrite-large-end", k.arena.size());
  if (flush_units())
    return ApplyResult::Unsat;
  std::vector<uint8_t>().swap(seen);
  sparse_seen.clear();
  std::vector<Lit>().swap(pending.units);
  std::vector<uint64_t>().swap(pending.ids);
  substitute_stage_trace(k, "rewrite-large-scratch-released");

  // (E) Retire every transient equivalence lemma after the rewrite. LRAT names
  // the exact lemma by id. DSR/DRAT name an identical-clause multiset, where
  // physical identity is irrelevant but multiplicity is not: retaining a
  // proof-only copy makes the checker formula strictly larger than the kernel
  // formula. That used to be harmless for RUP-only output, but a later direct
  // SR step must discharge every checker clause and therefore requires exact
  // population counts.
  if (k.proof)
    for_each_substitutable([&](Lit l) {
      const Lit lits2[2] = {negate(l), representative(l)};
      k.proof->del(k.next_clause_id, lrat ? lemma_id(l) : 0, lits2, 2);
    });

  // (F) reconstruction witnesses, once per substituted variable: the
  // order-independent symmetric pair for l ≡ s = repr[l], {¬l, s} witnessed by
  // ¬l and {l, ¬s} witnessed by l, so kernel_extend_model recovers l's value
  // from s regardless of any search assignment to l.
  std::vector<Var> witness_order;
  if (!session) {
    kernel_vars_in_import_order(k, witness_order);
  }
  size_t witness_vars = 0;
  for (const Var v : witness_order)
    witness_vars += substitutable(make_lit(v, false));
  k.retired_events.reserve(k.retired_events.size() + witness_vars);
  k.substituted_events.reserve(k.substituted_events.size() + witness_vars);
  k.reconstruction.reserve(k.reconstruction.size() + 6 * witness_vars);
  substitute_stage_trace(k, "rewrite-witness-reserved", witness_vars,
                         k.reconstruction.capacity(),
                         k.retired_events.capacity());
  for (const Var v : witness_order) {
    const Lit l = make_lit(v, false);
    if (!substitutable(l))
      continue;
    const Lit s = representative(l);
    const Lit rest_a[1] = {s};
    k.stats.substitute_vars++; // one per substituted variable (see Stats)
    // Retire v here, at the witness push: the status and the reconstruction
    // witness must be created together, because a retired variable with no
    // witness is never decided and never reconstructed — a wrong SAT answer
    // rather than a crash (`docs/design/variable-retirement-design-v2.md` §3).
    if (k.var_status.size() < k.nvars)
      k.var_status.resize(k.nvars, VarStatus::Active);
    if (k.var_status[v] == VarStatus::Active &&
        k.values[make_lit(v, false)] == 0) {
      assert(k.unassigned_active > 0); // it leaves the active pool
      k.unassigned_active--;
    }
#ifdef TACTIX_ENABLE_RULE_JOURNAL
    rule_journal_note_variable_status(k, v, "substituted");
#endif
    k.var_status[v] = VarStatus::Substituted;
    k.retired_events.push_back(v);
    k.substituted_events.push_back(v);
    kernel_push_witness(k, negate(l), rest_a, 1); // clause {s, ¬l}
    const Lit rest_b[1] = {negate(s)};
    kernel_push_witness(k, l, rest_b, 1); // clause {¬s, l}
  }
  std::vector<Lit>().swap(r.repr);
  std::vector<Lit>().swap(r.failed_units);
  std::vector<Lit>().swap(r.failed_witness);
  std::vector<uint8_t>().swap(live_sub);
  std::vector<uint64_t>().swap(lemma);
  substitute_stage_trace(k, "rewrite-representatives-released");

  if (changed && session) {
    session->changed = true;
  }
  substitute_stage_trace(k, "rewrite-exit", changed, k.arena.size(),
                         k.watches.arena.size());
  return changed ? ApplyResult::Ok : ApplyResult::NoOp;
}

} // namespace

// Canonical instance: one full round. Detect SCCs; on x ≡ ¬x refute, otherwise
// substitute every non-trivial SCC onto its representative.
ApplyResult substitute_reconnect_large_watches(Kernel &k,
                                               uint32_t trail_begin) {
  assert(!k.large_watches_connected);
  assert(trail_begin <= k.trail.size());
  kernel_rebuild_large_watches(k);
  // Units assigned while the large watches were disconnected reached their
  // closure over binaries only; replay them through the reconnected large
  // clauses (dense.c / substitute.c: kissat_reset_propagate then
  // kissat_probing_propagate).
  k.propagate_head = std::min<uint32_t>(k.propagate_head, trail_begin);
  k.binary_only_head = UINT32_MAX;
  if (inprocess_reach_root(k))
    return ApplyResult::Unsat;
  return ApplyResult::Ok;
}

ApplyResult substitute_apply(Kernel &k) {
  return execution::execute_action(k, execution::SubstituteRoundRequest{});
}

ApplyResult substitute_apply_round(Kernel &k, bool reconnect_large_watches) {
  assert(substitute_guard(k));
  const bool connected_at_entry = k.large_watches_connected;
  const uint32_t trail_at_entry = static_cast<uint32_t>(k.trail.size());
  const auto finish = [&](ApplyResult result) {
    // Restore an owned watch session before publishing even a refutation.
    // The root service recognizes inconsistent state without further reasoning.
    if (!connected_at_entry || !reconnect_large_watches ||
        k.large_watches_connected)
      return result;
    const ApplyResult closure =
        substitute_reconnect_large_watches(k, trail_at_entry);
    return closure == ApplyResult::Unsat ? closure : result;
  };
  // D-LEVEL: drain the root closure (no-op at a fixpoint); a conflict refutes.
  if (inprocess_reach_root(k))
    return ApplyResult::Unsat;
  k.stats.substitute_rounds++;
  SccResult r = substitute_find_sccs(k, false);
  substitute_stage_trace(k, "scc-return", r.nontrivial_count,
                         r.failed_units.size(), r.repr.capacity());
#ifdef TACTIX_ENABLE_EVENT_TRACE
  for (Lit l = 0; l < static_cast<Lit>(2 * k.nvars); l++)
    event_trace_substitute_map(k, l, r.repr[l]);
#endif
  substitute_stage_trace(k, "scc-event-map-end");
  if (r.contradiction) {
    assert(r.contradiction_lit != INVALID_LIT);
    emit_unsat(k, r.contradiction_lit);
    return ApplyResult::Unsat;
  }
  const ApplyResult failed = apply_failed_root_units(k, r);
  substitute_stage_trace(k, "scc-failed-units-end", r.failed_units.size());
  if (failed == ApplyResult::Unsat)
    return failed;
  k.stats.substitute_sccs += r.nontrivial_count; // counted before the
  // Every round also runs Kissat's `substitute_clauses`: even with no
  // non-trivial SCC, root units produced by the preceding Sweep can satisfy
  // large clauses or shrink them to binaries.  Returning here used to leave
  // those clauses stale and was the first FmlaEquivChain divergence after an
  // otherwise identical Sweep consequence set.
  std::vector<uint8_t> sub(2 * k.nvars, 0);
  substitute_stage_trace(k, "scc-sub-map", sub.size(), sub.capacity());
  for (Lit l = 0; l < static_cast<Lit>(2 * k.nvars); l++)
    if (r.repr[l] != INVALID_LIT && r.repr[l] != l) {
      sub[l] = 1;
      k.stats.substitute_scc_lits++;
    }
  // Kissat's round-one SCC pass still sees the large watches (their words
  // are part of its tick charge); `substitute_binaries` then drops them, so
  // the rewrite below touches bare clause records and no watch list.
  if (k.large_watches_connected)
    kernel_drop_large_watches(k);
  const ApplyResult rewritten = do_substitution(k, r, std::move(sub));
  if (rewritten == ApplyResult::NoOp && failed == ApplyResult::Ok)
    return finish(ApplyResult::Ok);
  return finish(rewritten);
}

ApplyResult substitute_apply_complete(Kernel &k, uint32_t max_rounds) {
  return execution::execute_action(
             k, execution::SubstituteBatchRequest{max_rounds},
             [&] { return execution::substitute_complete_active_count(k); },
             [](size_t) {},
             [&](uint64_t active_before, ApplyResult current) {
               return current != ApplyResult::Unsat &&
                      execution::substitute_complete_active_count(k) != active_before;
             })
      .result;
}

static ApplyResult substitute_apply_equivalences_impl(
    Kernel &k, const std::vector<std::pair<Lit, Lit>> &equivalences,
    bool drain_root) {
  if (equivalences.empty())
    return ApplyResult::NoOp;
  assert(k.level == 0 && !k.conflict_valid);
  if (drain_root && inprocess_reach_root(k))
    return ApplyResult::Unsat;
  k.stats.substitute_rounds++;
  SccResult r = substitute_find_sccs(k, false);
  if (r.contradiction) {
    assert(r.contradiction_lit != INVALID_LIT);
    emit_unsat(k, r.contradiction_lit);
    return ApplyResult::Unsat;
  }
  k.stats.substitute_sccs += r.nontrivial_count;
  std::vector<uint8_t> sub(2 * k.nvars, 0);
  for (const auto &eq : equivalences) {
    const Lit a = eq.first, b = eq.second;
    if (a >= r.repr.size() || b >= r.repr.size())
      continue;
    const Lit rep = r.repr[a];
    if (rep == INVALID_LIT || r.repr[b] != rep)
      continue; // the supplied binaries no longer state a live SCC class
    const Lit mirror = r.repr[negate(a)];
    for (Lit l = 0; l < static_cast<Lit>(r.repr.size()); l++)
      if (r.repr[l] != INVALID_LIT && r.repr[l] != l &&
          (r.repr[l] == rep || r.repr[l] == mirror)) {
        if (!sub[l])
          k.stats.substitute_scc_lits++;
        sub[l] = 1;
      }
  }
  if (std::none_of(sub.begin(), sub.end(), [](uint8_t marked) {
        return marked != 0;
      }))
    return ApplyResult::NoOp;
  // This path implements Kissat Sweep's connected-clause rewrite. Surviving
  // large records stay at their existing Ref; lazy unit/binary/deleted records
  // do not need an arena-order transaction at this call boundary.
  return do_substitution(k, r, std::move(sub));
}

ApplyResult substitute_apply_equivalences(
    Kernel &k, const std::vector<std::pair<Lit, Lit>> &equivalences) {
  return substitute_apply_equivalences_impl(k, equivalences, true);
}

ApplyResult substitute_apply_sweep_equivalences(
    Kernel &k, const std::vector<std::pair<Lit, Lit>> &equivalences,
    SweepSubstitutionSession &session,
    std::vector<std::pair<Lit, Lit>> *applied_images) {
  if (applied_images) applied_images->clear();
  if (equivalences.empty())
    return ApplyResult::NoOp;
  assert(k.level == 0 && !k.conflict_valid);

  // Sweep published both implication binaries before calling in, so the ledger
  // owes them a stream position whatever the classes below decide.  Declining
  // every class is a normal outcome — a proved endpoint can be root-fixed by
  // the units of the same batch — and returning first left those binaries live
  // in the watch lists but invisible to every later environment.
  session.sync_new_binaries(k, equivalences);

  // Sweep has just inserted both implication binaries for every pair.  Its
  // resumable loop needs those identities substituted before choosing the next
  // seed, but a whole-formula Tarjan pass here makes that bridge O(seeds * F).
  // Build exactly the equivalence classes stated by this emission batch; any
  // older/larger SCC remains visible to the normal Substitute slot immediately
  // after Sweep.  This is complete for the requested rewrite and preserves the
  // same minimum-import-order representative as substitute_find_sccs.
  const Lit nlits = static_cast<Lit>(2 * k.nvars);
  std::vector<Lit> members;
  members.reserve(4 * equivalences.size());
  for (const auto &eq : equivalences) {
    const Lit a = eq.first, b = eq.second;
    if (a >= nlits || b >= nlits || a == b || a == negate(b) ||
        k.value(a) != 0 || k.value(b) != 0)
      continue;
    members.insert(members.end(), {a, b, negate(a), negate(b)});
  }
  if (members.empty())
    return ApplyResult::NoOp;
  std::sort(members.begin(), members.end());
  members.erase(std::unique(members.begin(), members.end()), members.end());

  std::vector<uint32_t> parent(members.size());
  std::iota(parent.begin(), parent.end(), 0);
  const auto index_of = [&](Lit l) {
    const auto it = std::lower_bound(members.begin(), members.end(), l);
    assert(it != members.end() && *it == l);
    return static_cast<uint32_t>(it - members.begin());
  };
  const auto find = [&](uint32_t start) {
    uint32_t root = start;
    while (parent[root] != root)
      root = parent[root];
    while (parent[start] != start) {
      const uint32_t next = parent[start];
      parent[start] = root;
      start = next;
    }
    return root;
  };
  // Kissat proves one equivalence at a time and substitutes it before the next
  // is even attempted, so the retiring literal of each merge releases its whole
  // watch stream into the winner's, in merge order (sweep.c `sweep_equivalence`
  // -> `substitute_connected_clauses`). A literal that lost an earlier merge of
  // the same batch therefore travels inside the block of the literal it lost
  // to, not as a peer of it. Record the merge forest here, and read that order
  // back below; the final representative map alone cannot express it.
  std::vector<std::vector<Lit>> absorbed(members.size());
  const auto unite = [&](Lit a, Lit b) -> int {
    uint32_t ra = find(index_of(a)), rb = find(index_of(b));
    if (ra == rb)
      return -1;
    const uint32_t root_a = ra;
    if (kernel_import_lit_order(k, members[rb]) <
        kernel_import_lit_order(k, members[ra]))
      std::swap(ra, rb);
    const int losing_side = rb == root_a ? 0 : 1;
    parent[rb] = ra;
    absorbed[ra].push_back(members[rb]);
    return losing_side;
  };
  struct ProductivePair {
    Lit a, b;
    int losing_side;
  };
  std::vector<ProductivePair> productive;
  productive.reserve(equivalences.size());
  for (const auto &eq : equivalences) {
    const Lit a = eq.first, b = eq.second;
    if (a >= nlits || b >= nlits || a == b || a == negate(b) ||
        k.value(a) != 0 || k.value(b) != 0)
      continue;
    const int losing_side = unite(a, b);
    const int mirror_losing_side = unite(negate(a), negate(b));
    assert(losing_side == mirror_losing_side);
    (void)mirror_losing_side;
    if (losing_side < 0)
      continue;
    productive.push_back({a, b, losing_side});
  }
  // Sweep emitted (not a v b) and (a v not b) for each productive pair, and
  // Kissat exempts them only from their own pair's substitution: every later
  // merge still rewrites both endpoints (`substitute_connected_clauses` skips
  // exactly `other == NOT (repr)`). Replay that suffix composition backwards
  // so each preserved bridge carries the endpoints the sequential process
  // leaves behind. Jumping an endpoint straight to the final representative
  // instead drops the chain link owed to a class winner that loses a later
  // merge which never names it, and the mandated Substitute can no longer
  // rediscover the complete union.
  std::vector<SweepSubstitutionSession::EquivalenceBridge> bridges;
  bridges.reserve(2 * productive.size());
  {
    std::unordered_map<Lit, Lit> suffix; // identity where absent
    const auto suffix_image = [&](Lit l) {
      const auto it = suffix.find(l);
      return it == suffix.end() ? l : it->second;
    };
    for (size_t i = productive.size(); i--;) {
      const ProductivePair &pair = productive[i];
      bridges.push_back({negate(pair.a), pair.b,
                         suffix_image(negate(pair.a)),
                         suffix_image(pair.b)});
      bridges.push_back({pair.a, negate(pair.b), suffix_image(pair.a),
                         suffix_image(negate(pair.b))});
      const Lit loser = pair.losing_side ? pair.b : pair.a;
      const Lit winner = pair.losing_side ? pair.a : pair.b;
      const Lit winner_image = suffix_image(winner);
      const Lit winner_mirror = suffix_image(negate(winner));
      suffix[loser] = winner_image;
      suffix[negate(loser)] = winner_mirror;
    }
  }

  SccResult r;
  std::vector<uint32_t> class_size(members.size(), 0);
  for (uint32_t i = 0; i < members.size(); i++)
    class_size[find(i)]++;
  for (uint32_t i = 0; i < members.size(); i++) {
    const uint32_t root = find(i);
    if (i == root && class_size[root] > 1)
      r.nontrivial_reps.push_back(members[root]);
  }
  std::sort(r.nontrivial_reps.begin(), r.nontrivial_reps.end(),
            [&](Lit a, Lit b) {
              return kernel_import_lit_order(k, a) <
                     kernel_import_lit_order(k, b);
            });
  r.nontrivial_count = r.nontrivial_reps.size();

  k.stats.substitute_rounds++;
  k.stats.substitute_sccs += r.nontrivial_count;
  std::vector<std::pair<Lit, Lit>> sparse_map;
  sparse_map.reserve(members.size());
  for (uint32_t i = 0; i < members.size(); i++) {
    const Lit l = members[i];
    const Lit image = members[find(i)];
    if (image != l) {
      sparse_map.emplace_back(l, image);
      k.stats.substitute_scc_lits++;
    }
  }

  // Pre-order walk of the merge forest: a retiring literal is followed by
  // everything it had already absorbed, which is exactly the stream Kissat
  // hands to `substitute_connected_clauses` at the moment that literal retires.
  // Both polarities are separate roots and their streams never mix, so the
  // relative order of the two halves is not observable.
  std::vector<Lit> sources;
  sources.reserve(members.size());
  {
    std::vector<uint32_t> pending;
    const auto descend = [&](uint32_t node) {
      for (auto it = absorbed[node].rbegin(); it != absorbed[node].rend(); ++it)
        pending.push_back(index_of(*it));
    };
    for (uint32_t i = 0; i < members.size(); i++) {
      if (find(i) != i)
        continue; // reached from the root that absorbed it
      descend(i);
      while (!pending.empty()) {
        const uint32_t node = pending.back();
        pending.pop_back();
        sources.push_back(members[node]);
        descend(node);
      }
    }
  }

  session.rewrite_binary_occurrences(k, sparse_map, sources, bridges);
  const ApplyResult result = do_substitution(k, r, {}, &session);
  // flush_moves closes the transaction and clears its sparse mapping. A
  // composing caller needs the actual rewrite image, including polarity, to
  // translate later requests that were selected before this transaction.
  if (applied_images)
    for (const Lit lit : session.retiring_sources())
      applied_images->emplace_back(lit, session.representative(lit));
  session.flush_moves(k);
  // `rewrite_binary_occurrences` predicts the dense stream before the physical
  // rewrite, while units and large-clause collapses inside `do_substitution`
  // can decline or replace those images. Restore the stated membership
  // invariant before the next seed consumes the ledger.
  session.sync_new_binaries(k, equivalences);
  return result;
}

// Instance surface: payload = an SCC representative literal. A single instance
// substitutes the requested class — the SCC with representative `rep` and its
// mirror ¬rep — so both polarities of every member variable go together.
static uint32_t substitute_instances(Kernel &k, uint64_t *out, uint32_t cap) {
  // Public enumeration observes the current frontier. It must not spend the
  // solver's work currency before the caller chooses an instance.
  SccResult r = substitute_find_sccs(k, true, false);
  const uint32_t n =
      std::min<uint32_t>(cap, static_cast<uint32_t>(r.nontrivial_reps.size()));
  for (uint32_t i = 0; i < n; i++)
    out[i] = lit_instance(k, r.nontrivial_reps[i]);
  return n;
}

static ApplyResult substitute_apply_instance(Kernel &k, uint64_t inst) {
  // D-LEVEL: drain the root closure (no-op at a fixpoint); a conflict refutes.
  if (inprocess_reach_root(k))
    return ApplyResult::Unsat;
  if (inst == INSTANCE_CANONICAL)
    return substitute_apply(k);
  Lit rep;
  if (!lit_of_instance(k, inst, &rep))
    return ApplyResult::NoOp;
  if (var_of(rep) >= k.nvars || k.values[rep] != 0)
    return ApplyResult::NoOp;
  // re-derive from the live graph, which may have changed since instances()
  k.stats.substitute_rounds++;
  SccResult r = substitute_find_sccs(k, false);
  if (r.contradiction) { // a global x ≡ ¬x refutes regardless of the request
    assert(r.contradiction_lit != INVALID_LIT);
    emit_unsat(k, r.contradiction_lit);
    return ApplyResult::Unsat;
  }
  // substitute only members whose representative is rep or its mirror ¬rep; a
  // dissolved SCC marks nothing and yields NoOp
  k.stats.substitute_sccs += r.nontrivial_count;
  const Lit nrep = negate(rep);
  std::vector<uint8_t> sub(2 * k.nvars, 0);
  bool any = false;
  for (Lit l = 0; l < static_cast<Lit>(2 * k.nvars); l++)
    if (r.repr[l] != INVALID_LIT && r.repr[l] != l &&
        (r.repr[l] == rep || r.repr[l] == nrep)) {
      sub[l] = 1;
      any = true;
    }
  if (!any)
    return ApplyResult::NoOp;
  return do_substitution(k, r, std::move(sub));
}

TACTIX_REGISTER_RULE(Substitute, RuleTier::Inprocess, substitute_guard,
                     substitute_apply, substitute_instances,
                     substitute_apply_instance);

} // namespace tactix
