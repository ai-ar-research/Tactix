#include "policies/default_policy.hpp"
#include "diagnostics/event_trace.hpp"
#include "diagnostics/rule_journal.hpp"
#include "policies/heuristics.hpp"

#include "rules/analyze/analyze.hpp"
#include "rules/backjump/backjump.hpp"
#include "rules/bce/bce.hpp"
#include "rules/bve/bve.hpp"
#include "rules/decide/decide.hpp"
#include "rules/lucky/lucky.hpp"
#include "rules/propagate/propagate.hpp"
#include "rules/reduce/reduce.hpp"
#include "policies/ops/rephase/rephase.hpp"
#include "policies/ops/reorder/reorder.hpp"
#include "policies/ops/local_search/local_search.hpp"
#include "rules/lucky/parity_model.hpp"
#include "rules/lucky/parity_refutation.hpp"
#include "rules/lucky/count_preservation.hpp"
#include "rules/lucky/onehot_model.hpp"
#include "rules/lucky/exact_one_refutation.hpp"
#include "rules/lucky/balanced_signature_model.hpp"
#include "rules/lucky/fermat_model.hpp"
#include "rules/lucky/cerny_model.hpp"
#include "rules/lucky/lookup_circuit_model.hpp"
#include "rules/lucky/simon_model.hpp"
#include "rules/lucky/stconn_proof.hpp"
#include "rules/lucky/signed_cardinality_proof.hpp"
#include "rules/lucky/exact_cover_model.hpp"
#include "rules/lucky/independent_set_model.hpp"
#include "policies/ops/walk/walk.hpp"
#include "rules/restart/restart.hpp"
#include "rules/registry.hpp"
#include "rules/strengthen/strengthen.hpp"
#include "rules/subsume_forward/subsume_forward.hpp"
#include "rules/substitute/substitute.hpp"
#include "rules/sweep/sweep.hpp"
#include "rules/vivify/vivify.hpp"
#include "policies/ops/switchmode/switchmode.hpp"
#include "strategy/bve_invocation.hpp"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <csignal>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <optional>
#include <sstream>
#include <utility>

namespace tactix {

double kissat_bve_variable_score(double relevance, uint64_t positive,
                                 uint64_t negative,
                                 uint64_t occurrence_limit) {
  positive = std::min(positive, occurrence_limit);
  negative = std::min(negative, occurrence_limit);
  const double product = positive * negative;
  const double sum = positive + negative;
  const double occurrence_limit_squared =
      occurrence_limit * static_cast<double>(occurrence_limit);
  const double structural_score = product - sum;
  return relevance + structural_score - occurrence_limit_squared;
}

namespace {
template <class Apply>
ApplyResult default_direct_rule(Kernel &k, const char *name,
                                const std::string &candidate, Apply &&apply,
                                ApplyResult declined_result =
                                    ApplyResult::NoOp) {
#ifdef TACTIX_ENABLE_RULE_JOURNAL
  return journal_direct_rule(k, name, candidate,
                             std::function<ApplyResult()>(apply),
                             declined_result);
#else
  (void)k;
  (void)name;
  (void)candidate;
  (void)declined_result;
  return apply();
#endif
}

// Candidate descriptions are diagnostic rule-journal data, not part of the
// production rule transition.  Keep dynamic descriptions lazy so a build
// without the journal does not allocate and shift a string for every hot-path
// application (in particular, every decision).
template <class Candidate, class Apply>
ApplyResult default_direct_rule_lazy(
    Kernel &k, const char *name, Candidate &&candidate, Apply &&apply,
    ApplyResult declined_result = ApplyResult::NoOp) {
#ifdef TACTIX_ENABLE_RULE_JOURNAL
  return journal_direct_rule(k, name, candidate(),
                             std::function<ApplyResult()>(apply),
                             declined_result);
#else
  (void)k;
  (void)name;
  (void)candidate;
  (void)declined_result;
  return apply();
#endif
}

ApplyResult default_propagate(Kernel &k, const char *candidate) {
  const size_t trail_begin = k.trail.size();
  const uint64_t root_assignments = k.stats.root_assignments;
  const ApplyResult result = default_direct_rule(
      k, "Propagate", candidate, [&] { return propagate_apply(k); },
      ApplyResult::Ok);
  // Kissat marks every true-level-zero assignment fixed in its assignment
  // primitive. Keep the proof rule independent of policy state, but consume
  // the same lifecycle transition before DefaultPolicy next chooses a rule or
  // decision. This includes root implications discovered above level zero.
  if (k.stats.root_assignments != root_assignments)
    heuristics_consume_root_assignments(k, trail_begin);
  return result;
}

ApplyResult default_lucky(Kernel &k, const char *candidate) {
  const size_t trail_begin = k.trail.size();
  const uint64_t roots_before = k.stats.root_assignments;
  const ApplyResult result = default_direct_rule(
      k, "Lucky", candidate, [&] { return lucky_apply(k); });
  // Lucky can prove failed-literal units even when every model probe fails.
  // Its root entry prefix survives speculative backtracking, so consume the
  // appended roots in assignment order before any later policy consumer.
  // Kissat deactivates these identities in assignment; raw Lucky stays
  // independent of guidance here. The deferred early call still has no H:
  // its subsequent attachment reconstructs the same fixed-variable image.
  if (k.stats.root_assignments != roots_before)
    heuristics_consume_root_assignments(k, trail_begin);
  return result;
}
} // namespace

ApplyResult default_resume_sparse_propagation(Kernel &k,
                                              uint32_t trail_begin,
                                              bool charge_search_ticks) {
  assert(k.level == 0);
  assert(trail_begin <= k.trail.size());
  // Kissat clears its old root trail on phase entry, then resets propagation
  // to the beginning of the suffix produced by the simplifier after sparse
  // watches are rebuilt. Tactix retains immutable root identities, so the
  // equivalent cursor is the saved suffix boundary, not literal trail zero.
  k.propagate_head = trail_begin;
  k.binary_only_head = UINT32_MAX;
  const bool saved_inprocessing = k.inprocessing;
  if (charge_search_ticks)
    k.inprocessing = false;
  const ApplyResult result =
      default_propagate(k, charge_search_ticks ? "eliminate-sparse-resume"
                                               : "probe-sparse-resume");
  k.inprocessing = saved_inprocessing;
  return result;
}

void default_prepare_reduction(Kernel &k) {
  const uint64_t roots_before = k.stats.root_assignments;
  reduce_prepare(k);
  const uint64_t new_roots = k.stats.root_assignments - roots_before;
  if (new_roots) {
    // Preparation backtracks before its root-only propagation. The incoming
    // trail length is not a valid suffix cursor after that truncation; every
    // new root is instead in the final appended suffix, including on conflict.
    assert(new_roots <= k.trail.size());
    heuristics_consume_root_assignments(k, k.trail.size() - new_roots);
  }
}

bool default_should_cleanup_unique_literal_amo(
    uint64_t binaries_added, bool later_progress,
    bool generic_graph_root_progress) {
  return binaries_added && later_progress && !generic_graph_root_progress;
}

bool default_should_seed_structured_residual(
    bool grew_root_trail, uint64_t unique_literal_amo_binaries,
    bool generic_graph_root_progress) {
  return grew_root_trail &&
         (!unique_literal_amo_binaries || generic_graph_root_progress);
}

bool default_should_run_initial_fast_elimination(uint64_t candidates,
                                                 uint64_t active) {
  return candidates && candidates > active - std::min(candidates, active);
}

bool default_fast_elimination_discovery_admissible(uint64_t active,
                                                   uint64_t remaining) {
  // Discovery has to inspect every live variable before the owner order is
  // known. Reserve an equal amount of the shared dose for the transformation;
  // otherwise startup would pay mostly to construct a domain that can only be
  // mutated by a short, incomplete prefix.
  return active && active <= remaining / 2;
}

bool default_should_run_fast_elimination_after_structured(
    bool structured_root_grew_trail) {
  // A new root assignment rebuilds the residual search seed, so another
  // startup formula transformation would stack two independent trajectory
  // changes.  Clause-only structured progress composes with FastEliminate and
  // retains the owner's opportunity.
  return !structured_root_grew_trail;
}

namespace {
uint32_t binary_scale(uint64_t active) {
  if (!active)
    return 0;
  uint32_t result = 0;
  for (uint64_t bound = 1; bound < active;) {
    ++result;
    if (bound > UINT64_MAX / 2)
      break;
    bound <<= 1;
  }
  return std::max(result, uint32_t{1});
}
} // namespace

bool default_fast_elimination_material_progress(uint64_t eliminated,
                                                uint64_t active) {
  if (!eliminated || !active)
    return false;
  const uint64_t scale = binary_scale(active);
  return eliminated >= active / scale + !!(active % scale);
}

bool default_fast_elimination_admits_mab_at_entry(uint64_t eliminated,
                                                  uint64_t residual_active,
                                                  bool producer_complete) {
  // A material minority reduction changes the residual enough to admit the
  // owner's two-arm search immediately.  If elimination removed at least half
  // of the entry domain, preserve a baseline opportunity on the compact
  // residual instead.  Both boundaries derive from producer outcomes.
  return producer_complete && eliminated < residual_active &&
         default_fast_elimination_material_progress(eliminated,
                                                    residual_active);
}

uint64_t default_mab_stagnation_conflict_budget(uint64_t active,
                                                bool accelerated) {
  if (!active)
    return 0;
  if (accelerated)
    return 0;
  const uint64_t scale = binary_scale(active);
  return active > UINT64_MAX / scale
             ? UINT64_MAX
             : active * scale;
}

bool default_mab_stagnation_reached(uint64_t conflicts,
                                    uint64_t activation_conflict) {
  return conflicts >= activation_conflict;
}

bool default_should_schedule_delayed_mab(bool enabled, bool delayed,
                                         uint64_t sr_applications) {
  return enabled && delayed && !sr_applications;
}

namespace {
// Unit conversions and protocol values, not strategy parameters.
constexpr uint64_t PERMILLE_SCALE = 1000;

// Kissat's SET_EFFORT_LIMIT converts the per-mille option to a scale factor
// and only truncates after multiplying by the complete reference.  Splitting
// the quotient and remainder keeps that floor exact without overflowing the
// uint64_t product for the supported 0..1000 per-mille range.
static uint64_t scale_permille(uint64_t reference, uint32_t permille) {
  assert(permille <= PERMILLE_SCALE);
  return reference / PERMILLE_SCALE * permille +
         reference % PERMILLE_SCALE * permille / PERMILLE_SCALE;
}
constexpr uint64_t PERCENT_SCALE = 100;
constexpr uint32_t MODES_PER_CYCLE = 2;
constexpr uint32_t REORDER_STABLE_ONLY = 2;

void pose_tiers(Kernel &k, uint8_t tier1_mode, uint8_t tier2_mode) {
  assert(tier1_mode < MODES_PER_CYCLE && tier2_mode < MODES_PER_CYCLE);
  k.tier1 = k.tier1_by_mode[tier1_mode];
  k.tier2 = std::max(k.tier1, k.tier2_by_mode[tier2_mode]);
}

void pose_reduce_tiers(Kernel &k,
                       const DefaultStrategyConfig::Reduction &config) {
  // Kissat 4.0.4's shipped internal.h deliberately uses focused tier-1 and
  // stable tier-2 for Reduce (the general focusedtiers selector is compiled
  // out). Keep the unusual hybrid explicit: it is the first-reduction witness
  // on P4A tr-n300-s055, not an inferred simplification.
  pose_tiers(k, config.reduce_tier1_mode, config.reduce_tier2_mode);
}

void pose_vivify_tiers(Kernel &k,
                       const DefaultStrategyConfig::Inprocess &config) {
  pose_tiers(k, config.vivify_tier_mode, config.vivify_tier_mode);
}

void retier_current_mode(Kernel &k,
                         const DefaultStrategyConfig::Reduction &config) {
  const uint32_t mode = k.h && k.h->stable ? 1u : 0u;
  reduce_retier(k, mode, config.tier1_default, config.tier2_default,
                config.tier1_relative_permille,
                config.tier2_relative_permille);
}
} // namespace

strategy::OnlineStrategyProgram
DefaultStrategyConfig::reference_structured_root_program() {
  strategy::OnlineInvocation pure;
  pure.id = 1000;
  pure.rule = "BVE";
  strategy::BveParameters pure_parameters;
  // The owner closes pure literals inside its simplification (satsuma.h).
  pure_parameters.candidate_scope = strategy::BveCandidateScope::PureClosure;
  pure.parameters = pure_parameters;
  pure.granularity = strategy::InvocationGranularity::CompleteCurrentPass;
  pure.work_unit = strategy::WorkUnit::BveTicks;
  pure.post_application = strategy::PostApplication::Propagate;

  strategy::OnlineInvocation orbitopal;
  orbitopal.id = 1001;
  orbitopal.rule = "SubstitutionRedundancy";
  SubstitutionRedundancyParameters orbitopal_parameters;
  orbitopal_parameters.maximum_validation_ticks = 10'000'000;
  orbitopal_parameters.producer =
      SubstitutionRedundancyProducer::Orbitopal;
  // The two-dimensional refinement producer needs both axes so it can select
  // the ULC-bearing dimension after exact row and column checks. One-axis
  // matrices continue to emit only their independently certified action.
  orbitopal_parameters.orbitopal_orientation = OrbitopalOrientation::Both;
  orbitopal_parameters.minimum_orbitopal_rows = 2;
  orbitopal_parameters.minimum_orbitopal_columns = 2;
  // A complete orbitopal pass is the semantic scheduling unit.  A finite
  // matrix prefix can miss a later productive matrix and, because truncation
  // correctly stops the startup program, can suppress every following
  // producer.  Keep caller-selected finite prefixes available through the
  // typed interface, but let the reference program enumerate the full pass.
  orbitopal_parameters.maximum_orbitopal_matrices = UINT64_MAX;
  orbitopal_parameters.maximum_orbitopal_instances = UINT64_MAX;
  orbitopal_parameters.minimum_orbitopal_clique_columns = 5;
  orbitopal_parameters.maximum_orbitopal_clique_vertices = 100'000;
  orbitopal_parameters.maximum_orbitopal_clique_ticks = 10'000'000;
  orbitopal_parameters.maximum_orbitopal_product_states = 100'000;
  orbitopal_parameters.complete_unique_literal_amos = true;
  // Orbitopal refinement owns structured row actions. Generic generator
  // fixing is the following GraphSymmetry sub-strategy; repeating it inside
  // every inexact refinement orbit duplicates formula-wide group work and can
  // delay an already available exact structured action.
  orbitopal_parameters.orbitopal_generator_fallback = false;
  // Bound repeated pointwise-stabilizer refinement in the reference startup
  // schedule. Callers retain zero, finite, and unbounded choices through the
  // typed parameter surface.
  orbitopal_parameters.maximum_orbitopal_refinement_orbits = 64;
  orbitopal_parameters.orbitopal_progress_feedback = true;
  orbitopal_parameters.maximum_detection_ticks = UINT64_MAX;
  orbitopal_parameters.orbitopal_column_order =
      OrbitopalColumnOrder::CooccurrenceGreedyClique;
  orbitopal_parameters.orbitopal_completion =
      OrbitopalCompletion::IndividualizedGraphCompletion;
  // Consume formula-derived structured columns before asking the generic
  // equitable partition for candidate row orbits. The scoped-fixpoint repeat
  // resumes the generic phase after the cheaper producer stops making
  // progress.
  orbitopal_parameters.orbitopal_discovery_order =
      OrbitopalDiscoveryOrder::UniqueLiteralThenRefinement;
  orbitopal_parameters.graph_symmetry.maximum_graph_vertices =
      SYMMETRY_GRAPH_COMPONENT_LIMIT_DEFAULT;
  orbitopal_parameters.graph_symmetry.maximum_graph_edges =
      SYMMETRY_GRAPH_EDGE_LIMIT_DEFAULT;
  orbitopal_parameters.graph_symmetry.maximum_generators =
      SYMMETRY_GENERATOR_LIMIT_DEFAULT;
  orbitopal_parameters.graph_symmetry.backend_search_budget =
      SYMMETRY_BACKTRACK_LIMIT_DEFAULT;
  orbitopal_parameters.graph_symmetry.backend_support_budget =
      SYMMETRY_SUPPORT_LIMIT_DEFAULT;
  orbitopal_parameters.graph_symmetry.backend_component_size_limit =
      SYMMETRY_GRAPH_COMPONENT_LIMIT_DEFAULT;
  orbitopal.parameters = orbitopal_parameters;
  orbitopal.granularity =
      strategy::InvocationGranularity::CompleteCurrentPass;
  // ULC completion deliberately emits only its binary phase in the current
  // pass. Re-enumerate this producer against that strengthened formula before
  // a later sub-strategy can stop the outer sequence.
  orbitopal.repeat = {strategy::RepeatMode::UntilScopedFixpoint, 0};
  orbitopal.post_application = strategy::PostApplication::Propagate;

  strategy::OnlineInvocation graph;
  graph.id = 1002;
  graph.rule = "SubstitutionRedundancy";
  SubstitutionRedundancyParameters graph_parameters;
  graph_parameters.maximum_validation_ticks =
      SYMMETRY_TOTAL_TICK_LIMIT_DEFAULT;
  graph_parameters.maximum_detection_ticks =
      SYMMETRY_TOTAL_TICK_LIMIT_DEFAULT;
  graph_parameters.producer =
      SubstitutionRedundancyProducer::GraphSymmetry;
  graph_parameters.graph_symmetry.maximum_graph_vertices =
      SYMMETRY_GRAPH_COMPONENT_LIMIT_DEFAULT;
  graph_parameters.graph_symmetry.maximum_graph_edges =
      SYMMETRY_GRAPH_EDGE_LIMIT_DEFAULT;
  graph_parameters.graph_symmetry.maximum_generators =
      SYMMETRY_GENERATOR_LIMIT_DEFAULT;
  graph_parameters.graph_symmetry.backend_search_budget =
      SYMMETRY_BACKTRACK_LIMIT_DEFAULT;
  graph_parameters.graph_symmetry.backend_support_budget =
      SYMMETRY_SUPPORT_LIMIT_DEFAULT;
  graph_parameters.graph_symmetry.backend_component_size_limit =
      SYMMETRY_GRAPH_COMPONENT_LIMIT_DEFAULT;
  graph_parameters.graph_symmetry.maximum_fixing_instances =
      SYMMETRY_FIXING_LIMIT_DEFAULT;
  // One direct generator changes the stabilizer used by the next pass.  Fresh
  // detection is therefore the complete semantic unit, matching the
  // Satsuma-derived scheduling experiment rather than retaining a stale
  // generator prefix.
  graph_parameters.graph_symmetry.maximum_generator_instances_per_pass = 1;
  graph_parameters.graph_symmetry.maximum_group_ticks =
      SYMMETRY_TOTAL_TICK_LIMIT_DEFAULT;
  graph_parameters.graph_symmetry.clause_scope = SymmetryClauseScope::All;
  graph_parameters.graph_symmetry.binary_graph_mode =
      SymmetryBinaryGraphMode::Automatic;
  graph_parameters.graph_symmetry.binary_graph_density_permille =
      SYMMETRY_BINARY_DENSITY_PERMILLE_DEFAULT;
  graph_parameters.graph_symmetry.clause_selection =
      SymmetryClauseSelection::AmoThenShortest;
  graph_parameters.graph_symmetry.chain_mode = SymmetryChainMode::FixAndCut;
  graph_parameters.graph_symmetry.base_selection =
      SymmetryBaseSelection::CommonClauseAmo;
  // Satsuma fixes negation orbits before fix-and-cut, fixes a clause only
  // through its first stored literal, and cuts at the largest stabilizer
  // orbit's highest variable (symmetries.h negation_fixing_schreier,
  // orbit_overlaps_clause, find_non_trivial_orbit).
  graph_parameters.graph_symmetry.cut_point = SymmetryCutPoint::LargestOrbitLast;
  graph_parameters.graph_symmetry.negation_fixing_first = true;
  graph_parameters.graph_symmetry.first_literal_fix_anchor = true;
  graph.parameters = graph_parameters;
  graph.granularity = strategy::InvocationGranularity::CompleteCurrentPass;
  graph.post_application = strategy::PostApplication::Propagate;

  strategy::OnlineStrategyProgram result;
  result.sequence =
      {std::move(pure), std::move(orbitopal), std::move(graph)};
  // Repeat to the program's scoped no-progress boundary. Root assignments
  // alone are not a termination measure: ULC can add useful binaries without
  // fixing a variable. An incomplete budget stop is not a scoped fixpoint.
  // satsuma.h iteration_max with its iteration_limit of 128.
  result.repeat = {strategy::RepeatMode::UntilSizeScaledFixpoint, 128};
  return result;
}

bool DefaultStrategyConfig::valid(std::string *error) const {
  const auto reject = [error](const char *message) {
    if (error)
      *error = message;
    return false;
  };
  const auto positive_finite = [](double value) {
    return std::isfinite(value) && value > 0.0;
  };
  if (!branching.focused_phase_switch_span ||
      branching.focused_phase_pattern.empty())
    return reject("branching phase schedule must be nonempty with a positive span");
  for (const int8_t phase : branching.focused_phase_pattern)
    if (phase < -1 || phase > 1)
      return reject("branching phase pattern contains an invalid phase");
  if (!positive_finite(branching.logarithm_offset))
    return reject("branching logarithm offset must be positive and finite");
  if (!positive_finite(branching.mab_exploration) ||
      !positive_finite(branching.chb_step) ||
      !std::isfinite(branching.chb_step_min) ||
      branching.chb_step_min < 0.0 ||
      !std::isfinite(branching.chb_step_decay) ||
      branching.chb_step_decay < 0.0 ||
      branching.chb_step > 1.0 ||
      branching.chb_step_min > branching.chb_step)
    return reject("branching MAB/CHB parameters are invalid");
  if (!std::isfinite(analysis.bump_reason_rate) ||
      analysis.bump_reason_rate < 0.0)
    return reject("analysis reason-bump rate must be finite and nonnegative");
  if (analysis.eager_subsume >
      strategy::AnalyzeParameters::EAGER_SUBSUME_CAPACITY)
    return reject("analysis eager-subsumption size exceeds its representation");
  if (analysis.big_binary_fraction_permille > PERMILLE_SCALE)
    return reject("analysis binary fraction exceeds 1000 permille");
  if (!positive_finite(restart.glue_margin) ||
      !positive_finite(restart.fast_ema_window) ||
      !positive_finite(restart.slow_ema_window) ||
      !positive_finite(restart.logarithm_offset) ||
      !positive_finite(restart.logarithm_bias) || !restart.initial_interval ||
      !restart.reluctant_period || !restart.reluctant_limit)
    return reject("restart settings contain a zero or non-finite scale");
  if (mode.force > 2 || !mode.initial_conflicts || !mode.interval ||
      !positive_finite(mode.logarithm_offset) || !mode.logarithm_power)
    return reject("mode schedule is invalid");
  if (!reduction.initial_interval || !reduction.arithmetic_interval ||
      !reduction.arithmetic_step ||
      !positive_finite(reduction.logarithm_offset) ||
      !std::isfinite(reduction.low_percent) ||
      reduction.low_percent < 0.0 ||
      reduction.low_percent > static_cast<double>(PERCENT_SCALE) ||
      !std::isfinite(reduction.high_percent) ||
      reduction.high_percent < 0.0 ||
      reduction.high_percent > static_cast<double>(PERCENT_SCALE) ||
      reduction.compact_inactive_percent > PERCENT_SCALE ||
      reduction.tier1_default > reduction.tier2_default ||
      reduction.tier1_relative_permille >
          reduction.tier2_relative_permille ||
      reduction.tier2_relative_permille > PERMILLE_SCALE ||
      reduction.reduce_tier1_mode >= MODES_PER_CYCLE ||
      reduction.reduce_tier2_mode >= MODES_PER_CYCLE ||
      !reduction.victim_denominator ||
      reduction.victim_numerator > reduction.victim_denominator ||
      !reduction.retier_initial_interval || !reduction.retier_max_interval ||
      reduction.retier_growth < 1)
    return reject("reduction schedule is invalid");
  if (!rephase.initial_interval || !rephase.interval ||
      !positive_finite(rephase.logarithm_offset) || !rephase.logarithm_power ||
      rephase.walk_permille > PERMILLE_SCALE)
    return reject("rephase schedule is invalid");
  strategy::WalkParameters walk_parameters;
  walk_parameters.even_break_base_milli =
      rephase.walk_even_break_base_milli;
  walk_parameters.score_curve = rephase.walk_score_curve;
  if (!walk_parameters.valid() || rephase.rotation.empty())
    return reject("rephase Walk settings are invalid");
  if (rephase.structural_walk_seed &&
      rephase.structural_seed_rotation.empty())
    return reject("structural local-search rotation is empty");
  for (const strategy::LocalSearchKind kind :
       rephase.structural_seed_rotation)
    if (!strategy::valid_local_search_kind(kind))
      return reject("structural local-search rotation contains an invalid kind");
  for (const DefaultRephaseSlot slot : rephase.rotation)
    if (slot != DefaultRephaseSlot::Best &&
        slot != DefaultRephaseSlot::Walk &&
        slot != DefaultRephaseSlot::Inverted &&
        slot != DefaultRephaseSlot::Original)
      return reject("rephase rotation contains an invalid slot");
  if (rephase.walk_inapplicable_fallback == DefaultRephaseSlot::Walk ||
      (rephase.walk_inapplicable_fallback != DefaultRephaseSlot::Best &&
       rephase.walk_inapplicable_fallback != DefaultRephaseSlot::Inverted &&
       rephase.walk_inapplicable_fallback != DefaultRephaseSlot::Original))
    return reject("rephase Walk fallback is invalid");
  if (!reorder.initial_interval || !reorder.interval || reorder.mode > 2 ||
      (reorder.target != DefaultReorderTarget::Active &&
       reorder.target != DefaultReorderTarget::Queue &&
       reorder.target != DefaultReorderTarget::Heap) ||
      !reorder.parameters.valid())
    return reject("reorder schedule is invalid");
  if (!parity_model.parameters.valid())
    return reject("parity-model settings are invalid");
  if (!onehot_model.parameters.valid())
    return reject("onehot-model settings are invalid");
  if (!balanced_signature_model.parameters.valid())
    return reject("balanced-signature-model settings are invalid");
  if (!fermat_model.parameters.valid())
    return reject("fermat-model settings are invalid");
  if (!lookup_circuit_model.parameters.valid())
    return reject("lookup-circuit-model settings are invalid");
  if (!simon_model.parameters.valid())
    return reject("simon-model settings are invalid");
  if (!stconn_proof.parameters.valid())
    return reject("stconn-proof settings are invalid");
  if (!signed_cardinality_proof.parameters.valid())
    return reject("signed-cardinality-proof settings are invalid");
  if (!exact_cover_model.parameters.valid())
    return reject("exact-cover-model settings are invalid");
  if (!independent_set_model.parameters.valid())
    return reject("independent-set-model settings are invalid");

  const auto &ip = inprocess;
  if (!ip.eliminate_interval || !ip.probe_interval || !ip.phase_rounds ||
      !ip.initial_fast_elimination_rounds ||
      !ip.substitute_rounds || !ip.substitute_search_rounds ||
      !positive_finite(ip.logarithm_offset) ||
      !std::isfinite(ip.scale_quadratic) || ip.scale_quadratic < 0.0 ||
      !std::isfinite(ip.scale_constant) || ip.scale_constant < 0.0 ||
      !std::isfinite(ip.scale_log_shift) ||
      ip.vivify_tier_mode >= MODES_PER_CYCLE)
    return reject("inprocessing cadence or scaling is invalid");
  if (!ip.congruence_parameters.valid() ||
      !ip.instantiate_parameters.valid() || !ip.backbone_parameters.valid() ||
      !ip.vivify_parameters.valid() || !ip.bce_parameters.valid() ||
      !ip.ternary_parameters.valid() || !ip.factor_parameters.valid() ||
      !ip.transitive_parameters.valid() || !ip.substitute_parameters.valid() ||
      !ip.sweep_parameters.valid())
    return reject("inprocessing rule parameters are invalid");
  strategy::BveParameters bve;
  bve.occurrence_limit = ip.bve_occurrence_limit;
  bve.clause_size_limit = ip.bve_clause_size_limit;
  bve.xor_arity_limit = ip.bve_xor_arity_limit;
  bve.resolvent_size_limit = ip.bve_resolvent_size_limit;
  bve.backward_occurrence_limit = ip.bve_backward_occurrence_limit;
  bve.definition_budget = ip.bve_definition_budget;
  bve.definition_cores = ip.bve_definition_cores;
  bve.definition_core_budget_multiplier =
      ip.bve_definition_core_budget_multiplier;
  if (!bve.valid())
    return reject("inprocessing BVE parameters are invalid");
  if (!ip.initial_fast_elimination_parameters.valid())
    return reject("initial fast-elimination parameters are invalid");
  if (ip.bve_bounds.empty() ||
      ip.bve_bounds.front() > ip.bve_default_ceiling)
    return reject("BVE bound ladder is empty or starts above its ceiling");
  for (size_t i = 1; i < ip.bve_bounds.size(); ++i)
    if (ip.bve_bounds[i - 1] > ip.bve_bounds[i])
      return reject("BVE bound ladder is not monotone");
  if (ip.factor_decade_base < 2 ||
      uint64_t{ip.factor_decade_round_cap} + ip.factor_decade_offset >
          ip.factor_decade_cap)
    return reject("Factor delay schedule is invalid");
  uint64_t threshold = 1;
  for (uint32_t i = 0; i < ip.factor_decade_cap; ++i) {
    if (threshold > UINT64_MAX / ip.factor_decade_base)
      return reject("Factor delay threshold overflows uint64_t");
    threshold *= ip.factor_decade_base;
  }
  const uint32_t permilles[] = {
      ip.bve_permille,          ip.probe_permille,
      ip.hyper_binary_permille, ip.backbone_permille,
      ip.transitive_permille,   ip.vivify_permille,
      ip.strengthen_permille,   ip.subsume_forward_permille,
      ip.factor_permille,       ip.hyper_ternary_permille,
      ip.bce_permille,          ip.cce_permille,
      ip.instantiate_permille,  ip.sweep_permille,
      ip.substitute_permille,   ip.congruence_productivity_permille,
      ip.sweep_productivity_permille};
  for (const uint32_t value : permilles)
    if (value > PERMILLE_SCALE)
      return reject("inprocessing permille setting exceeds 1000");
  const uint64_t tier_share = uint64_t{ip.vivify_tier_shares[0]} +
                              ip.vivify_tier_shares[1] +
                              ip.vivify_tier_shares[2];
  if (!ip.vivify_total_share || !ip.vivify_redundant_share ||
      ip.vivify_redundant_share > ip.vivify_total_share ||
      tier_share > ip.vivify_redundant_share)
    return reject("Vivify share partition is invalid");
  for (const uint8_t scope : ip.vivify_tier_scopes)
    if (scope > 5)
      return reject("Vivify tier scope is invalid");
  if (ip.vivify_irredundant_productivity_percent > PERCENT_SCALE)
    return reject("Vivify productivity exceeds 100 percent");
  if (!strategy::validate_inprocess_program(ip.program, error))
    return false;
  for (const strategy::InprocessStep &step : ip.program)
    if (step.rule == "SubstitutionRedundancy")
      return reject("slot program duplicates structured root SR ownership");
  for (const auto *stages : {&ip.structured_root_stages,
                             &ip.structured_root_bounded_backtracking_stages,
                             &ip.structured_root_large_domain_stages})
  for (const auto &stage : *stages) {
    if (stage.on_budget_exhaustion != strategy::BudgetExhaustionPolicy::Stop &&
        stage.on_budget_exhaustion != strategy::BudgetExhaustionPolicy::Continue &&
        stage.on_budget_exhaustion != strategy::BudgetExhaustionPolicy::FinishRoundThenStop)
      return reject("structured root budget disposition is invalid");
    if (!strategy::validate_online_strategy_program(stage.program, error))
      return false;
    if (stage.structured_handoff_after_prior_progress &&
        std::none_of(stage.program.sequence.begin(), stage.program.sequence.end(),
                     [](const auto &step) {
                       const auto *parameters =
                           std::get_if<SubstitutionRedundancyParameters>(
                               &step.parameters);
                       return parameters &&
                              parameters->producer ==
                                  SubstitutionRedundancyProducer::GraphSymmetry &&
                              (parameters->graph_symmetry.use_structured_generators ||
                               parameters->graph_symmetry
                                   .stabilize_structured_variables);
                     }))
      return reject("structured handoff feedback requires a graph handoff");
    for (size_t i = 0; i < stage.progress_followups.size(); ++i) {
      const auto id = stage.progress_followups[i];
      if (std::none_of(stage.program.sequence.begin(), stage.program.sequence.end(),
              [id](const auto &step) { return step.id == id; }) ||
          std::find(stage.progress_followups.begin(), stage.progress_followups.begin() + i,
                    id) != stage.progress_followups.begin() + i)
        return reject("progress followup must name a unique existing step");
    }
    for (size_t i = 0; i < stage.before_progress.size(); ++i) {
      const auto id = stage.before_progress[i];
      if (std::none_of(stage.program.sequence.begin(), stage.program.sequence.end(),
              [id](const auto &step) { return step.id == id; }) ||
          std::find(stage.before_progress.begin(), stage.before_progress.begin() + i,
                    id) != stage.before_progress.begin() + i ||
          std::find(stage.progress_followups.begin(), stage.progress_followups.end(),
                    id) != stage.progress_followups.end())
        return reject("before-progress step must name a unique existing non-followup");
    }
    // This scheduler owns a quiescent-root preprocessing scope. All declared
    // inprocessing actions, Reduce, Propagate and Lucky fit that boundary
    // (Lucky may terminate with a model); other search
    // transitions remain freely composable through the general online API.
    for (const auto &step : stage.program.sequence) {
      const int id = tactix_rule_id(step.rule.c_str());
      if (id < 0 || (tactix_rules()[id].tier != RuleTier::Inprocess &&
                    step.rule != "Reduce" && step.rule != "Propagate" &&
                    step.rule != "Lucky"))
        return reject("structured root action does not preserve its root scope");
    }
  }
  for (const strategy::InprocessStep &step : ip.program)
    if (step.effort_permille && *step.effort_permille > PERMILLE_SCALE)
      return reject("inprocess step effort exceeds 1000 permille");
  if (error)
    error->clear();
  return true;
}

std::string DefaultStrategyConfig::serialize() const {
  std::ostringstream out;
  out << "strategy-v1"
      << " branching.random_initial_interval="
      << branching.random_initial_interval
      << " branching.random_sequence_length="
      << branching.random_sequence_length
      << " branching.random_seed=" << branching.random_seed
      << " branching.logarithm_offset=" << branching.logarithm_offset
      << " branching.focused_phase_switch_span="
      << branching.focused_phase_switch_span
      << " branching.random_sequences=" << branching.random_sequences
      << " branching.mab=" << branching.mab
      << " branching.mab_after_search_stagnation="
      << branching.mab_after_search_stagnation
      << " branching.mab_exploration=" << branching.mab_exploration
      << " branching.chb_step=" << branching.chb_step
      << " branching.chb_step_min=" << branching.chb_step_min
      << " branching.chb_step_decay=" << branching.chb_step_decay;
  for (size_t i = 0; i < branching.focused_phase_pattern.size(); ++i)
    out << " branching.focused_phase" << i << '='
        << static_cast<int>(branching.focused_phase_pattern[i]);
  out << " analysis.minimize_depth_limit=" << analysis.minimize_depth_limit
      << " analysis.bump_reason_limit=" << analysis.bump_reason_limit
      << " analysis.bump_reason_rate=" << analysis.bump_reason_rate
      << " analysis.reason_depth=" << analysis.reason_depth
      << " analysis.chronological_levels=" << analysis.chronological_levels
      << " analysis.reuse_ranked_trail_suffix="
      << analysis.reuse_ranked_trail_suffix
      << " analysis.conflict_reuse=" << analysis.conflict_reuse
      << " analysis.jump_reasons=" << analysis.jump_reasons
      << " analysis.shrink_glue_promote=" << analysis.shrink_glue_promote
      << " analysis.bump_extension_reasons="
      << analysis.bump_extension_reasons
      << " analysis.eager_subsume=" << analysis.eager_subsume
      << " analysis.small_clause_limit=" << analysis.small_clause_limit
      << " analysis.big_binary_fraction_permille="
      << analysis.big_binary_fraction_permille
      << " restart.glue_margin=" << restart.glue_margin
      << " restart.initial_interval=" << restart.initial_interval
      << " restart.fast_ema_window=" << restart.fast_ema_window
      << " restart.slow_ema_window=" << restart.slow_ema_window
      << " restart.logarithm_offset=" << restart.logarithm_offset
      << " restart.logarithm_bias=" << restart.logarithm_bias
      << " restart.reluctant_period=" << restart.reluctant_period
      << " restart.reluctant_limit=" << restart.reluctant_limit
      << " mode.initial_conflicts=" << mode.initial_conflicts
      << " mode.interval=" << mode.interval
      << " mode.logarithm_offset=" << mode.logarithm_offset
      << " mode.logarithm_power=" << mode.logarithm_power
      << " mode.force=" << mode.force
      << " reduction.initial_interval=" << reduction.initial_interval
      << " reduction.arithmetic_interval=" << reduction.arithmetic_interval
      << " reduction.arithmetic_step=" << reduction.arithmetic_step
      << " reduction.low_percent=" << reduction.low_percent
      << " reduction.high_percent=" << reduction.high_percent
      << " reduction.logarithm_offset=" << reduction.logarithm_offset
      << " reduction.compact_inactive_percent="
      << reduction.compact_inactive_percent
      << " reduction.retier_initial_interval="
      << reduction.retier_initial_interval
      << " reduction.retier_max_interval=" << reduction.retier_max_interval
      << " reduction.retier_growth=" << reduction.retier_growth
      << " reduction.tier1_default=" << reduction.tier1_default
      << " reduction.tier2_default=" << reduction.tier2_default
      << " reduction.tier1_relative_permille="
      << reduction.tier1_relative_permille
      << " reduction.tier2_relative_permille="
      << reduction.tier2_relative_permille
      << " reduction.reduce_tier1_mode="
      << unsigned(reduction.reduce_tier1_mode)
      << " reduction.reduce_tier2_mode="
      << unsigned(reduction.reduce_tier2_mode)
      << " reduction.victim_numerator=" << reduction.victim_numerator
      << " reduction.victim_denominator=" << reduction.victim_denominator
      << " reduction.protect_tiers=" << reduction.protect_tiers
      << " reduction.canonical_compact_collection="
      << reduction.canonical_compact_collection
      << " reduction.bookkeeping=" << reduction.bookkeeping
      << " reduction.square_root_cadence="
      << reduction.square_root_cadence
      << " reduction.ramp_fraction=" << reduction.ramp_fraction
      << " reduction.dynamic_tiers=" << reduction.dynamic_tiers
      << " reduction.compact_variables=" << reduction.compact_variables
      << " rephase.initial_interval=" << rephase.initial_interval
      << " rephase.interval=" << rephase.interval
      << " rephase.logarithm_offset=" << rephase.logarithm_offset
      << " rephase.logarithm_power=" << rephase.logarithm_power
      << " rephase.walk_permille=" << rephase.walk_permille
      << " rephase.walk_even_break_base_milli="
      << rephase.walk_even_break_base_milli
      << " rephase.walk_inapplicable_fallback="
      << static_cast<unsigned>(rephase.walk_inapplicable_fallback)
      << " rephase.walk_warmup=" << rephase.walk_warmup
      << " rephase.walk_use_branch_seed="
      << rephase.walk_use_branch_seed
      << " rephase.walk_random_seed=" << rephase.walk_random_seed
      << " rephase.structural_walk_seed="
      << rephase.structural_walk_seed
      << " rephase.stable_only=" << rephase.stable_only
      << " rephase.late_lucky=" << rephase.late_lucky;
  for (size_t i = 0; i < rephase.walk_score_curve.size(); ++i)
    out << " rephase.walk_score_point" << i << '='
        << rephase.walk_score_curve[i].average_clause_size_milli << ':'
        << rephase.walk_score_curve[i].break_base_milli;
  for (size_t i = 0; i < rephase.rotation.size(); ++i)
    out << " rephase.rotation" << i << '='
        << static_cast<unsigned>(rephase.rotation[i]);
  for (size_t i = 0; i < rephase.structural_seed_rotation.size(); ++i)
    out << " rephase.structural_seed_rotation" << i << '='
        << static_cast<unsigned>(rephase.structural_seed_rotation[i]);
  out
      << " reorder.initial_interval=" << reorder.initial_interval
      << " reorder.interval=" << reorder.interval
      << " reorder.mode=" << reorder.mode
      << " reorder.target=" << static_cast<unsigned>(reorder.target)
      << " reorder.maximum_clause_size="
      << reorder.parameters.maximum_clause_size
      << " reorder.clause_decay_milli="
      << reorder.parameters.clause_decay_milli
      << " reorder.binary_weight_milli="
      << reorder.parameters.binary_weight_milli
      << " reorder.balanced_polarity_milli="
      << reorder.parameters.balanced_polarity_milli
      << " parity_model.enabled=" << parity_model.enabled
      << " parity_model.maximum_variables="
      << parity_model.parameters.maximum_variables
      << " parity_model.maximum_groups="
      << parity_model.parameters.maximum_groups
      << " parity_model.maximum_constraints="
      << parity_model.parameters.maximum_constraints
      << " parity_model.minimum_group_clauses="
      << parity_model.parameters.minimum_group_clauses
      << " parity_model.minimum_equations="
      << parity_model.parameters.minimum_equations
      << " parity_model.maximum_free_variables="
      << parity_model.parameters.maximum_free_variables
      << " parity_model.candidate_budget="
      << parity_model.parameters.candidate_budget
      << " parity_model.refutation_maximum_variables="
      << parity_model.parameters.refutation_maximum_variables
      << " parity_model.refutation_maximum_groups="
      << parity_model.parameters.refutation_maximum_groups
      << " parity_model.refutation_maximum_constraints="
      << parity_model.parameters.refutation_maximum_constraints
      << " parity_model.refutation_maximum_arity="
      << parity_model.parameters.refutation_maximum_arity
      << " parity_model.refutation_probe_constraints="
      << parity_model.parameters.refutation_probe_constraints
      << " parity_model.refutation_minimum_probe_repeats="
      << parity_model.parameters.refutation_minimum_probe_repeats
      << " parity_model.refutation_maximum_proof_additions="
      << parity_model.parameters.refutation_maximum_proof_additions
      << " onehot_model.enabled=" << onehot_model.enabled
      << " onehot_model.maximum_variables="
      << onehot_model.parameters.maximum_variables
      << " onehot_model.maximum_domains="
      << onehot_model.parameters.maximum_domains
      << " onehot_model.maximum_constraints="
      << onehot_model.parameters.maximum_constraints
      << " onehot_model.maximum_equation_arity="
      << onehot_model.parameters.maximum_equation_arity
      << " onehot_model.minimum_domains="
      << onehot_model.parameters.minimum_domains
      << " onehot_model.minimum_equations="
      << onehot_model.parameters.minimum_equations
      << " onehot_model.maximum_free_domains="
      << onehot_model.parameters.maximum_free_domains
      << " onehot_model.candidate_budget="
      << onehot_model.parameters.candidate_budget
      << " balanced_signature_model.enabled="
      << balanced_signature_model.enabled
      << " balanced_signature_model.maximum_balls="
      << balanced_signature_model.parameters.maximum_balls
      << " balanced_signature_model.maximum_width="
      << balanced_signature_model.parameters.maximum_width
      << " balanced_signature_model.restarts="
      << balanced_signature_model.parameters.restarts
      << " balanced_signature_model.steps_per_restart="
      << balanced_signature_model.parameters.steps_per_restart
      << " balanced_signature_model.samples_per_step="
      << balanced_signature_model.parameters.samples_per_step
      << " balanced_signature_model.seed="
      << balanced_signature_model.parameters.seed
      << " balanced_signature_model.completion_rounds="
      << balanced_signature_model.parameters.completion_rounds
      << " fermat_model.enabled=" << fermat_model.enabled
      << " fermat_model.maximum_bits="
      << fermat_model.parameters.maximum_bits
      << " fermat_model.comparator_tail_clauses="
      << fermat_model.parameters.comparator_tail_clauses
      << " fermat_model.rho_constants="
      << fermat_model.parameters.rho_constants
      << " fermat_model.rho_iterations="
      << fermat_model.parameters.rho_iterations
      << " cerny_model.enabled=" << cerny_model.enabled
      << " lookup_circuit_model.enabled=" << lookup_circuit_model.enabled
      << " lookup_circuit_model.maximum_fanin="
      << lookup_circuit_model.parameters.maximum_fanin
      << " lookup_circuit_model.maximum_fanout="
      << lookup_circuit_model.parameters.maximum_fanout
      << " lookup_circuit_model.maximum_primary_inputs="
      << lookup_circuit_model.parameters.maximum_primary_inputs
      << " lookup_circuit_model.maximum_support="
      << lookup_circuit_model.parameters.maximum_support
      << " lookup_circuit_model.maximum_vector_gate_evaluations="
      << lookup_circuit_model.parameters.maximum_vector_gate_evaluations
      << " simon_model.enabled=" << simon_model.enabled
      << " simon_model.maximum_rounds="
      << simon_model.parameters.maximum_rounds
      << " simon_model.maximum_candidates="
      << simon_model.parameters.maximum_candidates
      << " stconn_proof.enabled=" << stconn_proof.enabled
      << " stconn_proof.maximum_width="
      << stconn_proof.parameters.maximum_width
      << " stconn_proof.maximum_columns="
      << stconn_proof.parameters.maximum_columns
      << " stconn_proof.maximum_rup_clauses="
      << stconn_proof.parameters.maximum_rup_clauses
      << " signed_cardinality_proof.enabled="
      << signed_cardinality_proof.enabled
      << " signed_cardinality_proof.maximum_variables="
      << signed_cardinality_proof.parameters.maximum_variables
      << " signed_cardinality_proof.maximum_groups="
      << signed_cardinality_proof.parameters.maximum_groups
      << " signed_cardinality_proof.maximum_constraints="
      << signed_cardinality_proof.parameters.maximum_constraints
      << " signed_cardinality_proof.maximum_group_arity="
      << signed_cardinality_proof.parameters.maximum_group_arity
      << " signed_cardinality_proof.maximum_bdd_nodes="
      << signed_cardinality_proof.parameters.maximum_bdd_nodes
      << " signed_cardinality_proof.maximum_proof_additions="
      << signed_cardinality_proof.parameters.maximum_proof_additions
      << " exact_cover_model.enabled=" << exact_cover_model.enabled
      << " exact_cover_model.block_arity="
      << exact_cover_model.parameters.block_arity
      << " exact_cover_model.maximum_nodes="
      << exact_cover_model.parameters.maximum_nodes
      << " exact_cover_model.restarts=" << exact_cover_model.parameters.restarts
      << " exact_cover_model.restart_nodes="
      << exact_cover_model.parameters.restart_nodes
      << " exact_cover_model.seed=" << exact_cover_model.parameters.seed
      << " independent_set_model.enabled=" << independent_set_model.enabled
      << " independent_set_model.maximum_vertices="
      << independent_set_model.parameters.maximum_vertices
      << " independent_set_model.maximum_steps="
      << independent_set_model.parameters.maximum_steps
      << " independent_set_model.completion_rounds="
      << independent_set_model.parameters.completion_rounds
      << " independent_set_model.seed=" << independent_set_model.parameters.seed
      << " inprocess.bve_enabled=" << inprocess.bve_enabled
      << " inprocess.vivify_enabled=" << inprocess.vivify_enabled
      << " inprocess.factor_enabled=" << inprocess.factor_enabled
      << " inprocess.sweep_enabled=" << inprocess.sweep_enabled
      << " inprocess.factor_repeated_enabled="
      << inprocess.factor_repeated_enabled
      << " inprocess.preprocess_only=" << inprocess.preprocess_only
      << " inprocess.initial_fast_elimination="
      << inprocess.initial_fast_elimination
      << " inprocess.initial_fast_elimination_rounds="
      << inprocess.initial_fast_elimination_rounds
      << " inprocess.initial_fast_elimination_resolvent_count_limit="
      << inprocess.initial_fast_elimination_parameters.resolvent_count_limit
      << " inprocess.initial_fast_elimination_traversal="
      << static_cast<unsigned>(
             inprocess.initial_fast_elimination_parameters.traversal)
      << " inprocess.cadical_arena_ordering_enabled="
      << inprocess.cadical_arena_ordering_enabled
      << " inprocess.append_unlisted_rules="
      << inprocess.append_unlisted_rules
      << " inprocess.eliminate_interval=" << inprocess.eliminate_interval
      << " inprocess.probe_interval=" << inprocess.probe_interval
      << " inprocess.minimum_effort_ticks="
      << inprocess.minimum_effort_ticks
      << " inprocess.preprocess_initial_ticks="
      << inprocess.preprocess_initial_ticks
      << " inprocess.phase_rounds=" << inprocess.phase_rounds
      << " inprocess.substitute_rounds=" << inprocess.substitute_rounds
      << " inprocess.substitute_search_rounds="
      << inprocess.substitute_search_rounds
      << " inprocess.factor_initial_ticks=" << inprocess.factor_initial_ticks
      << " inprocess.logarithm_offset=" << inprocess.logarithm_offset
      << " inprocess.scale_quadratic=" << inprocess.scale_quadratic
      << " inprocess.scale_constant=" << inprocess.scale_constant
      << " inprocess.scale_log_shift=" << inprocess.scale_log_shift
      << " inprocess.candidate_order_seed="
      << inprocess.candidate_order_seed
      << " inprocess.congruence_and_arity_limit="
      << inprocess.congruence_parameters.and_arity_limit
      << " inprocess.congruence_gate_count_limit="
      << inprocess.congruence_parameters.gate_count_limit
      << " inprocess.congruence_xor_arity_limit="
      << inprocess.congruence_parameters.xor_arity_limit
      << " inprocess.congruence_binary_watch_order="
      << static_cast<unsigned>(inprocess.congruence_parameters.binary_watch_order)
      << " inprocess.instantiate_minimum_clause_size="
      << inprocess.instantiate_parameters.minimum_clause_size
      << " inprocess.instantiate_occurrence_limit="
      << inprocess.instantiate_parameters.occurrence_limit
      << " inprocess.instantiate_minimum_unassigned="
      << inprocess.instantiate_parameters.minimum_unassigned
      << " inprocess.instantiate_include_redundant="
      << inprocess.instantiate_parameters.include_redundant
      << " inprocess.instantiate_new_material_threshold="
      << inprocess.instantiate_parameters.new_material_threshold
      << " inprocess.backbone_initial_rounds="
      << inprocess.backbone_parameters.initial_rounds
      << " inprocess.backbone_maximum_rounds="
      << inprocess.backbone_parameters.maximum_rounds
      << " inprocess.vivify_scope="
      << unsigned(inprocess.vivify_parameters.scope)
      << " inprocess.vivify_reuse=" << inprocess.vivify_parameters.reuse
      << " inprocess.vivify_flush=" << inprocess.vivify_parameters.flush
      << " inprocess.vivify_irredundant_sort_ratio="
      << inprocess.vivify_parameters.irredundant_sort_ratio
      << " inprocess.bce_occurrence_limit="
      << inprocess.bce_parameters.occurrence_limit
      << " inprocess.ternary_occurrence_limit="
      << inprocess.ternary_parameters.occurrence_limit
      << " inprocess.ternary_maximum_add_percent="
      << inprocess.ternary_parameters.maximum_add_percent
      << " inprocess.factor_maximum_clause_size="
      << inprocess.factor_parameters.maximum_clause_size
      << " inprocess.factor_growth_bound="
      << inprocess.factor_parameters.growth_bound
      << " inprocess.factor_candidate_rounds="
      << inprocess.factor_parameters.candidate_rounds
      << " inprocess.factor_composite="
      << inprocess.factor_parameters.composite
      << " inprocess.factor_demote_fresh="
      << inprocess.factor_parameters.demote_fresh
      << " inprocess.transitive_early_exit="
      << inprocess.transitive_parameters.early_exit
      << " inprocess.transitive_live_meter="
      << inprocess.transitive_parameters.live_meter
      << " inprocess.transitive_checked_budget_meter="
      << inprocess.transitive_parameters.checked_budget_meter
      << " inprocess.substitute_demote="
      << inprocess.substitute_parameters.demote_substituted
      << " inprocess.touch_filter=" << inprocess.touch_filter
      << " inprocess.likely_kept_redundant="
      << inprocess.likely_kept_redundant
      << " inprocess.structured_root_before_lucky="
      << inprocess.structured_root_before_lucky
      << " inprocess.structured_root_residual_search_handoff="
      << inprocess.structured_root_residual_search_handoff
      << " inprocess.structured_root_sr_discovery_unlimited="
      << inprocess.structured_root_sr_discovery_budget.is_unlimited()
      << " inprocess.structured_root_sr_discovery_ticks="
      << (inprocess.structured_root_sr_discovery_budget.is_unlimited()
              ? 0
              : inprocess.structured_root_sr_discovery_budget.amount())
      << " inprocess.structured_root_progress_feedback="
      << inprocess.structured_root_progress_feedback
      << " inprocess.structured_root_large_domain_progress_feedback="
      << inprocess.structured_root_large_domain_progress_feedback
      << " inprocess.structured_root_progress_minimum_ticks="
      << inprocess.structured_root_progress_minimum_ticks
      << " inprocess.structured_root_progress_ticks_per_variable="
      << inprocess.structured_root_progress_ticks_per_variable
      << " inprocess.structured_root_bce_after_unique_literal_amo="
      << inprocess.structured_root_bce_after_unique_literal_amo
      << " inprocess.structured_root_backtracking_domain_limit="
      << inprocess.structured_root_backtracking_domain_limit
      << " inprocess.structured_root_large_domain_limit="
      << inprocess.structured_root_large_domain_limit
;
  for (size_t i = 0; i < inprocess.structured_root_stages.size(); ++i) {
    const auto &stage = inprocess.structured_root_stages[i];
    out << " inprocess.structured_root_stage" << i << "={"
        << static_cast<unsigned>(stage.on_budget_exhaustion) << ':'
        << strategy::serialize_online_strategy_program(stage.program) << '}';
    if (!stage.progress_followups.empty()) {
      out << " inprocess.structured_root_stage" << i << ".progress_followups=";
      for (size_t j = 0; j < stage.progress_followups.size(); ++j)
        out << (j ? "," : "") << stage.progress_followups[j];
    }
    if (!stage.before_progress.empty()) {
      out << " inprocess.structured_root_stage" << i << ".before_progress=";
      for (size_t j = 0; j < stage.before_progress.size(); ++j)
        out << (j ? "," : "") << stage.before_progress[j];
    }
    out << " inprocess.structured_root_stage" << i
        << ".structured_handoff_after_prior_progress="
        << stage.structured_handoff_after_prior_progress;
  }
  for (size_t i = 0;
       i < inprocess.structured_root_bounded_backtracking_stages.size(); ++i) {
    const auto &stage =
        inprocess.structured_root_bounded_backtracking_stages[i];
    out << " inprocess.structured_root_bounded_backtracking_stage" << i << "={"
        << static_cast<unsigned>(stage.on_budget_exhaustion) << ':'
        << strategy::serialize_online_strategy_program(stage.program) << '}';
    if (!stage.progress_followups.empty()) {
      out << " inprocess.structured_root_bounded_backtracking_stage" << i
          << ".progress_followups=";
      for (size_t j = 0; j < stage.progress_followups.size(); ++j)
        out << (j ? "," : "") << stage.progress_followups[j];
    }
    if (!stage.before_progress.empty()) {
      out << " inprocess.structured_root_bounded_backtracking_stage" << i
          << ".before_progress=";
      for (size_t j = 0; j < stage.before_progress.size(); ++j)
        out << (j ? "," : "") << stage.before_progress[j];
    }
    out << " inprocess.structured_root_bounded_backtracking_stage" << i
        << ".structured_handoff_after_prior_progress="
        << stage.structured_handoff_after_prior_progress;
  }
  for (size_t i = 0; i < inprocess.structured_root_large_domain_stages.size();
       ++i) {
    const auto &stage = inprocess.structured_root_large_domain_stages[i];
    out << " inprocess.structured_root_large_stage" << i << "={"
        << static_cast<unsigned>(stage.on_budget_exhaustion) << ':'
        << strategy::serialize_online_strategy_program(stage.program) << '}';
    if (!stage.progress_followups.empty()) {
      out << " inprocess.structured_root_large_stage" << i
          << ".progress_followups=";
      for (size_t j = 0; j < stage.progress_followups.size(); ++j)
        out << (j ? "," : "") << stage.progress_followups[j];
    }
    if (!stage.before_progress.empty()) {
      out << " inprocess.structured_root_large_stage" << i
          << ".before_progress=";
      for (size_t j = 0; j < stage.before_progress.size(); ++j)
        out << (j ? "," : "") << stage.before_progress[j];
    }
    out << " inprocess.structured_root_large_stage" << i
        << ".structured_handoff_after_prior_progress="
        << stage.structured_handoff_after_prior_progress;
  }
  for (size_t i = 0; i < inprocess.bve_bounds.size(); ++i)
    out << " inprocess.bve_bound" << i << '=' << inprocess.bve_bounds[i];
  out << " inprocess.bve_default_ceiling=" << inprocess.bve_default_ceiling
      << " inprocess.bve_occurrence_limit="
      << inprocess.bve_occurrence_limit
      << " inprocess.bve_clause_size_limit="
      << inprocess.bve_clause_size_limit
      << " inprocess.bve_xor_arity_limit="
      << inprocess.bve_xor_arity_limit
      << " inprocess.bve_resolvent_size_limit="
      << inprocess.bve_resolvent_size_limit
      << " inprocess.bve_backward_occurrence_limit="
      << inprocess.bve_backward_occurrence_limit
      << " inprocess.bve_definition_budget="
      << inprocess.bve_definition_budget
      << " inprocess.bve_definition_cores="
      << inprocess.bve_definition_cores
      << " inprocess.bve_definition_core_budget_multiplier="
      << inprocess.bve_definition_core_budget_multiplier
      << " inprocess.bve_backward=" << inprocess.bve_backward
      << " inprocess.factor_decade_round_cap="
      << inprocess.factor_decade_round_cap
      << " inprocess.factor_decade_cap=" << inprocess.factor_decade_cap
      << " inprocess.factor_decade_offset=" << inprocess.factor_decade_offset
      << " inprocess.factor_decade_base=" << inprocess.factor_decade_base
      << " inprocess.factor_active_ceiling=" << inprocess.factor_active_ceiling
      << " inprocess.bve_permille=" << inprocess.bve_permille
      << " inprocess.probe_permille=" << inprocess.probe_permille
      << " inprocess.hyper_binary_permille="
      << inprocess.hyper_binary_permille
      << " inprocess.backbone_permille=" << inprocess.backbone_permille
      << " inprocess.transitive_permille=" << inprocess.transitive_permille
      << " inprocess.vivify_permille=" << inprocess.vivify_permille
      << " inprocess.strengthen_permille=" << inprocess.strengthen_permille
      << " inprocess.subsume_forward_permille="
      << inprocess.subsume_forward_permille
      << " inprocess.factor_permille=" << inprocess.factor_permille
      << " inprocess.hyper_ternary_permille="
      << inprocess.hyper_ternary_permille
      << " inprocess.bce_permille=" << inprocess.bce_permille
      << " inprocess.cce_permille=" << inprocess.cce_permille
      << " inprocess.instantiate_permille=" << inprocess.instantiate_permille
      << " inprocess.sweep_permille=" << inprocess.sweep_permille
      << " inprocess.substitute_permille=" << inprocess.substitute_permille
      << " inprocess.sweep_depth=" << inprocess.sweep_parameters.max_depth
      << " inprocess.sweep_max_depth="
      << inprocess.sweep_parameters.max_depth_ceiling
      << " inprocess.sweep_vars=" << inprocess.sweep_parameters.max_env_vars
      << " inprocess.sweep_max_vars="
      << inprocess.sweep_parameters.max_env_vars_ceiling
      << " inprocess.sweep_clauses="
      << inprocess.sweep_parameters.max_env_clauses
      << " inprocess.sweep_max_clauses="
      << inprocess.sweep_parameters.max_env_clauses_ceiling
      << " inprocess.sweep_candidate_pairs="
      << inprocess.sweep_parameters.max_candidates
      << " inprocess.sweep_flip_rounds="
      << inprocess.sweep_parameters.flip_rounds
      << " inprocess.sweep_seed_cap=" << inprocess.sweep_parameters.max_seeds
      << " inprocess.sweep_environment_ticks="
      << inprocess.sweep_parameters.env_ticks
      << " inprocess.sweep_round_ticks="
      << inprocess.sweep_parameters.round_ticks
      << " inprocess.sweep_proof_steps="
      << inprocess.sweep_parameters.max_proof_steps
      << " inprocess.sweep_strip_root_false="
      << inprocess.sweep_parameters.strip_false
      << " inprocess.sweep_measure_closure="
      << inprocess.sweep_parameters.measure_closure
      << " inprocess.sweep_full_partition="
      << inprocess.sweep_parameters.full_partition
      << " inprocess.sweep_skip_embedded_fixed="
      << inprocess.sweep_parameters.skip_embedded_fixed
      << " inprocess.sweep_resume=" << inprocess.sweep_parameters.resume
      << " inprocess.sweep_force_general_proof="
      << inprocess.sweep_parameters.force_general_proof
      << " inprocess.congruence_productivity_permille="
      << inprocess.congruence_productivity_permille
      << " inprocess.sweep_productivity_permille="
      << inprocess.sweep_productivity_permille
      << " inprocess.vivify_irredundant_productivity_percent="
      << inprocess.vivify_irredundant_productivity_percent
      << " inprocess.vivify_tier_mode="
      << unsigned(inprocess.vivify_tier_mode)
      << " inprocess.vivify_redundant_share="
      << inprocess.vivify_redundant_share
      << " inprocess.vivify_total_share=" << inprocess.vivify_total_share;
  for (size_t i = 0; i < inprocess.vivify_tier_shares.size(); ++i)
    out << " inprocess.vivify_tier_share" << i << '='
        << inprocess.vivify_tier_shares[i]
        << " inprocess.vivify_tier_scope" << i << '='
        << unsigned(inprocess.vivify_tier_scopes[i]);
  out << " inprocess.closure_delay=" << inprocess.closure_delay
      << " inprocess.split_clocks=" << inprocess.split_clocks
      << " inprocess.watermarks=" << inprocess.watermarks
      << " inprocess.preprocess_followups="
      << inprocess.preprocess_followups
      << " inprocess.hold_subsume_until_eliminate="
      << inprocess.hold_subsume_until_eliminate
      << " inprocess.forward_midround_budget="
      << inprocess.forward_midround_budget
      << " inprocess.couple_factor_bound="
      << inprocess.couple_factor_bound;
  for (size_t i = 0; i < inprocess.program.size(); ++i) {
    const strategy::InprocessStep &step = inprocess.program[i];
    out << " inprocess.step" << i << '=' << step.id << ':' << step.rule << ':'
        << (step.phase == strategy::InprocessPhase::Probe ? 'P' : 'E') << ':'
        << step.enabled << ':' << step.preprocessing << ':'
        << static_cast<unsigned>(step.followup) << ":effort=";
    if (step.effort_permille)
      out << *step.effort_permille;
    else
      out << "inherit";
    out << ":max=" << step.max_applications << ":cursor=";
    if (step.cursor_enabled)
      out << *step.cursor_enabled;
    else
      out << "inherit";
    out << ":order=";
    if (step.candidate_order)
      out << candidate_order_name(*step.candidate_order);
    else
      out << "inherit";
    if (const auto *p =
            std::get_if<strategy::BveParameters>(&step.parameters)) {
      out << ":bve(" << p->gate_mask << ',' << p->growth_bound << ','
          << p->occurrence_limit << ',' << p->clause_size_limit << ','
          << p->xor_arity_limit << ',' << p->resolvent_size_limit << ','
          << p->backward_occurrence_limit << ',' << p->definition_budget << ','
          << p->definition_cores << ','
          << p->definition_core_budget_multiplier << ',' << p->backward << ','
          << static_cast<unsigned>(p->candidate_scope) << ','
          << p->resolvent_count_limit << ','
          << static_cast<unsigned>(p->traversal) << ')';
    } else if (const auto *p =
                   std::get_if<strategy::SubsumeForwardParameters>(
                       &step.parameters)) {
      out << ":c1(" << p->clause_size_limit << ','
          << p->large_occurrence_limit << ','
          << p->binary_occurrence_limit << ')';
    } else if (const auto *p =
                   std::get_if<strategy::StrengthenParameters>(
                       &step.parameters)) {
      out << ":c2(" << p->clause_size_limit << ','
          << p->occurrence_limit << ')';
    } else if (const auto *p =
                   std::get_if<strategy::CongruenceParameters>(
                       &step.parameters)) {
      out << ":congruence(" << p->and_arity_limit << ','
          << p->gate_count_limit << ',' << p->xor_arity_limit << ','
          << static_cast<unsigned>(p->binary_watch_order) << ')';
    } else if (const auto *p =
                   std::get_if<strategy::InstantiateParameters>(
                       &step.parameters)) {
      out << ":instantiate(" << p->minimum_clause_size << ','
          << p->occurrence_limit << ',' << p->minimum_unassigned << ','
          << p->include_redundant << ',' << p->new_material_threshold << ')';
    } else if (const auto *p =
                   std::get_if<strategy::BackboneParameters>(
                       &step.parameters)) {
      out << ":backbone(" << p->initial_rounds << ','
          << p->maximum_rounds << ')';
    } else if (const auto *p = std::get_if<SweepLimits>(&step.parameters)) {
      out << ":sweep(" << p->max_depth << ',' << p->max_depth_ceiling << ','
          << p->max_env_vars << ',' << p->max_env_vars_ceiling << ','
          << p->max_env_clauses << ',' << p->max_env_clauses_ceiling << ','
          << p->max_candidates << ',' << p->env_ticks << ','
          << p->max_proof_steps << ',' << p->max_seeds << ','
          << p->round_ticks << ',' << p->strip_false << ','
          << p->measure_closure << ',' << p->full_partition << ','
          << p->skip_embedded_fixed << ',' << p->flip_rounds << ','
          << p->resume << ',' << p->force_general_proof << ')';
    } else if (const auto *p =
                   std::get_if<strategy::VivifyParameters>(&step.parameters)) {
      out << ":vivify(" << unsigned(p->scope) << ',' << p->reuse << ','
          << p->flush << ',' << p->irredundant_sort_ratio << ')';
    } else {
      out << ":inherit";
    }
  }
  return out.str();
}

DefaultPolicy::DefaultPolicy()
    : chrono_levels(DefaultStrategyConfig::CHRONOLOGICAL_LEVELS_DEFAULT),
      chrono_reuse_trail_(false), base_config_(), config_(base_config_),
      default_branching_(&config_.branching),
      default_reduction_(&config_.reduction), inprocess_(&config_.inprocess) {
  // Avoid constructing and then copying a third default program. Besides
  // needless startup allocation, that transient copy can cross a 2-MiB heap
  // arena boundary and become visible in peak-RSS comparisons.
  default_reduction_.ramp = config_.reduction.ramp_fraction;
  retier_.next_conflicts = retier_.interval =
      config_.reduction.retier_initial_interval;
  assert(config_.valid());
}

DefaultPolicy::DefaultPolicy(const DefaultStrategyConfig &config)
    : chrono_levels(config.analysis.chronological_levels),
      chrono_reuse_trail_(config.analysis.reuse_ranked_trail_suffix),
      base_config_(config), config_(config),
      default_branching_(&config_.branching),
      default_reduction_(&config_.reduction), inprocess_(&config_.inprocess) {
  default_reduction_.ramp = config_.reduction.ramp_fraction;
  retier_.next_conflicts = retier_.interval =
      config_.reduction.retier_initial_interval;
  std::string config_error;
  if (!config_.valid(&config_error)) {
    std::fprintf(stderr, "c ERROR: invalid DefaultStrategyConfig: %s\n",
                 config_error.c_str());
    std::abort();
  }
}

const DefaultStrategyConfig::Inprocess &
DefaultInprocessScheduler::config() const {
  if (config_)
    return *config_;
  static const DefaultStrategyConfig::Inprocess defaults;
  return defaults;
}

uint32_t DefaultBveBoundRamp::num_passes() const {
  const DefaultStrategyConfig::Inprocess *cfg = config_;
  if (!cfg) {
    static const DefaultStrategyConfig::Inprocess defaults;
    cfg = &defaults;
  }
  const uint32_t cap = cfg->bve_default_ceiling;
  uint32_t n = 0;
  for (uint32_t i = 0; i < cfg->bve_bounds.size(); i++)
    if (cfg->bve_bounds[i] <= cap)
      n = i + 1;
  return n ? n : 1;
}

uint32_t DefaultBveBoundRamp::bound(uint32_t pass) const {
  const DefaultStrategyConfig::Inprocess *cfg = config_;
  if (!cfg) {
    static const DefaultStrategyConfig::Inprocess defaults;
    cfg = &defaults;
  }
  const size_t last = cfg->bve_bounds.size() - 1;
  return cfg->bve_bounds[pass < cfg->bve_bounds.size() ? pass : last];
}

void CadicalArenaOrder::order(const Kernel &k, std::vector<Ref> &refs) {
  if (!k.h || k.h->queue_last == INVALID_VAR || refs.empty())
    return;
  std::vector<uint8_t> live(k.arena.size());
  for (const Ref ref : refs)
    live[ref] = 1;
  std::vector<Ref> ordered;
  ordered.reserve(refs.size());
  for (const bool opposite : {true, false})
    for (Var v = k.h->queue_last; v != INVALID_VAR; v = k.h->links[v].prev) {
      Lit lit = make_lit(v, k.h->saved[v] < 0);
      if (opposite)
        lit = negate(lit);
      for (const WatchEntry w : k.watches.entries(lit)) {
        if (w.binary())
          continue;
        const Ref ref = w.ref();
        if (ref < live.size() && live[ref]) {
          ordered.push_back(ref);
          live[ref] = 0;
        }
      }
    }
  for (const Ref ref : refs)
    if (live[ref])
      ordered.push_back(ref);
  refs.swap(ordered);
}

namespace {
struct ScopedArenaOrdering {
  Kernel &k;
  ArenaOrdering *saved;
  ScopedArenaOrdering(Kernel &kernel, ArenaOrdering *ordering)
      : k(kernel), saved(kernel.arena_ordering) {
    k.arena_ordering = ordering;
  }
  ~ScopedArenaOrdering() { k.arena_ordering = saved; }
};
} // namespace

void DefaultPolicy::observe_glue(const Kernel &k, uint32_t glue) {
  DefaultRestartControl::observe_glue(k, config_.restart, glue);
}

void DefaultPolicy::observe_decision_rate(const Kernel &k) {
  DefaultRestartControl::observe_decision_rate(k, config_.restart);
}

uint32_t DefaultPolicy::want_bump_reasons(const Kernel &k) const {
  if (!bump_reasons_limit_)
    return 0;
  if (bump_reasons_delay_.count)
    return 0;
  if (averages[k.h->stable].decision_rate.value >= bump_reasons_rate_)
    return 0;
  return bump_reasons_limit_;
}

void DefaultPolicy::tick_reluctant() {
  DefaultRestartControl::tick_reluctant(config_.restart);
}

bool DefaultPolicy::want_restart(const Kernel &k) const {
  return DefaultRestartControl::want_restart(k, config_.restart);
}

bool DefaultPolicy::want_switch_mode(const Kernel &k) const {
  return DefaultModeControl::wants_switch(k, search_ticks(k));
}

void DefaultPolicy::update_mode_limits(const Kernel &k) {
  if (DefaultModeControl::update_limits(k, config_.mode, search_ticks(k)))
    update_restart_limit(k);
}

void DefaultPolicy::update_restart_limit(const Kernel &k) {
  DefaultRestartControl::update_restart_limit(k, config_.restart);
}

bool DefaultPolicy::want_reduce(const Kernel &k) const {
  return DefaultDatabaseControl::wants_reduce(k);
}

bool DefaultPolicy::want_rephase(const Kernel &k) const {
  return DefaultPhaseControl::wants_rephase(k, config_.rephase);
}

ApplyResult DefaultPolicy::prepare_rephase_root(Kernel &k) {
  // Restart is publicly applicable as a level-zero no-op, but this helper
  // preserves the shipped policy's old root-preparation schedule.
  if (k.level > 0 && restart_guard(k)) {
    heuristics_update_target_phases(k);
    (void)default_direct_rule(k, "Restart", "keep-level=0;rephase=1",
                              [&] { return restart_backtrack_to(k, 0); });
  }
  // Kissat rephase.c backtracks, propagates and flushes the root trail before
  // changing phases. Chronological backtracking can retain out-of-order root
  // assignments that must be rescanned after their transient blockers vanish.
  // Warm-up must not defer those scans until after its first decision.
  const ApplyResult result = default_propagate(k, "rephase-root");
  if (result == ApplyResult::Ok) {
    assert(k.level == 0 && kernel_propagation_fixpoint(k));
    k.unflushed_root = 0;
  }
  return result;
}

bool DefaultPolicy::want_reorder(const Kernel &k) const {
  return DefaultPhaseControl::wants_reorder(k, config_.reorder);
}

void DefaultPolicy::update_reorder_limit(const Kernel &k) {
  DefaultPhaseControl::update_reorder_limit(k, config_.reorder);
}

void DefaultPolicy::update_rephase_limit(const Kernel &k) {
  DefaultPhaseControl::update_rephase_limit(k, config_.rephase);
}

uint64_t DefaultPolicy::walk_effort_reference(const Kernel &k) const {
  // Kissat runs Walk from the search loop with `solver->probing == false`.
  // SET_EFFORT_LIMIT therefore reads `last.ticks.eliminate`, shared with the
  // Eliminate pipeline.  Entering the simplifier timing profile does not flip
  // that semantic flag, and Walk does not own or advance an independent
  // anchor.
  const uint64_t now = search_ticks(k);
  const uint64_t anchor = inprocess_.elim_clock.anchor;
  uint64_t reference = now >= anchor ? now - anchor : 0;
  if (reference < config_.inprocess.minimum_effort_ticks)
    reference = config_.inprocess.minimum_effort_ticks;
  return reference;
}

void DefaultPolicy::reset_schedule(const Kernel &k) {
  const uint64_t conflicts = k.stats.conflicts;
  const uint64_t ticks = search_ticks(k);

  averages[0] = averages[1] = {};
  update_restart_limit(k);
  // Kissat initializes Reduce from `reduceinit` independently of the cadence
  // used after a completed reduction (kimits.c:kissat_init_limits).  The
  // arithmetic interval is a recurrence delta, not an alternative first
  // deadline: using it here postponed LegacySearch's first Reduce from
  // conflict 1000 to 2000.
  reduce.next_conflicts = conflicts + config_.reduction.initial_interval;
  mode = {};
  mode.conflicts_limit = conflicts + config_.mode.initial_conflicts;
  mode.ticks_at_focus_entry = ticks;
  reluctant = {};
  reluctant.wait = config_.restart.reluctant_period;
  rephase = {};
  rephase.next_conflicts = conflicts + config_.rephase.initial_interval;
  structural_seed_cursor_ = 0;
  reorder = {};
  reorder.next_conflicts = conflicts + config_.reorder.initial_interval;
  bump_reasons_delay_ = {};
  retier_.next_conflicts = config_.reduction.retier_initial_interval;
  retier_.interval = config_.reduction.retier_initial_interval;
  if (dynamic_tiers_)
    retier_.next_conflicts = conflicts + retier_.interval;
  default_branching_.reset(conflicts);
  inprocess_.reset(k);
}

static uint64_t active_variables(const Kernel &k) {
  // Kissat's `solver->active` is live state.  Cumulative retirement counters
  // cannot reconstruct it after compaction and also miss Factor's fresh
  // activation, which is precisely what makes `proberounds` enter round two.
  return kernel_active_variables(k);
}

// Formula rules publish events without depending on decision heuristics.
// Consume each Substitute round before a later round or watch reconnection
// derives more roots: native substitute_round retires its representatives at
// that boundary. Call-wide root-first batching changes arbitrary heap removals.
static ApplyResult default_substitute_round(Kernel &k) {
  const size_t trail_begin = k.trail.size();
  const ApplyResult result =
      substitute_apply_round(k, /*reconnect_large_watches=*/false);
  heuristics_consume_root_assignments(k, trail_begin);
  heuristics_consume_retirements(k);
  return result;
}

static ApplyResult default_substitute_complete(Kernel &k, uint32_t max_rounds) {
  // Keep the unbudgeted public complete helper's productivity/cap contract;
  // only DefaultPolicy's publication points differ from the rule-only API.
  const auto active = [&] {
    const uint64_t retired = static_cast<uint64_t>(kernel_root_fixed(k)) +
                            k.stats.bve_eliminated + k.stats.substitute_vars;
    return uint64_t{k.nvars} > retired ? uint64_t{k.nvars} - retired : 0;
  };
  const bool connected_at_entry = k.large_watches_connected;
  const uint32_t trail_at_entry = static_cast<uint32_t>(k.trail.size());
  ApplyResult result = ApplyResult::NoOp;
  for (uint32_t round = 0; round < max_rounds; ++round) {
    const uint64_t active_before = active();
    const ApplyResult current = default_substitute_round(k);
    if (current == ApplyResult::Unsat)
      return current;
    if (current == ApplyResult::Ok)
      result = current;
    if (active() == active_before)
      break;
  }
  if (connected_at_entry && !k.large_watches_connected &&
      substitute_reconnect_large_watches(k, trail_at_entry) == ApplyResult::Unsat)
    return ApplyResult::Unsat;
  return result;
}

static uint64_t scale_inprocessing_delta(
    const Kernel &k, uint64_t delta,
    const DefaultStrategyConfig::Inprocess &config) {
  // kimits.c calls `kissat_logn(C + 1)`, while kissat_logn(count) computes
  // log10(count + 9).  Preserve both additions: the scale is therefore based
  // on log10(C + 10), not log10(C + 1).  The distinction crosses an integer
  // deadline at common states (for example 22,575 clauses and probe round 2).
  const double f =
      std::log10(static_cast<double>(kernel_irredundant_clauses(k)) + 1.0 +
                 config.logarithm_offset) -
      config.scale_log_shift;
  return static_cast<uint64_t>((config.scale_quadratic * f * f +
                                config.scale_constant) *
                               static_cast<double>(delta));
}

namespace {

uint32_t reuse_trail_level(const Kernel &k, uint32_t jump) {
  const uint32_t begin = k.frames[jump + 1];
  const uint32_t end = static_cast<uint32_t>(k.trail.size());
  if (begin >= end || !k.h)
    return jump;
  uint32_t best_pos = begin;
  Var best = 0;
  bool have_best = false;
  for (uint32_t i = begin; i < end; i++) {
    const Var v = var_of(k.trail[i]);
    if (kernel_var_retired(k, v))
      continue;
    if (!have_best) {
      best = v;
      best_pos = i;
      have_best = true;
      continue;
    }
    const bool better =
        k.h->stable
            ? (k.h->scores.score[v] > k.h->scores.score[best] ||
               (k.h->scores.score[v] == k.h->scores.score[best] && v < best))
            : k.h->links[v].stamp > k.h->links[best].stamp;
    if (better) {
      best = v;
      best_pos = i;
    }
  }
  if (!have_best) // the whole suffix is retired variables: nothing to keep
    return jump;
  uint32_t res = jump;
  while (res + 1 < k.level && k.frames[res + 1] <= best_pos)
    res++;
  return res;
}


struct TickSinkScope {
  Kernel &k;
  TickSinkScope(Kernel &kk, uint64_t Stats::*ctr) : k(kk) {
    k.tick_sink = ctr ? &(k.stats.*ctr) : nullptr;
  }
  ~TickSinkScope() { k.tick_sink = nullptr; }
  TickSinkScope(const TickSinkScope &) = delete;
  TickSinkScope &operator=(const TickSinkScope &) = delete;
};

#ifdef TACTIX_ENABLE_RULE_JOURNAL
struct RuleJournalMeterScope {
  explicit RuleJournalMeterScope(RuleJournalMeter meter) {
    rule_journal_set_effort_meter(meter);
  }
  ~RuleJournalMeterScope() { rule_journal_set_effort_meter(nullptr); }
  RuleJournalMeterScope(const RuleJournalMeterScope &) = delete;
  RuleJournalMeterScope &operator=(const RuleJournalMeterScope &) = delete;
};
#endif

struct InprocessScope {
  Kernel &k;
  bool previous_inprocessing;
  bool previous_phase_saving_suppressed;
  explicit InprocessScope(Kernel &kk)
      : k(kk), previous_inprocessing(kk.inprocessing),
        previous_phase_saving_suppressed(kk.phase_saving_suppressed) {
    k.inprocessing = true;
    // Kissat keeps `solver->probing` set across the complete Probe pipeline.
    // All speculative and learned assignments in that scope therefore leave
    // `phases.saved` untouched.  Individual Tactix rules may use different
    // propagation engines, so the strategy scope owns the equivalent wire.
    k.phase_saving_suppressed = true;
  }
  ~InprocessScope() {
    k.phase_saving_suppressed = previous_phase_saving_suppressed;
    k.inprocessing = previous_inprocessing;
  }
  InprocessScope(const InprocessScope &) = delete;
  InprocessScope &operator=(const InprocessScope &) = delete;
};

// Kissat's `search_ticks` is charged only by the ordinary CDCL search
// propagator.  Startup propagation, both Lucky trials, sparse root collection,
// and `probe_initially` all run before search and therefore must not seed mode
// or inprocessing effort references.  This scope suppresses only that tick
// currency; unlike `InprocessScope` it deliberately leaves assignment-time
// phase saving unchanged outside the actual Probe pipeline.
struct PreSearchTickScope {
  Kernel &k;
  bool previous_inprocessing;
  explicit PreSearchTickScope(Kernel &kk)
      : k(kk), previous_inprocessing(kk.inprocessing) {
    k.inprocessing = true;
  }
  ~PreSearchTickScope() { k.inprocessing = previous_inprocessing; }
  PreSearchTickScope(const PreSearchTickScope &) = delete;
  PreSearchTickScope &operator=(const PreSearchTickScope &) = delete;
};

uint64_t meter_probe(const Kernel &k) { return k.stats.probe_ticks; }
uint64_t meter_backbone(const Kernel &k) { return k.stats.backbone_ticks; }
uint64_t meter_vivify(const Kernel &k) { return k.stats.vivify_ticks; }
uint64_t meter_instantiate(const Kernel &k) { return k.stats.instantiate_ticks; }
uint64_t meter_bve(const Kernel &k) { return k.stats.bve_resolutions; }
uint64_t meter_forward_pair(const Kernel &k) {
  return k.stats.strengthen_visits + k.stats.forward_visits;
}
uint64_t meter_transitive(const Kernel &k) {
  return k.transitive_budget_checked ? k.stats.transitive_checked
                                     : k.stats.transitive_ticks;
}
uint64_t meter_factor(const Kernel &k) { return k.stats.factor_ticks; }
uint64_t meter_ternary(const Kernel &k) { return k.stats.ternary_ticks; }
uint64_t meter_hbr(const Kernel &k) { return k.stats.hbr_ticks; }
uint64_t meter_bce(const Kernel &k) { return k.stats.bce_ticks; }
uint64_t meter_cce(const Kernel &k) { return k.stats.cce_ticks; }
uint64_t meter_sweep(const Kernel &k) { return sweep_effort(k); }
#ifdef TACTIX_ENABLE_RULE_JOURNAL
// Congruence has no shipped effort ceiling in Kissat.  Keep its inclusive
// logical counter available to compile-time rule journals without placing it
// back in EFFORT_SPECS (which would make the meter behavior-affecting).
uint64_t meter_congruence(const Kernel &k) { return k.stats.congruence_ticks; }
#endif
uint64_t meter_substitute(const Kernel &k) { return k.stats.substitute_ticks; }

SweepLimits configured_sweep_limits(
    const DefaultStrategyConfig::Inprocess &config) {
  return config.sweep_parameters;
}

struct EffortSpec {
  const char *name;
  uint32_t DefaultStrategyConfig::Inprocess::*permille;
  uint64_t (*meter)(const Kernel &);
  bool dosed;
  bool budget_aware;
  uint64_t Stats::*tick_counter = nullptr;
  bool closure = false;
};

struct DelaySpec {
  const char *name;
  uint64_t (*yield)(const Kernel &);
  uint64_t (*denom)(const Kernel &);
  uint32_t DefaultStrategyConfig::Inprocess::*permille;
  bool denom_delta;
};
constexpr DelaySpec DELAY_SPECS[] = {
    {"Congruence", [](const Kernel &k) { return k.stats.congruence_merges; },
     active_variables,
     &DefaultStrategyConfig::Inprocess::congruence_productivity_permille,
     false},
    // kissat `sweep.c`: `if (kissat_average (eliminated, swept) < 0.001)
    // BUMP_DELAY (sweep)`, where `swept` counts the scheduled VARIABLES the
    // call swept, not the candidate pairs its environments solved.
    {"Sweep", [](const Kernel &k) {
       return k.stats.sweep_equivalences + k.stats.sweep_units;
     },
     [](const Kernel &k) { return k.stats.sweep_swept; },
     &DefaultStrategyConfig::Inprocess::sweep_productivity_permille, true},
};
static const DelaySpec *delay_spec(const char *name) {
  for (const DelaySpec &d : DELAY_SPECS)
    if (!std::strcmp(d.name, name))
      return &d;
  return nullptr;
}

constexpr EffortSpec EFFORT_SPECS[] = {
    {"BVE", &DefaultStrategyConfig::Inprocess::bve_permille, meter_bve, true,
     false, nullptr},
    {"Probe", &DefaultStrategyConfig::Inprocess::probe_permille, meter_probe,
     true, false, &Stats::probe_ticks},
    {"HyperBinaryRes",
     &DefaultStrategyConfig::Inprocess::hyper_binary_permille, meter_hbr, true,
     true, &Stats::hbr_ticks},
    {"Backbone", &DefaultStrategyConfig::Inprocess::backbone_permille,
     meter_backbone, false, true, &Stats::backbone_ticks},
    {"TransitiveReduce", &DefaultStrategyConfig::Inprocess::transitive_permille,
     meter_transitive, true, true},
    {"Vivify", &DefaultStrategyConfig::Inprocess::vivify_permille,
     meter_vivify, false, true, &Stats::vivify_ticks},
    {"Strengthen", &DefaultStrategyConfig::Inprocess::strengthen_permille,
     meter_forward_pair, false, true, nullptr},
    {"SubsumeForward",
     &DefaultStrategyConfig::Inprocess::subsume_forward_permille,
     meter_forward_pair, false, true, nullptr},
    {"Factor", &DefaultStrategyConfig::Inprocess::factor_permille,
     meter_factor, false, true, nullptr},
    {"HyperTernaryRes",
     &DefaultStrategyConfig::Inprocess::hyper_ternary_permille, meter_ternary,
     false, true, nullptr},
    {"BCE", &DefaultStrategyConfig::Inprocess::bce_permille, meter_bce, false,
     true},
    {"CCE", &DefaultStrategyConfig::Inprocess::cce_permille, meter_cce, false,
     true},
    {"Instantiate", &DefaultStrategyConfig::Inprocess::instantiate_permille,
     meter_instantiate, false, true, &Stats::instantiate_ticks},
    {"Sweep", &DefaultStrategyConfig::Inprocess::sweep_permille, meter_sweep,
     false, true},
    {"Substitute", &DefaultStrategyConfig::Inprocess::substitute_permille,
     meter_substitute, false, true},
};

const EffortSpec *effort_spec(const char *name) {
  for (const EffortSpec &s : EFFORT_SPECS)
    if (!std::strcmp(s.name, name))
      return &s;
  return nullptr; // all-or-nothing rule: no titration, no meter
}

#ifdef TACTIX_ENABLE_RULE_JOURNAL
const char *effort_currency(const char *name) {
  if (!std::strcmp(name, "BVE"))
    return "resolutions";
  if (!std::strcmp(name, "Strengthen") ||
      !std::strcmp(name, "SubsumeForward"))
    return "forward-plus-strengthen-visits";
  if (!std::strcmp(name, "Sweep"))
    return "sweep-scheduled-effort";
  if (!std::strcmp(name, "TransitiveReduce"))
    return "transitive-cache-lines";
  if (!std::strcmp(name, "Congruence"))
    return "congruence-ticks";
  if (!std::strcmp(name, "Substitute"))
    return "substitute-cache-lines";
  return "probing-rule-ticks";
}

const char *journal_result(ApplyResult result) {
  switch (result) {
  case ApplyResult::Ok:
    return "applied";
  case ApplyResult::NoOp:
    return "no-op";
  case ApplyResult::Conflict:
    return "conflict";
  case ApplyResult::Sat:
    return "sat";
  case ApplyResult::Unsat:
    return "refuted";
  }
  return "unknown";
}
#endif

template <class Apply>
ApplyResult metered_rule_apply(Kernel &k,
                               uint64_t (*meter)(const Kernel &),
                               Apply &&apply) {
#ifdef TACTIX_ENABLE_RULE_JOURNAL
  RuleJournalMeterScope journal_meter(meter);
#else
  (void)meter;
#endif
  (void)k;
  return apply();
}

// The meter the compile-time journal prices an entry in.  For every metered
// rule this is the ledger meter; Congruence has none, so the journal alone
// reads its inclusive counter.  Scheduling never consults this function, so
// production binaries see exactly `e.meter`.
uint64_t (*journal_effort_meter(
    const DefaultInprocessScheduler::SlotEntry &e,
    const RuleVTable &r))(const Kernel &) {
#ifdef TACTIX_ENABLE_RULE_JOURNAL
  if (!e.meter && !std::strcmp(r.name, "Congruence"))
    return meter_congruence;
#else
  (void)r;
#endif
  return e.meter;
}

SlotGroup slot_group(strategy::InprocessPhase phase) {
  return phase == strategy::InprocessPhase::Probe ? SlotGroup::Probe
                                                   : SlotGroup::Eliminate;
}

FollowupKind followup_kind(strategy::Followup followup) {
  switch (followup) {
  case strategy::Followup::AfterCongruence:
    return FollowupKind::AfterCongruence;
  case strategy::Followup::AfterSweepOrFinal:
    return FollowupKind::AfterSweepOrFinal;
  default:
    return FollowupKind::None;
  }
}


} // namespace

const SlotOrderRow *default_slot_order(size_t *count) {
  struct ReferenceRows {
    std::vector<strategy::InprocessStep> program =
        strategy::reference_inprocess_program();
    std::vector<SlotOrderRow> rows;
    ReferenceRows() {
      rows.reserve(program.size());
      for (const strategy::InprocessStep &step : program)
        rows.push_back({step.rule.c_str(), slot_group(step.phase)});
    }
  };
  static const ReferenceRows reference;
  if (count)
    *count = reference.rows.size();
  return reference.rows.data();
}


const char *candidate_order_name(CandidateOrder o) {
  switch (o) {
  case CandidateOrder::Native:
    return "native";
  case CandidateOrder::Reverse:
    return "reverse";
  case CandidateOrder::Random:
    return "random";
  case CandidateOrder::OccAsc:
    return "occ-asc";
  case CandidateOrder::OccDesc:
    return "occ-desc";
  case CandidateOrder::NegOccDesc:
    return "negocc-desc";
  case CandidateOrder::Heuristic:
    return "heuristic";
  }
  return "native";
}

bool parse_candidate_order(const char *s, CandidateOrder *out) {
  static const struct {
    const char *n;
    CandidateOrder o;
  } table[] = {
      {"native", CandidateOrder::Native},
      {"reverse", CandidateOrder::Reverse},
      {"random", CandidateOrder::Random},
      {"occ-asc", CandidateOrder::OccAsc},
      {"occ-desc", CandidateOrder::OccDesc},
      {"negocc-desc", CandidateOrder::NegOccDesc},
      {"heuristic", CandidateOrder::Heuristic},
  };
  for (const auto &row : table)
    if (!std::strcmp(s, row.n)) {
      *out = row.o;
      return true;
    }
  return false;
}

namespace {

uint64_t instance_key(uint64_t inst) {
  Lit l;
  return lit_of_instance(inst, &l) ? static_cast<uint64_t>(l) : inst;
}

uint32_t lit_occurrences(const Kernel &k, Lit l, bool binary_only) {
  uint32_t n = 0;
  for (const WatchEntry w : k.watches.entries(l))
    n += w.binary() ? 1u : (binary_only ? 0u : 1u);
  return n;
}

double transitive_activity(const Kernel &k, Var v) {
  // AE-kissat-MAB routes transitive.c through kissat_get_scores: when CHB is
  // the selected stable arm, its ordering is part of that arm too.  Other
  // Kissat inprocessors retain their original EVSIDS coupling.
  if (k.h->mab_enabled && k.h->stable_heuristic == 1)
    return k.h->chb_scores.score[v];
  return k.h->scores.score[v];
}

uint64_t order_key(const Kernel &k, CandidateOrder arm, uint64_t inst,
                   bool transitive_reference_order,
                   const std::vector<Var> *reference_compact_order,
                   const std::vector<Var> *reference_compact_position) {
  Lit l;
  if (!lit_of_instance(k, inst, &l) || var_of(l) >= k.nvars)
    return 0; // not a literal payload: leave it where the native order had it
  const Var v = var_of(l);
  switch (arm) {
  case CandidateOrder::OccAsc:
  case CandidateOrder::OccDesc: {
    const uint64_t occ = lit_occurrences(k, make_lit(v, false), false) +
                         lit_occurrences(k, make_lit(v, true), false);
    return arm == CandidateOrder::OccAsc ? occ : ~occ;
  }
  case CandidateOrder::NegOccDesc:
    return ~static_cast<uint64_t>(lit_occurrences(k, negate(l), true));
  case CandidateOrder::Heuristic: {
    // transitive.c schedules variable indices but its comparator applies IDX
    // once more before consulting activity.  Keep that literal reference
    // behavior local to TransitiveReduce; other users of the generic arm rank
    // the candidate's own variable as expected.
    Var proxy = transitive_reference_order ? v >> 1 : v;
    if (transitive_reference_order && reference_compact_order &&
        reference_compact_position &&
        v < reference_compact_position->size()) {
      const Var compact = (*reference_compact_position)[v];
      if (compact != INVALID_VAR &&
          (compact >> 1) < reference_compact_order->size())
        proxy = (*reference_compact_order)[compact >> 1];
    }
    if (k.h->stable) {
      const double s = transitive_reference_order
                           ? transitive_activity(k, proxy)
                           : k.h->scores.score[proxy];
      uint64_t bits = 0;
      std::memcpy(&bits, &s, sizeof bits);
      return bits;
    }
    return k.h->links[proxy].stamp;
  }
  default:
    return 0;
  }
}

template <class Less>
void kissat_reference_sort(std::vector<Var> &values, Less less) {
  const size_t n = values.size();
  if (n <= 1)
    return;

  auto greater_swap = [&](size_t p, size_t q) {
    if (less(values[q], values[p]))
      std::swap(values[p], values[q]);
  };

  constexpr size_t quick_sort_limit = 10;
  size_t left = 0, right = n - 1;
  std::vector<std::pair<size_t, size_t>> pending;
  if (right - left > quick_sort_limit) {
    for (;;) {
      const size_t middle = left + (right - left) / 2;
      std::swap(values[middle], values[right - 1]);
      greater_swap(left, right - 1);
      greater_swap(left, right);
      greater_swap(right - 1, right);

      size_t i = left;
      size_t j = right - 1;
      const Var pivot = values[j];
      for (;;) {
        while (less(values[++i], pivot))
          ;
        while (less(pivot, values[--j]))
          if (j == left)
            break;
        if (i >= j)
          break;
        std::swap(values[i], values[j]);
      }
      std::swap(values[i], values[right - 1]);

      size_t other_left, other_right;
      if (i - left < right - i) {
        other_left = i + 1;
        other_right = right;
        right = i - 1;
      } else {
        other_left = left;
        other_right = i - 1;
        left = i + 1;
      }
      if (right - left > quick_sort_limit) {
        assert(other_right - other_left > quick_sort_limit);
        pending.emplace_back(other_left, other_right);
      } else if (other_right - other_left > quick_sort_limit) {
        left = other_left;
        right = other_right;
      } else if (!pending.empty()) {
        left = pending.back().first;
        right = pending.back().second;
        pending.pop_back();
      } else {
        break;
      }
    }
  }

  // Kissat finishes the whole array with the same sentinel-seeded insertion
  // sort after quicksort partitions it (sort.h:83-104).
  for (size_t i = n - 1; i > 0; i--)
    greater_swap(i - 1, i);
  for (size_t i = 2; i < n; i++) {
    const Var pivot = values[i];
    size_t j = i;
    while (less(pivot, values[j - 1])) {
      values[j] = values[j - 1];
      j--;
    }
    values[j] = pivot;
  }
}

bool rank_transitive_reference(const Kernel &k, uint64_t *insts,
                               uint32_t n) {
  if (!k.h || k.compact_import_order.empty())
    return false;
  std::vector<Var> compact_position(k.nvars, INVALID_VAR);
  for (Var compact = 0; compact < k.compact_import_order.size(); compact++)
    compact_position[k.compact_import_order[compact]] = compact;

  std::vector<uint64_t> positive(k.nvars, UINT64_MAX);
  std::vector<uint64_t> negative(k.nvars, UINT64_MAX);
  std::vector<Var> compact_candidates;
  std::vector<uint8_t> seen(k.compact_import_order.size(), 0);
  for (uint32_t i = 0; i < n; i++) {
    Lit lit;
    if (!lit_of_instance(k, insts[i], &lit) || var_of(lit) >= k.nvars)
      return false;
    const Var v = var_of(lit);
    const Var compact = compact_position[v];
    if (compact == INVALID_VAR)
      return false;
    (negated(lit) ? negative[v] : positive[v]) = insts[i];
    if (!seen[compact]) {
      seen[compact] = 1;
      compact_candidates.push_back(compact);
    }
  }
  // Kissat's `all_variables` seeds the stack in current compact-index order.
  std::sort(compact_candidates.begin(), compact_candidates.end());
  auto less = [&](Var a, Var b) {
    const Var i = a >> 1, j = b >> 1; // transitive.c's second IDX
    const Var iv = k.compact_import_order[i], jv = k.compact_import_order[j];
    if (k.h->stable) {
      const double s = transitive_activity(k, iv);
      const double t = transitive_activity(k, jv);
      if (s < t)
        return true;
      if (s > t)
        return false;
      return i < j;
    }
    return k.h->links[iv].stamp < k.h->links[jv].stamp;
  };
  kissat_reference_sort(compact_candidates, less);

  uint32_t out = 0;
  for (auto it = compact_candidates.rbegin(); it != compact_candidates.rend();
       ++it) {
    const Var v = k.compact_import_order[*it];
    if (positive[v] != UINT64_MAX)
      insts[out++] = positive[v];
    if (negative[v] != UINT64_MAX)
      insts[out++] = negative[v];
  }
  assert(out == n);
  return true;
}

// Kissat's elimination schedule is a mutable indexed max-heap.  It stores the
// negated elimination score, inserts candidates in compact-variable order,
// stops bubble-up at equality, and prefers the left child at equality while
// bubbling down.  Those topology rules are semantic scheduling state: after
// one candidate mutates several occurrence lists, a global re-sort can choose
// a different equal-score variable even when every scalar score is correct.
class BveCandidateHeap {
public:
  void initialize(Kernel &k, const uint64_t *insts, uint32_t n) {
    kernel_ = &k;
    assert(k.dense && !k.bve_occurrence_count_image);
    // Kissat eliminate.c::variable_score reads SIZE_WATCHES for each polarity:
    // one physical dense-stack length containing binary and large entries.
    // Tactix stores those populations separately, so materialize their exact
    // sum once and let the kernel mirror subsequent physical mutations.
    occurrence_counts_.assign(2 * static_cast<size_t>(k.nvars), 0);
    for (Lit lit = 0; lit < 2 * k.nvars; ++lit) {
      uint64_t count = k.dense->large_size(lit);
      for (const WatchEntry watch : k.watches.entries(lit))
        count += watch.binary();
      occurrence_counts_[lit] =
          static_cast<uint32_t>(std::min<uint64_t>(count, UINT32_MAX));
    }
    k.bve_occurrence_count_image = &occurrence_counts_;
    pop_ordinal_ = 0;
    pop_hash_ = 1469598103934665603ull;
    stack_.clear();
    pos_.assign(k.nvars, UINT32_MAX);
    score_.assign(k.nvars, 0.0);
    payload_.assign(k.nvars, INSTANCE_CANONICAL);
    eligible_.assign(k.nvars, 0);
    std::vector<uint8_t> inserted(k.nvars, 0);
    for (uint32_t i = 0; i < n; i++) {
      Lit lit;
      if (!lit_of_instance(k, insts[i], &lit) || var_of(lit) >= k.nvars)
        continue;
      const Var v = var_of(lit);
      eligible_[v] = 1;
      payload_[v] = insts[i];
    }
    // `all_variables` in Kissat walks current compact internal indices.
    for (const Var v : k.compact_import_order)
      if (v < k.nvars && eligible_[v]) {
        insert_initial(v);
        inserted[v] = 1;
      }
    // Stable identities normally all occur in compact_import_order.  Preserve
    // a deterministic complete fallback for bare API kernels that have no H.
    for (Var v = 0; v < k.nvars; v++)
      if (eligible_[v] && !inserted[v])
        insert_initial(v);
#ifdef TACTIX_ENABLE_EVENT_TRACE
    if (const char *selected = std::getenv("TACTIX_EVENT_TRACE_BVE_HEAP")) {
      const char *p = selected;
      while (*p) {
        char *end = nullptr;
        const long external = std::strtol(p, &end, 10);
        if (end == p)
          break;
        for (Var v = 0; v < k.nvars; v++)
          if (static_cast<long>(k.internal_to_external[v] + 1) == external) {
            trace_vars_.push_back(v);
            break;
          }
        p = *end ? end + 1 : end;
      }
    }
    if (std::getenv("SAT_EVENT_TRACE_BVE_SCHEDULE_OCCURRENCES")) {
      const char *selected = std::getenv("TACTIX_EVENT_TRACE_BVE_EXTERNAL");
      if (selected && *selected) {
        const long external = std::strtol(selected, nullptr, 10);
        for (Var v = 0; v < k.nvars; ++v) {
          if (static_cast<long>(k.internal_to_external[v] + 1) != external)
            continue;
          for (uint32_t side = 0; side != 2; ++side) {
            const Lit lit = make_lit(v, side != 0);
            uint32_t ordinal = side ? 0x40000000u : 0;
            for (const OccIndex::Entry entry : k.dense->ordered[lit]) {
              ++ordinal;
              if (entry.binary) {
                const Lit binary[2] = {lit, entry.payload};
                event_trace_bve_pair(
                    k, v, ordinal, binary, 2, INVALID_REF, 0, nullptr, 0,
                    INVALID_REF, 0,
                    side ? "schedule-negative-binary"
                         : "schedule-positive-binary");
              } else {
                const Clause *c = clause_at(k.arena, entry.payload);
                event_trace_bve_pair(
                    k, v, ordinal, c->lits, c->size, entry.payload, c->id(),
                    nullptr, 0, INVALID_REF, 0,
                    side ? "schedule-negative-large"
                         : "schedule-positive-large");
              }
            }
          }
          break;
        }
      }
    }
#endif
    trace_last_pos_.assign(trace_vars_.size(), UINT32_MAX);
    trace_last_score_.assign(trace_vars_.size(), 0.0);
    trace_selected("initial", INVALID_VAR, true);
    uint64_t insertion_hash = 1469598103934665603ull;
    for (const Var v : k.compact_import_order)
      if (v < k.nvars && contains(v)) {
        insertion_hash ^= k.internal_to_external[v] + 1ull;
        insertion_hash *= 1099511628211ull;
      }
    event_trace_bve_schedule(k, stack_.data(), score_.data(),
                             static_cast<uint32_t>(stack_.size()), k.bve_bound,
                             insertion_hash);
  }

  bool empty() const { return stack_.empty(); }

  uint64_t pop_max() {
    assert(!stack_.empty());
    const Var result = stack_[0];
    const Var last = stack_.back();
    stack_.pop_back();
    pos_[result] = UINT32_MAX;
    if (!stack_.empty()) {
      stack_[0] = last;
      pos_[last] = 0;
      bubble_down(last);
    }
    pop_ordinal_++;
    pop_hash_ ^= kernel_->internal_to_external[result] + 1ull;
    pop_hash_ *= 1099511628211ull;
    event_trace_bve_pop(*kernel_, pop_ordinal_, pop_hash_, result,
                        score_[result], stack_.empty() ? INVALID_VAR : stack_[0],
                        static_cast<uint32_t>(stack_.size()));
    trace_selected("pop", result, false);
    return payload_[result];
  }

  static void update_hook(Kernel &, void *state, Var v, bool reinsert) {
    static_cast<BveCandidateHeap *>(state)->update(v, reinsert);
  }

private:
  bool contains(Var v) const {
    return v < pos_.size() && pos_[v] != UINT32_MAX;
  }

  bool active(Var v) const {
    const Kernel &k = *kernel_;
    return v < k.nvars && k.values[make_lit(v, false)] == 0 &&
           !kernel_var_retired(k, v);
  }

  double schedule_score(Var v) const {
    const Kernel &k = *kernel_;
#ifndef NDEBUG
    for (const Lit lit : {make_lit(v, false), make_lit(v, true)}) {
      uint64_t physical = k.dense->large_size(lit);
      for (const WatchEntry watch : k.watches.entries(lit))
        physical += watch.binary();
      assert(physical == occurrence_counts_[lit]);
    }
#endif
    const double relevance =
        k.h ? (k.h->stable ? k.h->scores.score[v] : k.h->links[v].stamp) : 0;
    const double reference = kissat_bve_variable_score(
        relevance, bve_schedule_occurrence_count(k, make_lit(v, false)),
        bve_schedule_occurrence_count(k, make_lit(v, true)),
        k.bve_occurrence_limit);
    return -reference; // Kissat stores the negated score in a max-heap.
  }

  void insert_initial(Var v) {
    const Kernel &k = *kernel_;
    if (!active(v) || v >= k.bve_retry.size())
      return;
    // Kissat's schedule contains exactly the active variables whose
    // `flags.eliminate` bit is set.  `bve_retry` is that bit's kernel image;
    // bound growth rearms it for every variable at the phase boundary below.
    if (!k.bve_retry[v])
      return;
    score_[v] = schedule_score(v);
    pos_[v] = static_cast<uint32_t>(stack_.size());
    stack_.push_back(v);
    bubble_up(v);
  }

  void update(Var v, bool reinsert) {
    // kissat eliminate.c:72-110 (update_after_removing_variable): any
    // non-fixed variable of a removed clause is rescored and, when absent,
    // pushed, whether or not this round scheduled it; the pop-time retry
    // check is the only eligibility test.  Adding a resolvent never pushes.
    if (v >= pos_.size() || !active(v))
      return;
    const double old = score_[v];
    const double now = schedule_score(v);
    score_[v] = now;
    if (contains(v)) {
      if (now > old)
        bubble_up(v);
      else if (now < old)
        bubble_down(v);
    } else if (reinsert) {
      // eliminate.c::update_after_removing_variable pushes an active variable
      // which is absent from the physical schedule without consulting its
      // `flags.eliminate` bit.  A previously failed candidate can therefore
      // re-enter the heap as a ghost: can_eliminate_variable rejects it when it
      // is popped, but its interim presence and bubble path are observable heap
      // topology.  `bve_retry` is the flag image used at initial scheduling and
      // at the pre-apply guard; it must not suppress this physical reinsertion.
      if (payload_[v] == INSTANCE_CANONICAL)
        payload_[v] = lit_instance(*kernel_, make_lit(v, false));
      pos_[v] = static_cast<uint32_t>(stack_.size());
      stack_.push_back(v);
      bubble_up(v);
    }
    trace_selected(reinsert ? "update-reinsert" : "update-add", v, false);
  }

  void trace_selected(const char *stage, Var trigger, bool force) {
    const Var root = stack_.empty() ? INVALID_VAR : stack_[0];
    for (size_t i = 0; i < trace_vars_.size(); i++) {
      const Var v = trace_vars_[i];
      const uint32_t position = contains(v) ? pos_[v] : UINT32_MAX;
      const double score = score_[v];
      if (!force && position == trace_last_pos_[i] &&
          score == trace_last_score_[i])
        continue;
      event_trace_bve_heap(*kernel_, stage, trigger, v, score, position, root,
                           static_cast<uint32_t>(stack_.size()));
      trace_last_pos_[i] = position;
      trace_last_score_[i] = score;
    }
  }

  void bubble_up(Var v) {
    uint32_t at = pos_[v];
    while (at) {
      const uint32_t parent_at = (at - 1) / 2;
      const Var parent = stack_[parent_at];
      if (score_[parent] >= score_[v])
        break;
      stack_[at] = parent;
      pos_[parent] = at;
      at = parent_at;
    }
    stack_[at] = v;
    pos_[v] = at;
  }

  void bubble_down(Var v) {
    uint32_t at = pos_[v];
    for (;;) {
      uint32_t child_at = 2 * at + 1;
      if (child_at >= stack_.size())
        break;
      Var child = stack_[child_at];
      const uint32_t sibling_at = child_at + 1;
      if (sibling_at < stack_.size() &&
          score_[stack_[sibling_at]] > score_[child]) {
        child_at = sibling_at;
        child = stack_[child_at];
      }
      if (score_[child] <= score_[v])
        break;
      stack_[at] = child;
      pos_[child] = at;
      at = child_at;
    }
    stack_[at] = v;
    pos_[v] = at;
  }

  Kernel *kernel_ = nullptr;
  std::vector<Var> stack_;
  std::vector<uint32_t> pos_;
  std::vector<uint32_t> occurrence_counts_;
  std::vector<double> score_;
  std::vector<uint64_t> payload_;
  std::vector<uint8_t> eligible_;
  std::vector<Var> trace_vars_;
  std::vector<uint32_t> trace_last_pos_;
  std::vector<double> trace_last_score_;
  uint64_t pop_ordinal_ = 0;
  uint64_t pop_hash_ = 1469598103934665603ull;
};

bool rank_bve_reference(const Kernel &k, uint64_t *insts, uint32_t n) {
  if (!k.h)
    return false;
  BveOccurrences occ;
  bve_build_occurrences(k, occ);
  std::vector<std::pair<double, uint64_t>> ranked;
  ranked.reserve(n);
  const uint64_t occurrence_limit = k.bve_occurrence_limit;
  for (uint32_t i = 0; i < n; i++) {
    Lit lit;
    if (!lit_of_instance(k, insts[i], &lit) || var_of(lit) >= k.nvars)
      return false;
    const Var v = var_of(lit);
    const double relevance =
        k.h->stable ? k.h->scores.score[v] : k.h->links[v].stamp;
    const double score = kissat_bve_variable_score(
        relevance, occ.count(make_lit(v, false)),
        occ.count(make_lit(v, true)), occurrence_limit);
    ranked.emplace_back(score, insts[i]);
  }
  std::stable_sort(ranked.begin(), ranked.end(),
                   [](const auto &a, const auto &b) {
                     return a.first < b.first;
                   });
  for (uint32_t i = 0; i < n; i++)
    insts[i] = ranked[i].second;
  return true;
}

} // namespace

void DefaultCandidateOrder::rank(const Kernel &k, uint32_t rule,
                                 uint64_t *insts, uint32_t n) {
  const CandidateOrder arm = arm_of(rule);
  if (arm == CandidateOrder::Native || n < 2)
    return;
  if (arm == CandidateOrder::Reverse) {
    std::reverse(insts, insts + n);
    return;
  }
  if (arm == CandidateOrder::Random) {
    for (uint32_t i = n; i > 1; i--) {
      rng_ += increment_;
      uint64_t z = rng_;
      z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ull;
      z = (z ^ (z >> 27)) * 0x94d049bb133111ebull;
      z ^= z >> 31;
      std::swap(insts[i - 1], insts[z % i]);
    }
    return;
  }
  if (arm == CandidateOrder::Heuristic && !k.h)
    return;
  const std::vector<RuleVTable> &rules = tactix_rules();
  const bool transitive_reference_order =
      arm == CandidateOrder::Heuristic && rule < rules.size() &&
      !std::strcmp(rules[rule].name, "TransitiveReduce");
  const bool bve_reference_order =
      arm == CandidateOrder::Heuristic && rule < rules.size() &&
      !std::strcmp(rules[rule].name, "BVE");
  if (transitive_reference_order && rank_transitive_reference(k, insts, n))
    return;
  if (bve_reference_order && rank_bve_reference(k, insts, n))
    return;
  std::vector<Var> compact_position;
  const bool has_reference_compact_order =
      transitive_reference_order && k.h && !k.compact_import_order.empty();
  if (has_reference_compact_order) {
    compact_position.assign(k.nvars, INVALID_VAR);
    for (Var i = 0; i < k.compact_import_order.size(); i++)
      compact_position[k.compact_import_order[i]] = i;
  }
  scratch_.resize(n);
  for (uint32_t i = 0; i < n; i++)
    scratch_[i] = {order_key(k, arm, insts[i], transitive_reference_order,
                                has_reference_compact_order
                                    ? &k.compact_import_order
                                    : nullptr,
                                has_reference_compact_order ? &compact_position
                                                            : nullptr),
                   insts[i]};
  std::stable_sort(
      scratch_.begin(), scratch_.end(),
      [transitive_reference_order, has_reference_compact_order,
       &compact_position](
          const std::pair<uint64_t, uint64_t> &a,
          const std::pair<uint64_t, uint64_t> &b) {
        if (a.first != b.first)
          return transitive_reference_order ? a.first > b.first
                                            : a.first < b.first;
        if (transitive_reference_order) {
          Lit al, bl;
          if (lit_of_instance(a.second, &al) &&
              lit_of_instance(b.second, &bl)) {
            const Var av = var_of(al), bv = var_of(bl);
            const Var ac = has_reference_compact_order &&
                                   av < compact_position.size() &&
                                   compact_position[av] != INVALID_VAR
                               ? compact_position[av]
                               : av;
            const Var bc = has_reference_compact_order &&
                                   bv < compact_position.size() &&
                                   compact_position[bv] != INVALID_VAR
                               ? compact_position[bv]
                               : bv;
            // The second IDX maps each adjacent pair of compact candidate
            // variables to one activity owner.  Kissat's sort/pop pose consumes
            // the lower compact candidate first inside that equal-key pair;
            // See benchmarks/reports/2026-08-21-tierd-rank27-transitive-reference-order.md.
            if ((ac >> 1) != (bc >> 1))
              return (ac >> 1) < (bc >> 1);
            if (ac != bc)
              return ac < bc;
          }
        }
        return false;
      });
  for (uint32_t i = 0; i < n; i++)
    insts[i] = scratch_[i].second;
}

void DefaultInprocessScheduler::order_candidates(const Kernel &k, SlotEntry &e,
                                     uint64_t *insts, uint32_t n) {
  if (n == 0)
    return;
  e.ord.lists++;
  e.ord.candidates += n;
  if (e.cursor_enabled) {
    uint32_t start = 0;
    while (start < n && instance_key(insts[start]) < e.cursor)
      start++;
    if (start >= n)
      start = 0; // the cursor ran past the set: begin again at the head
    if (start) {
      std::rotate(insts, insts + start, insts + n);
      e.ord.rotated++;
    }
  }
  if (!candidate_order && e.order == CandidateOrder::Native)
    return;
  CandidateOrderPolicy &cp =
      candidate_order ? *candidate_order : default_candidate_order_;
  order_before_.assign(insts, insts + n);
  cp.rank(k, static_cast<uint32_t>(e.rule), insts, n);
  uint64_t moved = 0;
  for (uint32_t i = 0; i < n; i++)
    moved += (order_before_[i] != insts[i]);
  if (moved) {
    e.ord.ranked++;
    e.ord.moved += moved;
  }
}

bool DefaultInprocessScheduler::want_phase(const Kernel &k, SlotGroup g) {
  if (!initialized_)
    return false;
  if (preprocess_only_ && k.stats.conflicts)
    return false;
  if (k.stats.conflicts == 0 && g == SlotGroup::Eliminate)
    return false;
  // Kissat declines both phases on the same conflict as its latest Reduce.
  // The reduction-count Probe watermark below answers a different question:
  // whether any Reduce happened since the preceding Probe round.
  if (last_reduce_conflicts_ == k.stats.conflicts)
    return false;
  SlotClock &c = g == SlotGroup::Probe ? probe_clock : elim_clock;
  // Kissat's two guards deliberately differ.  Probe tests
  // `limit < conflicts` (probe.c:kissat_probing), while Eliminate declines
  // only for `limit > conflicts` (eliminate.c:kissat_eliminating) and is due
  // at equality.  The round-zero probe clock is the explicit startup-
  // preprocessing invitation, not such a deadline, and remains due at zero.
  const bool startup_probe =
      g == SlotGroup::Probe && c.rounds == 0 &&
      k.stats.conflicts == c.next_conflicts;
  const bool before_deadline =
      g == SlotGroup::Probe ? k.stats.conflicts <= c.next_conflicts
                            : k.stats.conflicts < c.next_conflicts;
  if (!startup_probe && before_deadline)
    return false;
  const bool gated =
      slot_watermark_ && c.rounds != 0 &&
      (g == SlotGroup::Probe
           ? k.stats.reductions == c.reductions_mark
           : (k.stats.bve_marks <= c.marks_mark &&
              kernel_logical_root_fixed(k) <= c.fixed_mark &&
              k.subsume_material_count <= c.material_mark));
  if (gated) {
    if (!c.blocked) { // count episodes, not search steps
      c.blocked = true;
      c.blocked_episodes++;
    }
    return false;
  }
  return true;
}

void DefaultInprocessScheduler::update_limit(const Kernel &k, SlotGroup g) {
  const auto &cfg = config();
  SlotClock &c = g == SlotGroup::Probe ? probe_clock : elim_clock;
  const bool split = slot_clocks_split_;
  uint64_t n = split ? c.rounds
                     : std::max(probe_clock.rounds, elim_clock.rounds);
  if (!n)
    n = 1;
  const double lg =
      std::log10(static_cast<double>(n) + cfg.logarithm_offset);
  const double base = split && g == SlotGroup::Probe
                          ? cfg.probe_interval * static_cast<double>(n) * lg
                          : cfg.eliminate_interval * static_cast<double>(n) *
                                lg * lg;
  c.next_conflicts = k.stats.conflicts +
                     scale_inprocessing_delta(k, static_cast<uint64_t>(base),
                                              cfg);
}

void DefaultPolicy::update_reduce_limit(const Kernel &k) {
  DefaultDatabaseControl::update_limit(k, config_.reduction, reduce_sqrt_);
}

bool DefaultPolicy::update_tiers_after_analysis(Kernel &k) {
  // Kissat analyze.c advances this exponential schedule only on the extra
  // conflict created when OTFS restarts 1-UIP analysis. Ordinary propagated
  // conflicts do not test the glue limit. Analyze remains atomic at the rule
  // boundary, so it records the histogram seen at each internal OTFS boundary
  // and the policy consumes those observations here. Reduce has its own
  // independent current-mode refresh.
  bool updated = false;
  if (dynamic_tiers_)
    for (const AnalysisConflictCheckpoint &checkpoint :
         k.analysis_conflict_checkpoints) {
      if (checkpoint.conflicts <= retier_.next_conflicts)
        continue;
      reduce_retier_from_histogram(
          k, checkpoint.mode, checkpoint.used_glue,
          config_.reduction.tier1_default,
          config_.reduction.tier2_default,
          config_.reduction.tier1_relative_permille,
          config_.reduction.tier2_relative_permille);
      k.tier1 = k.tier1_by_mode[checkpoint.mode];
      k.tier2 = std::max(k.tier1, k.tier2_by_mode[checkpoint.mode]);
      if (retier_.interval < config_.reduction.retier_max_interval)
        retier_.interval *= config_.reduction.retier_growth;
      retier_.next_conflicts = checkpoint.conflicts + retier_.interval;
      event_trace_retier(k, checkpoint.mode, checkpoint.used_glue);
      updated = true;
    }
  k.analysis_conflict_checkpoints.clear();
  return updated;
}

FormulaClassification DefaultPolicy::classify_formula_counts(
    uint64_t binaries, uint64_t irredundant_large) const {
  const uint64_t clauses = binaries + irredundant_large;
  FormulaClassification result;
  result.small = clauses <= config_.analysis.small_clause_limit;
  if (result.small)
    return result;

  // This intentionally preserves Kissat's unit mismatch: `kissat_percent`
  // returns 0..100 while `bigbigfraction` is divided by 1000.0. Thus the
  // shipped 990 threshold is 0.99%, not 99%.
  const unsigned __int128 lhs =
      static_cast<unsigned __int128>(100000) * binaries;
  const unsigned __int128 rhs =
      static_cast<unsigned __int128>(
          config_.analysis.big_binary_fraction_permille) *
      clauses;
  result.bigbig = lhs >= rhs;
  return result;
}

FormulaClassification DefaultPolicy::classify_formula(const Kernel &k) const {
  // kissat_classify reads `clauses_binary + clauses_irredundant`; recomputing
  // them here walked every watch list and the whole arena on every call.
#ifndef NDEBUG
  kernel_check_binirr_counts(k);
#endif
  return classify_formula_counts(k.watches.binary_clauses(),
                                 k.live_irredundant_large);
}

void DefaultPolicy::update_formula_classification(Kernel &k) const {
  const FormulaClassification classification = classify_formula(k);
  // `classification.small` is write-only in pinned Kissat. Do not invent a
  // second consumer: only `bigbig` gates ordinary fast binary assignment.
  k.jump_reasons_bigbig = classification.bigbig;
  k.stats.jump_reason_classifications++;
  k.stats.jump_reason_bigbig += classification.bigbig;
}

size_t GlueTieredReduction::victims(const Kernel &k, size_t candidates) {
  static const DefaultStrategyConfig::Reduction defaults;
  const auto &cfg = config_ ? *config_ : defaults;
  if (!ramp)
    return reduce_fractional_victims(candidates, cfg.victim_numerator,
                                     cfg.victim_denominator);
  if (cfg.low_percent >= cfg.high_percent)
    return static_cast<size_t>(static_cast<double>(candidates) *
                               cfg.low_percent / PERCENT_SCALE);
  const double r = static_cast<double>(k.stats.reductions) + 1.0;
  const double percent =
      cfg.high_percent - (cfg.high_percent - cfg.low_percent) /
                             std::log10(r + cfg.logarithm_offset);
  return static_cast<size_t>(static_cast<double>(candidates) * percent /
                             PERCENT_SCALE);
}

Lit DefaultBranching::pick(Kernel &k) { return pick_impl(k, false); }

Lit DefaultBranching::pick_for_restart_reuse(Kernel &k) {
  return pick_impl(k, true);
}

Lit DefaultBranching::pick_impl(Kernel &k, bool restart_reuse) {
  assert(k.unassigned > 0);
  if (!k.warming && randec_enabled && !k.h->stable) {
    const uint64_t c = k.stats.conflicts;
    event_trace_randec_state(k, "pre", randec_remaining, randec_next,
                             randec_sequences, randec_rng);
    // An ordinary kissat_decide increments `solver->level` before this test,
    // so Tactix's pre-frame equivalent admits only level zero.  Restart trail
    // reuse calls kissat_next_decision_variable directly, without incrementing
    // the level, and therefore admits retained levels zero or one.  Keep that
    // call-context distinction explicit; conflating them suppressed due random
    // sequences at level-one restarts and changed the subsequent CDCL path.
    const bool level_allows_start = restart_reuse ? k.level <= 1 : k.level == 0;
    if (!randec_remaining && level_allows_start && c >= randec_next)
      start_random_sequence(k);
    event_trace_randec_state(k, randec_remaining ? "active" : "inactive",
                             randec_remaining, randec_next, randec_sequences,
                             randec_rng);
    if (randec_remaining) {
      for (;;) {
        randec_rng = randec_rng * RANDEC_MULTIPLIER + RANDEC_INCREMENT;
        const uint32_t random = static_cast<uint32_t>(randec_rng >> 32);
        assert(!k.compact_import_order.empty());
        const uint32_t slot = random % k.compact_import_order.size();
        const Var v = k.compact_import_order[slot];
        const bool accepted = k.values[make_lit(v, true)] == 0 &&
                              !kernel_var_retired(k, v);
        event_trace_randec_draw(k, random, slot, v, accepted);
        if (accepted) {
          k.stats.random_decisions++;
          return decide_lit(k, v);
        }
      }
    }
  }
  const Var v = heuristics_next_active_decision_var(k);
  heuristics_mab_note_decision(k);
  return decide_lit(k, v);
}

Lit DefaultBranching::decide_lit(const Kernel &k, Var v) {
  static const DefaultStrategyConfig::Branching defaults;
  const auto &cfg = config_ ? *config_ : defaults;
  int8_t phase = 0;
  if (!k.h->stable && cfg.focused_phase_switch_span &&
      !cfg.focused_phase_pattern.empty()) {
    const uint64_t epoch =
        k.stats.switched / cfg.focused_phase_switch_span;
    if (focused_phase_epoch_ != epoch) {
      focused_phase_epoch_ = epoch;
      focused_phase_ =
          cfg.focused_phase_pattern[epoch % cfg.focused_phase_pattern.size()];
    }
    phase = focused_phase_;
  }
  const int8_t target = k.h->stable ? k.h->target[v] : 0;
  const int8_t saved = k.h->saved[v];
  const Lit result =
      phase ? make_lit(v, phase < 0) : heuristics_decide_lit(k, v);
  event_trace_phase_pick(k, v, target, saved,
                         negated(result) ? -1 : 1);
  return result;
}

void DefaultBranching::start_random_sequence(Kernel &k) {
  if (!randec_enabled || k.h->stable || randec_remaining)
    return;
  static const DefaultStrategyConfig::Branching defaults;
  const auto &cfg = config_ ? *config_ : defaults;
  randec_sequences++;
  const double n = static_cast<double>(randec_sequences);
  const double logn = std::log10(n + cfg.logarithm_offset);
  randec_remaining =
      static_cast<uint64_t>(cfg.random_sequence_length * logn);
  randec_next =
      k.stats.conflicts +
      static_cast<uint64_t>(cfg.random_initial_interval * logn);
  k.stats.random_sequences++;
}

void DefaultPolicy::configure_from_env(const Kernel &) {
  config_ = base_config_;
  // Preserve the pre-existing white-box policy pose surface: callers and
  // focused tests may set these public members before solve().
  config_.analysis.chronological_levels = chrono_levels;
  config_.analysis.reuse_ranked_trail_suffix = chrono_reuse_trail_;
  config_.branching.random_sequences = default_branching_.randec_enabled;
  if (const char *fm = std::getenv("TACTIX_FORCE_MODE")) {
    if (!std::strcmp(fm, "focused"))
      config_.mode.force = 1;
    else if (!std::strcmp(fm, "stable"))
      config_.mode.force = 2;
  }
  if (std::getenv("TACTIX_NO_BUMP_REASONS"))
    config_.analysis.bump_reason_limit = 0;
  if (const char *bl = std::getenv("TACTIX_BUMP_REASONS_LIMIT"))
    config_.analysis.bump_reason_limit =
        static_cast<uint32_t>(std::strtoul(bl, nullptr, 10));
  if (const char *br = std::getenv("TACTIX_BUMP_REASONS_RATE"))
    config_.analysis.bump_reason_rate = std::strtod(br, nullptr);
  const char *cad = std::getenv("TACTIX_REDUCE_CADENCE"); // "sqrt" | "arith"
  const char *rmp = std::getenv("TACTIX_REDUCE_RAMP");    // "1" | "0"
  if (cad)
    config_.reduction.square_root_cadence =
        std::strcmp(cad, "arith") != 0;
  if (rmp)
    config_.reduction.ramp_fraction = rmp[0] == '1';
  else if (cad)
    config_.reduction.ramp_fraction =
        config_.reduction.square_root_cadence;
  if (std::getenv("TACTIX_NO_DYNAMIC_TIERS"))
    config_.reduction.dynamic_tiers = false;
  if (std::getenv("TACTIX_NO_COMPACT"))
    config_.reduction.compact_variables = false;
  if (const char *ll = std::getenv("TACTIX_LUCKY_LATE"))
    config_.rephase.late_lucky = std::strtoul(ll, nullptr, 10) != 0;
  if (std::getenv("TACTIX_REPHASE_BOTH_MODES"))
    config_.rephase.stable_only = false;
  if (const char *ro = std::getenv("TACTIX_REORDER"))
    config_.reorder.mode =
        static_cast<uint32_t>(std::strtoul(ro, nullptr, 10));
  if (const char *cl = std::getenv("TACTIX_CHRONO_LEVELS")) {
    const long n = std::strtol(cl, nullptr, 10);
    if (n >= 0)
      config_.analysis.chronological_levels = static_cast<uint32_t>(n);
  }
  if (const char *cr = std::getenv("TACTIX_CHRONO_REUSE"))
    config_.analysis.reuse_ranked_trail_suffix =
        std::strtoul(cr, nullptr, 10) != 0;
  if (const char *value = std::getenv("TACTIX_CONFLICT_REUSE"))
    config_.analysis.conflict_reuse = *value != '0';
  if (const char *value = std::getenv("TACTIX_JUMP_REASONS"))
    config_.analysis.jump_reasons = *value != '0';
  if (const char *value = std::getenv("TACTIX_SHRINK_GLUE"))
    config_.analysis.shrink_glue_promote = *value != '0';
  if (std::getenv("TACTIX_NO_EXT_REASON_BUMP"))
    config_.analysis.bump_extension_reasons = false;
  if (const char *value = std::getenv("TACTIX_EAGER_SUBSUME"))
    config_.analysis.eager_subsume = std::min<uint32_t>(
        static_cast<uint32_t>(std::strtoul(value, nullptr, 10)),
        strategy::AnalyzeParameters::EAGER_SUBSUME_CAPACITY);
  if (const char *rd = std::getenv("TACTIX_RANDEC"))
    config_.branching.random_sequences = *rd != '0';
  if (const char *value = std::getenv("TACTIX_MAB")) {
    config_.branching.mab = *value != '0';
    config_.branching.mab_after_search_stagnation = false;
  }
  if (const char *wp = std::getenv("TACTIX_WALK_PERMILLE"))
    config_.rephase.walk_permille = std::strtoull(wp, nullptr, 10);
  if (const char *bc = std::getenv("TACTIX_BVE_RAMP_MAX"))
    config_.inprocess.bve_default_ceiling =
        static_cast<uint32_t>(std::strtoul(bc, nullptr, 10));
  if (const char *dt = std::getenv("TACTIX_BVE_DEF_TICKS"))
    config_.inprocess.bve_definition_budget = std::strtoull(dt, nullptr, 10);
  if (const char *dc = std::getenv("TACTIX_BVE_DEF_CORES"))
    config_.inprocess.bve_definition_cores = std::clamp<uint32_t>(
        static_cast<uint32_t>(std::strtoul(dc, nullptr, 10)), 1, 100);
  if (const char *dm = std::getenv("TACTIX_BVE_DEF_CORE_MULTIPLIER"))
    config_.inprocess.bve_definition_core_budget_multiplier =
        static_cast<uint32_t>(std::strtoul(dm, nullptr, 10));
  if (const char *value = std::getenv("TACTIX_BVE_BACKWARD"))
    config_.inprocess.bve_backward = *value != '0';
  if (const char *value = std::getenv("TACTIX_BCE_OCC_LIMIT"))
    config_.inprocess.bce_parameters.occurrence_limit =
        static_cast<uint32_t>(std::strtoul(value, nullptr, 10));
  if (const char *value = std::getenv("TACTIX_TERNARY_OCC_LIMIT"))
    config_.inprocess.ternary_parameters.occurrence_limit =
        static_cast<uint32_t>(std::strtoul(value, nullptr, 10));
  if (const char *value = std::getenv("TACTIX_TERNARY_MAXADD"))
    config_.inprocess.ternary_parameters.maximum_add_percent =
        static_cast<uint32_t>(std::strtoul(value, nullptr, 10));
  if (const char *value = std::getenv("TACTIX_FACTOR_SIZE"))
    config_.inprocess.factor_parameters.maximum_clause_size =
        static_cast<uint32_t>(std::strtoul(value, nullptr, 10));
  if (const char *value = std::getenv("TACTIX_FACTOR_BOUND"))
    config_.inprocess.factor_parameters.growth_bound =
        static_cast<uint32_t>(std::strtoul(value, nullptr, 10));
  if (const char *value = std::getenv("TACTIX_FACTOR_DEMOTE"))
    config_.inprocess.factor_parameters.demote_fresh = *value != '0';
  if (const char *value = std::getenv("TACTIX_FACTOR_CAND_ROUNDS"))
    config_.inprocess.factor_parameters.candidate_rounds =
        static_cast<uint32_t>(std::strtoul(value, nullptr, 10));
  if (const char *value = std::getenv("TACTIX_V4_EARLY_EXIT"))
    config_.inprocess.transitive_parameters.early_exit = *value != '0';
  if (const char *value = std::getenv("TACTIX_TRANSITIVE_LIVE_METER"))
    config_.inprocess.transitive_parameters.live_meter = *value != '0';
  if (const char *value = std::getenv("TACTIX_V4_METER"))
    config_.inprocess.transitive_parameters.checked_budget_meter =
        !std::strcmp(value, "checked");
  if (const char *value = std::getenv("TACTIX_VIVIFY_REUSE"))
    config_.inprocess.vivify_parameters.reuse = *value != '0';
  if (const char *value = std::getenv("TACTIX_VIVIFY_FLUSH"))
    config_.inprocess.vivify_parameters.flush = *value != '0';
  if (std::getenv("TACTIX_SUBST_DEMOTE"))
    config_.inprocess.substitute_parameters.demote_substituted = true;
  if (std::getenv("TACTIX_NO_BVE"))
    config_.inprocess.bve_enabled = false;
  if (std::getenv("TACTIX_NO_FACTOR"))
    config_.inprocess.factor_enabled = false;
  if (std::getenv("TACTIX_NO_SWEEP"))
    config_.inprocess.sweep_enabled = false;
  if (const char *hold = std::getenv("TACTIX_SUBSUME_HOLD"))
    config_.inprocess.hold_subsume_until_eliminate = *hold != '0';
  if (const char *touch = std::getenv("TACTIX_TOUCH_MARKS"))
    config_.inprocess.touch_filter = *touch != '0';
  if (const char *redundant = std::getenv("TACTIX_TOUCH_REDUNDANT"))
    config_.inprocess.likely_kept_redundant = *redundant != '0';
  const auto sweep_u32 = [](const char *name, uint32_t &slot) {
    if (const char *s = std::getenv(name))
      slot = static_cast<uint32_t>(std::strtoul(s, nullptr, 10));
  };
  const auto sweep_bool = [](const char *name, bool &slot) {
    if (const char *s = std::getenv(name))
      slot = std::strtoul(s, nullptr, 10) != 0;
  };
  sweep_u32("TACTIX_SWEEP_DEPTH",
            config_.inprocess.sweep_parameters.max_depth);
  sweep_u32("TACTIX_SWEEP_VARS",
            config_.inprocess.sweep_parameters.max_env_vars);
  sweep_u32("TACTIX_SWEEP_CLAUSES",
            config_.inprocess.sweep_parameters.max_env_clauses);
  sweep_u32("TACTIX_SWEEP_CANDIDATES",
            config_.inprocess.sweep_parameters.max_candidates);
  sweep_u32("TACTIX_SWEEP_FLIP_ROUNDS",
            config_.inprocess.sweep_parameters.flip_rounds);
  sweep_u32("TACTIX_SWEEP_SEEDS",
            config_.inprocess.sweep_parameters.max_seeds);
  if (const char *s = std::getenv("TACTIX_SWEEP_TICKS"))
    config_.inprocess.sweep_parameters.env_ticks =
        std::strtoull(s, nullptr, 10);
  if (const char *s = std::getenv("TACTIX_SWEEP_ROUND_TICKS"))
    config_.inprocess.sweep_parameters.round_ticks =
        std::strtoull(s, nullptr, 10);
  sweep_bool("TACTIX_SWEEP_STRIP",
             config_.inprocess.sweep_parameters.strip_false);
  sweep_bool("TACTIX_SWEEP_CLOSURE",
             config_.inprocess.sweep_parameters.measure_closure);
  sweep_bool("TACTIX_SWEEP_PARTITION",
             config_.inprocess.sweep_parameters.full_partition);
  sweep_bool("TACTIX_SWEEP_RESUME",
             config_.inprocess.sweep_parameters.resume);
  sweep_bool("TACTIX_SWEEP_FORCE_GENERAL",
             config_.inprocess.sweep_parameters.force_general_proof);
  sweep_bool("TACTIX_ARENA_ORDER",
             config_.inprocess.cadical_arena_ordering_enabled);

  if (std::getenv("TACTIX_NO_CLOSURE_DELAY"))
    config_.inprocess.closure_delay = false;
  if (const char *value = std::getenv("TACTIX_FACTOR_INIT_TICKS"))
    config_.inprocess.factor_initial_ticks = std::strtoull(value, nullptr, 10);
  if (std::getenv("TACTIX_PREPROCESS_ONLY"))
    config_.inprocess.preprocess_only = true;
  if (const char *value = std::getenv("TACTIX_PREPROCESS_FOLLOWUPS"))
    config_.inprocess.preprocess_followups =
        std::strtoul(value, nullptr, 10) != 0;
  if (const char *value = std::getenv("TACTIX_SLOT_CLOCKS"))
    config_.inprocess.split_clocks = std::strtoul(value, nullptr, 10) != 1;
  if (const char *value = std::getenv("TACTIX_SLOT_WATERMARK"))
    config_.inprocess.watermarks = std::strtoul(value, nullptr, 10) != 0;
  if (const char *value = std::getenv("TACTIX_FACTOR_COUPLE"))
    config_.inprocess.couple_factor_bound =
        std::strtoul(value, nullptr, 10) != 0;

  const auto list_has = [](const char *list, const std::string &name) {
    if (!list)
      return false;
    const size_t n = name.size();
    for (const char *p = list; (p = std::strstr(p, name.c_str())); p += n)
      if ((p == list || p[-1] == ',') && (p[n] == '\0' || p[n] == ','))
        return true;
    return false;
  };
  const auto mapped_u32 = [](const char *map, const std::string &name,
                             uint32_t &value) {
    if (!map)
      return false;
    const size_t n = name.size();
    for (const char *p = map; (p = std::strstr(p, name.c_str())); p += n)
      if ((p == map || p[-1] == ',') && p[n] == ':') {
        value = static_cast<uint32_t>(std::strtoul(p + n + 1, nullptr, 10));
        return true;
      }
    return false;
  };
  const char *enabled = std::getenv("TACTIX_SLOT_ENABLE");
  const char *disabled = std::getenv("TACTIX_SLOT_DISABLE");
  const char *permille = std::getenv("TACTIX_SLOT_PERMILLE");
  const char *maximum = std::getenv("TACTIX_SLOT_MAX_APPLIES");
  for (strategy::InprocessStep &step : config_.inprocess.program) {
    if (list_has(enabled, step.rule)) {
      step.enabled = true;
      if (step.rule == "BVE")
        config_.inprocess.bve_enabled = true;
      else if (step.rule == "Vivify")
        config_.inprocess.vivify_enabled = true;
      else if (step.rule == "Factor")
        config_.inprocess.factor_enabled = true;
      else if (step.rule == "Sweep")
        config_.inprocess.sweep_enabled = true;
    }
    if (list_has(disabled, step.rule))
      step.enabled = false;
    uint32_t value = 0;
    if (mapped_u32(permille, step.rule, value) &&
        effort_spec(step.rule.c_str()))
      step.effort_permille = value;
    if (mapped_u32(maximum, step.rule, value))
      step.max_applications = value;

    char knob[96];
    const auto knob_name = [&knob](const char *prefix,
                                   const std::string &name) {
      size_t p = 0;
      for (const char *s = prefix; *s && p + 1 < sizeof knob; ++s)
        knob[p++] = *s;
      for (const char c : name)
        if (p + 1 < sizeof knob)
          knob[p++] = static_cast<char>(
              std::toupper(static_cast<unsigned char>(c)));
      knob[p] = '\0';
    };
    knob_name("TACTIX_CURSOR_", step.rule);
    if (const char *cursor = std::getenv(knob))
      step.cursor_enabled = std::strtoul(cursor, nullptr, 10) != 0;
    knob_name("TACTIX_ORDER_", step.rule);
    if (const char *order = std::getenv(knob)) {
      CandidateOrder parsed;
      if (!parse_candidate_order(order, &parsed)) {
        std::fprintf(stderr, "c ERROR: %s: unknown candidate-order arm\n",
                     knob);
        std::abort();
      }
      step.candidate_order = parsed;
    }
  }

  std::string config_error;
  if (!config_.valid(&config_error)) {
    std::fprintf(stderr, "c ERROR: invalid strategy configuration: %s\n",
                 config_error.c_str());
    std::abort();
  }

  force_mode_ = config_.mode.force;
  bump_reasons_limit_ = config_.analysis.bump_reason_limit;
  bump_reasons_rate_ = config_.analysis.bump_reason_rate;
  reduce_sqrt_ = config_.reduction.square_root_cadence;
  dynamic_tiers_ = config_.reduction.dynamic_tiers;
  compact_ = config_.reduction.compact_variables;
  lucky_late_ = config_.rephase.late_lucky;
  chrono_levels = config_.analysis.chronological_levels;
  chrono_reuse_trail_ = config_.analysis.reuse_ranked_trail_suffix;
  default_branching_.set_config(&config_.branching);
  default_branching_.randec_enabled = config_.branching.random_sequences;
  default_reduction_.set_config(&config_.reduction);
  default_reduction_.ramp = config_.reduction.ramp_fraction;
  inprocess_.set_config(&config_.inprocess);
  inprocess_.configure();
}

void DefaultInprocessScheduler::configure() {
  const auto &cfg = config();
  closure_delay_ = cfg.closure_delay;
  slot_clocks_split_ = cfg.split_clocks;
  slot_watermark_ = cfg.watermarks;
  couple_factor_bound_ = cfg.couple_factor_bound;
  factor_init_ticks_ = cfg.factor_initial_ticks;
  preprocess_followups_ = cfg.preprocess_followups;
  preprocess_only_ = cfg.preprocess_only;
}

void DefaultInprocessScheduler::reset(const Kernel &) {
  initialized_ = false;
  search_limits_initialized_ = false;
  last_reduce_conflicts_ = UINT64_MAX;
  probe_clock = elim_clock = {};
  // Kissat initializes both `last.ticks.probe` and
  // `last.ticks.eliminate` to zero.  Input-unit closure already uses the
  // ordinary search propagator and contributes to `search_ticks` before
  // solve entry, so rebasing these clocks here silently removes real reference
  // work from the first search-time Probe and Eliminate doses.  Initial
  // preprocessing deliberately does not advance the Probe anchor; completed
  // search-time phases update their own clock in `run_phase` below.
  bve_rounds_run_ = 0;
  factor_large_formula_ = false;
  factor_marked_watermark_ = 0;
  bve_level_ = 0;
  bve_level_idx_ = 0;
  initial_fast_elimination_active_ = false;
  initial_fast_elimination_discovery_ticks_ = 0;
  initial_fast_elimination_budget_exhausted_ = false;
  initial_fast_elimination_attempted_.clear();
  structured_root_consumed_ = false;
  structured_root = {};
  default_candidate_order_.reset(config().candidate_order_seed);
  for (SlotEntry &e : entries) {
    e.limit = 0;
    e.applies = 0;
    e.doses = 0;
    e.cursor = 0;
    e.tm = {};
    e.ord = {};
    e.binaries_mark = 0;
    e.root_fixed_mark = 0;
    e.arena_mark = 0;
    e.delay_count = 0;
    e.delay_current = 0;
  }
  forward_pair_limit_ = 0;
}

void DefaultInprocessScheduler::build(Kernel &k) {
  configure();
  if (entries.empty()) {
    const std::vector<RuleVTable> &rules = tactix_rules();
    const auto add_entry = [&](int i,
                               const strategy::InprocessStep *planned = nullptr) {
      {
        const char *nm = rules[i].name;
        // DefaultPolicy's Phase-4 reference is original Kissat.  Keep the
        // CaDiCaL-derived proof rules registered and explicitly poseable, but
        // do not splice them into Kissat's shipped probe/eliminate pipelines:
        // doing so changes the formula before the next common control choice.
        // Sweep remains in the reference pipeline and therefore ships on.
        const bool non_kissat_pipeline =
            !std::strcmp(nm, "HyperBinaryRes") ||
            !std::strcmp(nm, "Probe") ||
            !std::strcmp(nm, "HyperTernaryRes") ||
            !std::strcmp(nm, "Instantiate") || !std::strcmp(nm, "BCE") ||
            !std::strcmp(nm, "CCE");
        // Strengthen is the one fused Kissat forward pass: it subsumes and
        // self-subsumes under the shared allowance.  Keep standalone C1 fully
        // registered/poseable, but do not run the duplicated decomposition in
        // the reference-shaped default strategy.
        const bool duplicated_decomposition =
            !std::strcmp(nm, "SubsumeForward");
        bool on = planned ? planned->enabled
                          : !non_kissat_pipeline && !duplicated_decomposition;
        on = on &&
             !(!config().bve_enabled && !std::strcmp(nm, "BVE")) &&
             !(!config().vivify_enabled && !std::strcmp(nm, "Vivify")) &&
             !(!config().factor_enabled && !std::strcmp(nm, "Factor")) &&
             !(!config().sweep_enabled && !std::strcmp(nm, "Sweep"));
        SlotEntry e;
        e.step_id = planned ? planned->id : entries.size() + 1;
        e.defer_preprocess = !std::strcmp(nm, "BVE");
        e.rule = i;
        // Kissat transitive.c activity-sorts its variable stack and consumes
        // it from the back.  The dedicated comparator path above also retains
        // its exact IDX-on-variable reference behavior.
        if (!std::strcmp(nm, "TransitiveReduce") || !std::strcmp(nm, "BVE"))
          e.order = CandidateOrder::Heuristic;
        e.enabled = on;
        if (planned) {
          e.group = slot_group(planned->phase);
          e.preprocess = planned->preprocessing;
          e.followup = followup_kind(planned->followup);
          e.parameters = planned->parameters;
          e.max_applies = planned->max_applications;
          if (planned->candidate_order)
            e.order = *planned->candidate_order;
        } else {
          size_t norder = 0;
          const SlotOrderRow *order = default_slot_order(&norder);
          for (size_t o = 0; o < norder; o++)
            if (!std::strcmp(order[o].name, nm)) {
              e.group = order[o].group;
              break;
            }
        }
        // No production entry receives the generic closure watermark merely
        // because it is unmetered.  In particular, Kissat calls Congruence on
        // every admitted Probe phase subject only to its named productivity
        // delay; it has no binary/root "new material" admission gate.
        e.closure = false;
        if (const EffortSpec *s = effort_spec(nm)) {
          e.closure = s->closure;
          e.permille = config().*(s->permille);
          e.meter = s->meter;
          e.tick_counter = s->tick_counter;
          e.dosed = s->dosed;
          e.budget_aware = s->budget_aware;
          if (planned && planned->effort_permille)
            e.permille = *planned->effort_permille;
        }
        if (e.dosed)
          e.cursor_enabled = std::strcmp(nm, "BVE") != 0;
        if (planned && planned->cursor_enabled)
          e.cursor_enabled = *planned->cursor_enabled;
        entries.push_back(e);
      }
    };
    std::vector<bool> placed(rules.size(), false);
    std::string program_error;
    if (!strategy::validate_inprocess_program(config().program,
                                              &program_error)) {
      std::fprintf(stderr, "c ERROR: invalid inprocess program: %s\n",
                   program_error.c_str());
      std::abort();
    }
    // Resolve and validate every occurrence before constructing any runtime
    // entry, so a bad typed program cannot leave a usable prefix behind.
    for (const strategy::InprocessStep &step : config().program) {
      const int id = tactix_rule_id(step.rule.c_str());
      if (id < 0 || rules[id].tier != RuleTier::Inprocess) {
        std::fprintf(stderr,
                     "c ERROR: inprocess program rule '%s' is not a "
                     "registered inprocessing action\n",
                     step.rule.c_str());
        std::abort();
      }
      const EffortSpec *spec = effort_spec(step.rule.c_str());
      if (step.effort_permille && !spec) {
        std::fprintf(stderr,
                     "c ERROR: inprocess step '%s' has an effort share but "
                     "the action has no scheduler effort meter\n",
                     step.rule.c_str());
        std::abort();
      }
      if ((step.cursor_enabled || step.candidate_order) &&
          (!spec || !spec->dosed)) {
        std::fprintf(stderr,
                     "c ERROR: inprocess step '%s' configures candidate "
                     "traversal but the action runs as a batch\n",
                     step.rule.c_str());
        std::abort();
      }
    }
    for (const strategy::InprocessStep &step : config().program) {
      const int id = tactix_rule_id(step.rule.c_str());
      placed[id] = true;
      add_entry(id, &step);
    }
    if (config().append_unlisted_rules)
      for (int i = 0; i < static_cast<int>(rules.size()); i++)
        if (rules[i].tier == RuleTier::Inprocess && !placed[i] &&
            std::strcmp(rules[i].name, "SubstitutionRedundancy") &&
            std::strcmp(rules[i].name, "Condition"))
          add_entry(i);
    default_candidate_order_.arms.assign(rules.size(),
                                         CandidateOrder::Native);
    for (const SlotEntry &se : entries)
      default_candidate_order_.arms[se.rule] = se.order;
  }
  // `eliminateocclim` is a Kissat option, so `variable_score` reads the same
  // bound wherever it runs, not only inside an elimination round.  Install it
  // when the scheduler attaches to the kernel: the candidate order is a public
  // action surface and may be consulted before the first phase, and the
  // kernel's unlimited default squares to a magnitude that cancels every
  // score difference in `kissat_bve_variable_score`.
  k.bve_occurrence_limit = config().bve_occurrence_limit;
  k.congruence_parameters = config().congruence_parameters;
  k.instantiate_parameters = config().instantiate_parameters;
  k.backbone_parameters = config().backbone_parameters;
  k.bce_occ_limit = config().bce_parameters.occurrence_limit;
  k.ternary_occ_limit = config().ternary_parameters.occurrence_limit;
  k.ternary_max_add_percent =
      config().ternary_parameters.maximum_add_percent;
  k.factor_size = config().factor_parameters.maximum_clause_size;
  k.factor_bound = config().factor_parameters.growth_bound;
  k.factor_cand_rounds = config().factor_parameters.candidate_rounds;
  k.factor_composite = config().factor_parameters.composite;
  k.factor_demote_fresh = config().factor_parameters.demote_fresh;
  k.transitive_early_exit = config().transitive_parameters.early_exit;
  k.transitive_live_meter = config().transitive_parameters.live_meter;
  k.transitive_budget_checked =
      config().transitive_parameters.checked_budget_meter;
  k.subst_demote = config().substitute_parameters.demote_substituted;
  k.vivify_scope = config().vivify_parameters.scope;
  k.vivify_reuse = config().vivify_parameters.reuse;
  k.vivify_flush = config().vivify_parameters.flush;
  k.vivify_irredundant_sort_ratio =
      config().vivify_parameters.irredundant_sort_ratio;
  k.touch_filter = config().touch_filter;
  k.touch_redundant = config().likely_kept_redundant;
  k.bve_clause_size_limit = config().bve_clause_size_limit;
  k.bve_resolvent_count_limit = UINT32_MAX;
  k.bve_xor_arity_limit = config().bve_xor_arity_limit;
  k.bve_resolvent_size_limit = config().bve_resolvent_size_limit;
  k.bve_backward_occurrence_limit =
      config().bve_backward_occurrence_limit;
  k.bve_definition_budget = config().bve_definition_budget;
  k.bve_definition_cores = config().bve_definition_cores;
  k.bve_definition_core_budget_multiplier =
      config().bve_definition_core_budget_multiplier;
  k.bve_backward = config().bve_backward;
  if (!initialized_) {
    initialized_ = true;
    // Probe is due immediately because it owns initial preprocessing.
    // Eliminate is not part of that pipeline.  Kissat initializes its first
    // Eliminate deadline in start_search, after preprocessing has established
    // the formula population used by kissat_scale_delta.  Keep it unreachable
    // until initialize_search_limits observes that same lifecycle boundary.
    probe_clock.next_conflicts = k.stats.conflicts;
    elim_clock.next_conflicts = UINT64_MAX;
  }
}

void DefaultInprocessScheduler::initialize_search_limits(const Kernel &k) {
  if (search_limits_initialized_)
    return;
  // kimits.c:kissat_init_limits runs from search.c:start_search, after
  // preprocessing, late Lucky, and classification.  rounds==0 makes the
  // existing NLOG2N updater use n=1, i.e. eliminateinit=500 with the exact
  // post-preprocessing BINIRR_CLAUSES scaling population.
  update_limit(k, SlotGroup::Eliminate);
  search_limits_initialized_ = true;
}

int DefaultPolicy::solve(Kernel &k, volatile sig_atomic_t *stop) {
  KernelStopPublisher stop_published(k, stop);
  configure_from_env(k);
  KernelAnalysisConflictPublisher analysis_conflict_published(
      k,
      [](Kernel &kernel, void *state) {
        DefaultPolicy *policy = static_cast<DefaultPolicy *>(state);
        if (policy->strategy_config().branching.mab)
          heuristics_mab_note_conflict(kernel);
        policy->update_tiers_after_analysis(kernel);
      },
      this);
  KernelAnalysisLearnedPublisher analysis_learned_published(
      k,
      config_.branching.mab
          ? +[](Kernel &kernel, void *) {
              heuristics_chb_mark_analyzed(kernel);
            }
          : nullptr,
      this);
  // Kissat creation order is production state.  CaDiCaL's VMTF/phase arena
  // permutation remains available only through the explicit typed/environment
  // diagnostic arm; no formula classifier or benchmark selector controls it.
  ArenaOrdering *arena_ordering =
      config_.inprocess.cadical_arena_ordering_enabled
          ? inprocess_.cadical_arena_ordering()
          : nullptr;
  ScopedArenaOrdering arena_ordered(k, arena_ordering);
  if (k.inconsistent)
    return 20;
  // Solve-entry root normalization must retire an externally recorded conflict,
  // not only discard its decision trail. S1 Restart owns that transition
  // (docs/calculus.md §4); startup inprocessing requires !conflict_valid.
  if (k.level || k.conflict_valid) {
    if (restart_backtrack_to(k, 0) == ApplyResult::Unsat)
      return 20;
  }
  std::optional<ScopedHeuristics> owned_h;
  solves++;
  k.conflict_reuse_chrono_levels = chrono_levels;
  k.analyze_parameters.minimize_depth_limit =
      config_.analysis.minimize_depth_limit;
  k.conflict_reuse = config_.analysis.conflict_reuse;
  k.jump_reasons = config_.analysis.jump_reasons;
  k.shrink_glue_promote = config_.analysis.shrink_glue_promote;
  k.no_ext_reason_bump = !config_.analysis.bump_extension_reasons;
  k.eager_subsume = config_.analysis.eager_subsume;
  k.reorder_maximum_clause_size =
      config_.reorder.parameters.maximum_clause_size;
  k.reorder_clause_decay_milli =
      config_.reorder.parameters.clause_decay_milli;
  k.reorder_binary_weight_milli =
      config_.reorder.parameters.binary_weight_milli;
  k.reorder_balanced_polarity_milli =
      config_.reorder.parameters.balanced_polarity_milli;
  k.parity_model_maximum_variables =
      config_.parity_model.parameters.maximum_variables;
  k.parity_model_maximum_groups = config_.parity_model.parameters.maximum_groups;
  k.parity_model_maximum_constraints =
      config_.parity_model.parameters.maximum_constraints;
  k.parity_model_minimum_group_clauses =
      config_.parity_model.parameters.minimum_group_clauses;
  k.parity_model_minimum_equations =
      config_.parity_model.parameters.minimum_equations;
  k.parity_model_maximum_free_variables =
      config_.parity_model.parameters.maximum_free_variables;
  k.parity_model_candidate_budget =
      config_.parity_model.parameters.candidate_budget;
  k.parity_refutation_maximum_variables =
      config_.parity_model.parameters.refutation_maximum_variables;
  k.parity_refutation_maximum_groups =
      config_.parity_model.parameters.refutation_maximum_groups;
  k.parity_refutation_maximum_constraints =
      config_.parity_model.parameters.refutation_maximum_constraints;
  k.parity_refutation_maximum_arity =
      config_.parity_model.parameters.refutation_maximum_arity;
  k.parity_refutation_probe_constraints =
      config_.parity_model.parameters.refutation_probe_constraints;
  k.parity_refutation_minimum_probe_repeats =
      config_.parity_model.parameters.refutation_minimum_probe_repeats;
  k.parity_refutation_maximum_proof_additions =
      config_.parity_model.parameters.refutation_maximum_proof_additions;
  k.onehot_model_maximum_variables =
      config_.onehot_model.parameters.maximum_variables;
  k.onehot_model_maximum_domains =
      config_.onehot_model.parameters.maximum_domains;
  k.onehot_model_maximum_constraints =
      config_.onehot_model.parameters.maximum_constraints;
  k.onehot_model_maximum_equation_arity =
      config_.onehot_model.parameters.maximum_equation_arity;
  k.onehot_model_minimum_domains =
      config_.onehot_model.parameters.minimum_domains;
  k.onehot_model_minimum_equations =
      config_.onehot_model.parameters.minimum_equations;
  k.onehot_model_maximum_free_domains =
      config_.onehot_model.parameters.maximum_free_domains;
  k.onehot_model_candidate_budget =
      config_.onehot_model.parameters.candidate_budget;
  k.exact_one_refutation_maximum_variables =
      config_.onehot_model.parameters.refutation_maximum_variables;
  k.exact_one_refutation_maximum_groups =
      config_.onehot_model.parameters.refutation_maximum_groups;
  k.exact_one_refutation_maximum_constraints =
      config_.onehot_model.parameters.refutation_maximum_constraints;
  k.exact_one_refutation_maximum_arity =
      config_.onehot_model.parameters.refutation_maximum_arity;
  k.exact_one_refutation_maximum_proof_additions =
      config_.onehot_model.parameters.refutation_maximum_proof_additions;
  k.balanced_signature_model_parameters =
      config_.balanced_signature_model.parameters;
  k.fermat_model_parameters = config_.fermat_model.parameters;
  k.lookup_circuit_model_parameters =
      config_.lookup_circuit_model.parameters;
  k.simon_model_parameters = config_.simon_model.parameters;
  k.stconn_proof_parameters = config_.stconn_proof.parameters;
  k.signed_cardinality_proof_parameters =
      config_.signed_cardinality_proof.parameters;
  k.exact_cover_model_parameters = config_.exact_cover_model.parameters;
  k.independent_set_model_parameters =
      config_.independent_set_model.parameters;
  k.reduce_victim_numerator = config_.reduction.victim_numerator;
  k.reduce_victim_denominator = config_.reduction.victim_denominator;
  k.reduce_protect_tiers = config_.reduction.protect_tiers;
  k.reduce_compact_collection =
      config_.reduction.canonical_compact_collection;
  k.reduce_bookkeeping = config_.reduction.bookkeeping;
  k.walk_even_break_base_milli =
      config_.rephase.walk_even_break_base_milli;
  k.walk_score_curve = config_.rephase.walk_score_curve;
  if (reset_schedule_per_solve) {
    for (uint32_t mode = 0; mode != 2; ++mode) {
      k.tier1_by_mode[mode] = config_.reduction.tier1_default;
      k.tier2_by_mode[mode] = std::max(config_.reduction.tier1_default,
                                       config_.reduction.tier2_default);
    }
    pose_vivify_tiers(k, config_.inprocess);
    reset_schedule(k);
  }
  inprocess_.build(k);
  EventTrace event_trace;
  event_trace.open_from_env(k);
  // Paired search-time deletion counters on every analysis_end row: the
  // clause a solver deletes between two boundaries is invisible in the
  // journals, and kissat's rows carry the same three statistics.
#ifdef TACTIX_ENABLE_EVENT_TRACE
  const auto event_trace_analysis_deletions = [&](const Kernel &kk) {
    event_trace.detail(kk, "analysis_eager_subsumed",
                       static_cast<int64_t>(kk.stats.eager_subsumed));
    event_trace.detail(kk, "analysis_otfs_strengthened",
                       static_cast<int64_t>(kk.stats.otfs_strengthened));
    event_trace.detail(kk, "analysis_otfs_subsumed",
                       static_cast<int64_t>(kk.stats.otfs_subsumed));
  };
#else
  const auto event_trace_analysis_deletions = [](const Kernel &) {};
#endif
  event_trace.macro(k, "startup_begin");
  auto finish = [&](int verdict) {
    char payload[16];
    std::snprintf(payload, sizeof payload, "%d", verdict);
    event_trace.macro(k, "terminate", payload);
    event_trace.close();
    return verdict;
  };

  std::optional<PreSearchTickScope> presearch_ticks;
  presearch_ticks.emplace(k);

  // The references expose two distinct Lucky opportunities around initial
  // preprocessing. Keep them out of the CDCL loop so neither can repeat after
  // a later inprocessing phase.
  if (config_.parity_model.enabled && startup_parity_guard(k)) {
    const ApplyResult pb = default_direct_rule(
        k, "Lucky", "startup-parity-pb", [&] { return startup_parity_apply(k); });
    if (pb == ApplyResult::Unsat)
      return finish(20);
  }
  if (count_preservation_guard(k)) {
    const ApplyResult counting = default_direct_rule(
        k, "Lucky", "startup-count-pb", [&] { return count_preservation_apply(k); });
    if (counting == ApplyResult::Unsat)
      return finish(20);
  }
  k.close_startup_certificate();
  if (k.proof && k.proof->startup_pb_available())
    k.proof->commit_dsr();
  ApplyResult startup = default_propagate(k, "startup");
  if (startup != ApplyResult::Ok)
    return finish(20); // startup is at root: a conflict is a refutation
  if (config_.signed_cardinality_proof.enabled &&
      signed_cardinality_proof_guard(k)) {
    event_trace.macro(k, "signed_cardinality_proof_begin");
    const ApplyResult counting = default_direct_rule(
        k, "Lucky", "signed-cardinality-proof",
        [&] { return signed_cardinality_proof_apply(k); });
    if (counting == ApplyResult::Unsat) {
      event_trace.macro(k, "signed_cardinality_proof_end", "unsat");
      return finish(20);
    }
    event_trace.macro(k, "signed_cardinality_proof_end", "unknown");
  }
  // Signed at-most-one block exact cover (the sgen owner): exact recognition
  // on the live clause set, then the owner's deterministic DFS and dosed
  // randomized restarts; a completed cover is validated as a total model.
  if (config_.exact_cover_model.enabled && exact_cover_model_guard(k)) {
    event_trace.macro(k, "exact_cover_model_begin");
    const ApplyResult cover = default_direct_rule(
        k, "Lucky", "exact-cover-model",
        [&] { return exact_cover_model_apply(k); });
    if (cover == ApplyResult::Sat) {
      event_trace.macro(k, "exact_cover_model_end", "sat");
      return finish(10);
    }
    event_trace.macro(k, "exact_cover_model_end", "unknown");
  }
  // Independent set under a layered exact-count encoding: the owner's count
  // equation recognizes the shape; a generic greedy + swap search, propagation
  // completion and full validation construct the model.
  if (config_.independent_set_model.enabled &&
      independent_set_model_guard(k)) {
    event_trace.macro(k, "independent_set_model_begin");
    const ApplyResult independent = default_direct_rule(
        k, "Lucky", "independent-set-model",
        [&] { return independent_set_model_apply(k); });
    if (independent == ApplyResult::Sat) {
      event_trace.macro(k, "independent_set_model_end", "sat");
      return finish(10);
    }
    event_trace.macro(k, "independent_set_model_end", "unknown");
  }
  // Arithmetic-circuit construction consumes only the parser's bounded raw
  // structural summary, then independently validates any completed model.
  if (config_.fermat_model.enabled && fermat_model_guard(k)) {
    event_trace.macro(k, "fermat_model_begin");
    const ApplyResult fermat = default_direct_rule(
        k, "Lucky", "fermat-model", [&] { return fermat_model_apply(k); });
    if (fermat == ApplyResult::Sat) {
      event_trace.macro(k, "fermat_model_end", "sat");
      return finish(10);
    }
    event_trace.macro(k, "fermat_model_end", "unknown");
  }
  if (config_.cerny_model.enabled && cerny_model_guard(k)) {
    event_trace.macro(k, "cerny_model_begin");
    const ApplyResult cerny = default_direct_rule(
        k, "Lucky", "cerny-model", [&] { return cerny_model_apply(k); });
    if (cerny == ApplyResult::Sat) {
      event_trace.macro(k, "cerny_model_end", "sat");
      return finish(10);
    }
    event_trace.macro(k, "cerny_model_end", "unknown");
  }
  if (config_.lookup_circuit_model.enabled &&
      lookup_circuit_model_guard(k)) {
    event_trace.macro(k, "lookup_circuit_model_begin");
    const ApplyResult circuit = default_direct_rule(
        k, "Lucky", "lookup-circuit-model",
        [&] { return lookup_circuit_model_apply(k); });
    if (circuit == ApplyResult::Sat) {
      event_trace.macro(k, "lookup_circuit_model_end", "sat");
      return finish(10);
    }
    event_trace.macro(k, "lookup_circuit_model_end", "unknown");
  }
  if (config_.simon_model.enabled && simon_model_guard(k)) {
    event_trace.macro(k, "simon_model_begin");
    const ApplyResult simon = default_direct_rule(
        k, "Lucky", "simon-model", [&] { return simon_model_apply(k); });
    if (simon == ApplyResult::Sat) {
      event_trace.macro(k, "simon_model_end", "sat");
      return finish(10);
    }
    event_trace.macro(k, "simon_model_end", "unknown");
  }
  if (config_.stconn_proof.enabled && stconn_proof_guard(k)) {
    event_trace.macro(k, "stconn_proof_begin");
    const ApplyResult stconn = default_direct_rule(
        k, "Lucky", "stconn-proof", [&] { return stconn_proof_apply(k); });
    if (stconn == ApplyResult::Unsat) {
      event_trace.macro(k, "stconn_proof_end", "unsat");
      return finish(20);
    }
    event_trace.macro(k, "stconn_proof_end", "unknown");
  }
  // Balance-design construction reads the untouched imported variable blocks.
  // Its root-signature gate is linear in variables and all clause work occurs
  // only after the complete diagonal/boundary shape has been established.
  if (config_.balanced_signature_model.enabled &&
      balanced_signature_model_guard(k)) {
    event_trace.macro(k, "balanced_signature_model_begin");
    const ApplyResult balanced = default_direct_rule(
        k, "Lucky", "balanced-signature-model",
        [&] { return balanced_signature_model_apply(k); });
    if (balanced == ApplyResult::Sat) {
      event_trace.macro(k, "balanced_signature_model_end", "sat");
      return finish(10);
    }
    event_trace.macro(k, "balanced_signature_model_end", "unknown");
  }
  // The parity refutation recognizes a complete imported XOR system and its
  // proof preflight is transactional.  Offer the complete typed parity action
  // before structured-root SR can fix variables or add helper clauses that
  // erase that exact representation.  This is the same lifecycle boundary as
  // exact-one below; admission remains entirely structural and bounded by the
  // public parity parameters.
  if (config_.parity_model.enabled && parity_model_guard(k)) {
    event_trace.macro(k, "parity_model_begin");
    const ApplyResult parity = default_direct_rule(
        k, "Lucky", "parity-model", [&] { return parity_model_apply(k); });
    if (parity == ApplyResult::Sat) {
      event_trace.macro(k, "parity_model_end", "sat");
      return finish(10);
    }
    if (parity == ApplyResult::Unsat) {
      event_trace.macro(k, "parity_model_end", "unsat");
      return finish(20);
    }
    event_trace.macro(k, "parity_model_end", "unknown");
  }
  // The exact-one proof compares a complete live incidence system with the
  // parser's stable binary order. Run it while both still describe the same
  // imported formula, before structured-root rules may add helpers or retire
  // clauses. Its count-only preflight keeps every decline proof-atomic.
  if (config_.onehot_model.enabled && onehot_model_guard(k)) {
    event_trace.macro(k, "exact_one_refutation_begin");
    const ApplyResult exact_one = default_direct_rule(
        k, "Lucky", "exact-one-refutation", [&] {
          return exact_one_refutation_apply(
              k, strategy::OnehotModelParameters::from_kernel(k));
        });
    if (exact_one == ApplyResult::Unsat) {
      event_trace.macro(k, "exact_one_refutation_end", "unsat");
      return finish(20);
    }
    event_trace.macro(k, "exact_one_refutation_end", "unknown");
  }
  bool structured_root_grew_trail = false;
  uint64_t structured_root_amo_binaries_added = 0;
  bool structured_root_graph_root_progress = false;
  std::vector<Var> residual_import_order;
  // Symmetry detection may depend on adjacency insertion order. Schedule the
  // shared structured program on the imported root before speculative Lucky
  // propagation can rearrange watches. The reference Probe-entry order remains
  // an explicit strategy choice; empty/compatibility programs retain the cold
  // Lucky fast path.
  if (config_.inprocess.structured_root_before_lucky &&
      !config_.inprocess.structured_root_stages.empty() &&
      (!k.proof || k.proof->dsr())) {
    kernel_materialize_cold_state(k);
    const uint64_t amo_binaries_before =
        k.stats.sr_unique_literal_amo_binaries;
    const uint64_t post_amo_progress_before =
        k.stats.sr_post_amo_nonhelper_applied;
    const uint64_t post_amo_graph_root_units_before =
        k.stats.sr_post_amo_graph_root_units;
    const size_t structured_trail_before = k.trail.size();
    const uint64_t structured_started = now_nanos();
    const int structured_result = inprocess_.run_structured_root(k, stop);
    const uint64_t structured_elapsed = now_nanos() - structured_started;
    k.stats.structured_root_nanos += structured_elapsed;
    k.stats.inprocess_nanos += structured_elapsed;
    structured_root_grew_trail = k.trail.size() > structured_trail_before;
    if (structured_result == 10 || structured_result == 20)
      return finish(structured_result);
    if ((stop && *stop) || (k.stop && *k.stop))
      return finish(0);
    const uint64_t amo_binaries_added =
        k.stats.sr_unique_literal_amo_binaries - amo_binaries_before;
    structured_root_amo_binaries_added = amo_binaries_added;
    // ULC completion is useful in three distinguishable ways.  If generic
    // graph symmetry consumes the completed BIG and fixes a root literal,
    // retain the pairs as input structure for search: the fixing is durable
    // evidence that completion exposed a useful subgroup.  If later progress
    // does not do that, the helpers have served their discovery purpose and
    // one canonical BCE pass may remove them.  If completion was the only
    // progress, retain the pairs instead of paying for a formula round trip
    // which leaves only scheduler/heuristic perturbation.  These are producer
    // outcomes, independent of formula size or benchmark identity.
    const bool amo_enabled_later_progress =
        k.stats.sr_post_amo_nonhelper_applied != post_amo_progress_before;
    const bool amo_enabled_graph_root_progress =
        k.stats.sr_post_amo_graph_root_units !=
        post_amo_graph_root_units_before;
    structured_root_graph_root_progress =
        amo_enabled_graph_root_progress;
    if (config_.inprocess.structured_root_bce_after_unique_literal_amo &&
        default_should_cleanup_unique_literal_amo(
            amo_binaries_added, amo_enabled_later_progress,
            amo_enabled_graph_root_progress)) {
      if (inprocess_reach_root(k))
        return finish(20);
      if (bce_guard(k)) {
        InprocessScope scope(k);
        const ApplyResult bce = default_direct_rule(
            k, "BCE", "post-structured-amo",
            [&] { return bce_apply(k); });
        if (bce == ApplyResult::Unsat)
          return finish(20);
      }
      if ((stop && *stop) || (k.stop && *k.stop))
        return finish(0);
    }
  }
  // Direct finite-domain model search can be much more expensive than a
  // proof-producing root pass.  Preserve the parser's stable binary order
  // through that pass, then search only if preprocessing did not already
  // decide the formula.  The recognizer and full-model validator still own
  // admission; this scheduling order is independent of names and families.
  if (config_.onehot_model.enabled && onehot_model_guard(k)) {
    event_trace.macro(k, "direct_csp_model_begin");
    const ApplyResult direct_csp = default_direct_rule(
        k, "Lucky", "direct-csp-model", [&] { return direct_csp_model_apply(k); });
    if (direct_csp == ApplyResult::Sat) {
      event_trace.macro(k, "direct_csp_model_end", "sat");
      return finish(10);
    }
    event_trace.macro(k, "direct_csp_model_end", "unknown");
  }
  if (k.input_binary_order_captured) {
    k.input_binary_order.clear();
    k.input_binary_order.shrink_to_fit();
    k.input_binary_order_captured = false;
  }
  if (lucky_guard(k)) {
    event_trace.macro(k, "lucky_early_begin");
    k.stats.lucky_early_calls++;
    if (default_lucky(k, "early") == ApplyResult::Sat) {
      event_trace.macro(k, "lucky_early_end", "sat");
      return finish(10);
    }
    event_trace.macro(k, "lucky_early_end", "unknown");
  }
  if (config_.onehot_model.enabled && onehot_model_guard(k)) {
    event_trace.macro(k, "onehot_model_begin");
    const ApplyResult onehot = default_direct_rule(
        k, "Lucky", "onehot-model", [&] { return onehot_model_apply(k); });
    if (onehot == ApplyResult::Sat) {
      event_trace.macro(k, "onehot_model_end", "sat");
      return finish(10);
    }
    event_trace.macro(k, "onehot_model_end", "unknown");
  }
  // The shipped frontend postpones state that neither root propagation nor
  // early Lucky can read. A failed opportunity crosses the first consumer
  // boundary: materialize before sparse collection and every authored rule.
  kernel_materialize_cold_state(k);
  // Search guidance is likewise unobservable to startup propagation and Lucky.
  // Attach it only after the early opportunity fails. ScopedHeuristics consumes
  // the parser's retained activation order, preserving the exact first-search
  // pose; callers that supplied H keep their existing session-wide object.
  // Reconstruct the seed a fresh solver would obtain by parsing the live
  // post-structured residual. This is the integrated equivalent of Satsuma
  // writing its reduced CNF before Kissat parses it. A structured pass that
  // adds no root assignments retains the original seed exactly.
  if (!k.h &&
      default_should_seed_structured_residual(
          structured_root_grew_trail,
          structured_root_amo_binaries_added,
          structured_root_graph_root_progress) &&
      config_.inprocess.structured_root_residual_search_handoff) {
    const uint64_t started = now_nanos();
    k.stats.residual_handoff_variables +=
        heuristics_prepare_residual_activation_order(k);
    residual_import_order = k.input_activation_order;
    k.stats.residual_handoff_nanos += now_nanos() - started;
    ++k.stats.residual_handoff_calls;
  }
  if (!k.h)
    owned_h.emplace(k);
  // Defer the optional second ranking until startup feedback decides whether
  // this residual search state should leave the baseline EVSIDS trajectory.
  heuristics_configure_mab(k, false,
                           config_.branching.mab_exploration,
                           config_.branching.chb_step,
                           config_.branching.chb_step_min,
                           config_.branching.chb_step_decay);
  if (!residual_import_order.empty())
    heuristics_seed_residual_import_order(k, residual_import_order);
  event_trace.macro(k, "preprocess_begin");
  // Kissat preprocess.c initially propagates, then consumes those root units
  // by sparse-collecting the whole large-clause arena before the first Probe
  // technique. This is lifecycle scaffolding, not an authored Strengthen slot.
  RootCollectOutcome collected;
  do {
#ifdef TACTIX_ENABLE_EVENT_TRACE
    for (Lit l = 0; l < static_cast<Lit>(2 * k.nvars); l++)
      event_trace_substitute_map(k, l, l);
#endif
    event_trace_slot_boundary(k, "SparseCollect", "begin");
    collected = kernel_sparse_collect_root(k);
    event_trace_slot_boundary(k, "SparseCollect", "end");
    if (collected == RootCollectOutcome::Refuted)
      return finish(20);
    if (collected == RootCollectOutcome::Unit) {
      const ApplyResult root_result = default_propagate(k, "root-collect");
      if (root_result == ApplyResult::Unsat)
        return finish(20);
    }
  } while (collected == RootCollectOutcome::Unit);
  // Kissat's initial sparse collection compacts every fixed internal variable
  // onto one representative.  Tactix preserves kernel identities for its
  // universal rule surface, but the random brancher's index permutation is
  // policy state and must use the same compacted population and ordering.
  event_trace_target_state(k, "startup-compact-pre",
                           static_cast<uint32_t>(k.trail.size()));
  heuristics_compact_random_order_fixed(k);
  event_trace_target_state(
      k, "startup-compact-post",
      static_cast<uint32_t>(k.compact_import_order.size() -
                            k.unassigned_active));
#ifdef TACTIX_ENABLE_EVENT_TRACE
  for (Var v = 0; v < k.nvars; v++) {
    uint32_t ordinal = 0;
    for (uint32_t sign = 0; sign < 2; sign++)
      for (const WatchEntry w : k.watches.entries(make_lit(v, sign != 0)))
        if (w.binary())
          event_trace_sweep_watch(k, v, ordinal++, w.other());
  }
#endif
  if (inprocess_.want_phase(k, SlotGroup::Probe)) {
    const int phase_result = inprocess_.run_phase(k, SlotGroup::Probe, stop);
    if (phase_result == 10 || phase_result == 20) return finish(phase_result);
  }
  if (config_.inprocess.initial_fast_elimination &&
      default_should_run_fast_elimination_after_structured(
          structured_root_grew_trail)) {
    event_trace.macro(k, "initial_fast_eliminate_begin");
    const int phase_result =
        inprocess_.run_initial_fast_elimination(k, stop);
    event_trace.macro(k, "initial_fast_eliminate_end");
    if (phase_result == 10 || phase_result == 20)
      return finish(phase_result);
  } else if (config_.inprocess.initial_fast_elimination) {
    ++k.stats.fastel_root_suppressed;
  }
  event_trace.macro(k, "preprocess_end");
  startup = default_propagate(k, "post-preprocess");
  if (startup != ApplyResult::Ok)
    return finish(20);
  bool mab_activation_pending = false;
  uint64_t mab_activation_conflict = UINT64_MAX;
  if (config_.branching.mab) {
    if (!config_.branching.mab_after_search_stagnation) {
      heuristics_configure_mab(k, true,
                               config_.branching.mab_exploration,
                               config_.branching.chb_step,
                               config_.branching.chb_step_min,
                               config_.branching.chb_step_decay);
      ++k.stats.mab_activations;
    } else if (default_should_schedule_delayed_mab(
                   config_.branching.mab,
                   config_.branching.mab_after_search_stagnation,
                   k.stats.sr_applications)) {
      const bool accelerated =
          default_fast_elimination_admits_mab_at_entry(
              k.stats.fastel_eliminated, active_variables(k),
              !k.stats.fastel_budget_stops);
      const uint64_t budget = default_mab_stagnation_conflict_budget(
          active_variables(k), accelerated);
      k.stats.mab_activation_fastel_accelerated += accelerated;
      k.stats.mab_activation_limit = budget;
      mab_activation_conflict =
          budget > UINT64_MAX - k.stats.conflicts
              ? UINT64_MAX
              : k.stats.conflicts + budget;
      mab_activation_pending = true;
      ++k.stats.mab_activation_delayed;
    } else {
      ++k.stats.mab_activation_sr_suppressed;
    }
  }
  if (lucky_late_ && lucky_guard(k)) {
    event_trace.macro(k, "lucky_late_begin");
    k.stats.lucky_late_calls++;
    if (default_lucky(k, "late") == ApplyResult::Sat) {
      k.stats.lucky_late_sat++;
      event_trace.macro(k, "lucky_late_end", "sat");
      return finish(10);
    }
    event_trace.macro(k, "lucky_late_end", "unknown");
  }
  presearch_ticks.reset();
  // There is no Kissat collection point between late Lucky and search
  // (preprocess.c:57, reduce.c:160-185).  In particular, collecting the whole
  // arena here would apply the optional CaDiCaL diagnostic order after
  // preprocessing and invent a representation transition the reference never
  // performs.  Tactix models
  // initial fixed-variable compaction's decision-population effect above;
  // subsequent variable/arena compaction remains coupled to Reduce below.
  // Preprocessing has consumed the root-unit trail prefix.  Tactix retains
  // those literals for stable IDs/proof witnesses, so only the lifecycle
  // marker is cleared (Kissat physically clears that prefix).
  k.unflushed_root = 0;
#ifdef TACTIX_ENABLE_EVENT_TRACE
  if (const char *selected = std::getenv("TACTIX_EVENT_TRACE_FACTOR_LITERAL"))
    for (Lit lit = 0; lit < static_cast<Lit>(2 * k.nvars); lit++)
      if (std::atoi(selected) == kernel_externalize(k, lit)) {
        event_trace_factor_literal_state(
            k, lit, k.factor_marks[lit], kernel_var_retired(k, var_of(lit)),
            k.value(lit), k.watches.size(lit));
        uint32_t ordinal = 0;
        for (const WatchEntry watch : k.watches.entries(lit)) {
          const Clause *clause =
              watch.binary() ? nullptr : clause_at(k.arena, watch.ref());
          event_trace_factor_literal_entry(
              k, lit, ordinal++, !clause || !clause->garbage(),
              watch.binary() ? watch.other() : INVALID_LIT,
              watch.binary() ? kernel_binary_id(k, lit, watch.other())
                             : clause->id(),
              clause);
        }
      }
#endif

  // Kissat classifies once after startup simplification and again while
  // entering search (`search.c:kissat_search`, then `start_search`).  The
  // calls are adjacent there too; preserve both so the reach counter and the
  // classification lifetime match the reference exactly.
  update_formula_classification(k);
  update_formula_classification(k);

  // Kissat initializes the first search-time Eliminate limit only from
  // start_search, after startup simplification has changed BINIRR_CLAUSES.
  inprocess_.initialize_search_limits(k);

  // Kissat initializes the first focused-mode tick anchor in `start_search`,
  // after Lucky and preprocessing.  Tactix's schedule object is reset before
  // those startup phases, whose kernel work also uses the shared tick meter;
  // rebase this one clock so startup work cannot lengthen the first stable
  // interval.  Later anchors are maintained by `update_mode_limits`.
  mode.ticks_at_focus_entry = search_ticks(k);

  for (;;) {
    if (mab_activation_pending && default_mab_stagnation_reached(
                                      k.stats.conflicts,
                                      mab_activation_conflict)) {
      heuristics_configure_mab(k, true,
                               config_.branching.mab_exploration,
                               config_.branching.chb_step,
                               config_.branching.chb_step_min,
                               config_.branching.chb_step_decay);
      mab_activation_pending = false;
      ++k.stats.mab_activations;
    }
    event_trace.checkpoint(k);
#ifdef TACTIX_ENABLE_EVENT_TRACE
    if (k.propagate_head < k.trail.size()) {
      const std::string cursor_payload =
          "next=" + std::to_string(kernel_externalize(k, k.trail[k.propagate_head])) +
          "|pos=" + std::to_string(k.propagate_head) +
          "|trail=" + std::to_string(k.trail.size());
      event_trace.detail_text(k, "propagate_cursor", cursor_payload.c_str());
    }
#endif
    const size_t trace_trail_begin = k.trail.size();
    const ApplyResult r = default_propagate(k, "search");
    if (config_.branching.mab)
      heuristics_chb_update_after_propagation(k, r == ApplyResult::Conflict);
    event_trace.implications(k, trace_trail_begin);
    if (r == ApplyResult::Unsat)
      return finish(20);
    if (r == ApplyResult::Conflict) {
      BranchingPolicy &bp = branching ? *branching : default_branching_;
      bp.on_search_propagation_conflict();
      if (config_.branching.mab)
        heuristics_mab_note_conflict(k);
      event_trace.conflict(k);
      event_trace.detail(k, "analysis_begin", k.level);
      event_trace.mode_clock(k, "pre_analyze", mode.ticks_limit,
                             mode.ticks_at_focus_entry, mode.count);
      observe_decision_rate(k); // kissat: before the analysis, once per conflict
#ifdef TACTIX_ENABLE_EVENT_TRACE
      event_trace.detail(k, "reason_bump_delay_before",
                         bump_reasons_delay_.count);
      event_trace.detail(k, "reason_bump_rate_milli",
                         static_cast<int64_t>(
                             averages[k.h->stable].decision_rate.value * 1000));
#endif
      k.bump_reason_limit = want_bump_reasons(k);
      event_trace.detail(k, "reason_bump_limit", k.bump_reason_limit);
      k.bump_reason_depth = config_.analysis.reason_depth;
      const uint64_t learned_before = k.stats.learned;
      const uint64_t br_rounds = k.stats.reason_bump_rounds;
      const uint64_t br_aborted = k.stats.reason_bump_aborted;
      const ApplyResult ar = default_direct_rule_lazy(
          k, "ConflictAnalysis",
          [&] { return "conflict=" + std::to_string(k.stats.conflicts); },
          [&] { return analyze_apply(k); });
      k.bump_reason_limit = 0;
      k.bump_reason_depth = 1;
      // Kissat calls DELAYING(bumpreasons) inside
      // analyze_reason_side_literals, after ordinary analysis has produced a
      // final clause.  Reused conflicts, failed-literal unit batches, and
      // other early analysis exits must not consume this countdown.
      if (k.pending.valid && k.stats.learned != learned_before)
        bump_reasons_delay_.reached_gate(
            k.stats.reason_bump_rounds != br_rounds,
            k.stats.reason_bump_aborted != br_aborted);
      if (ar == ApplyResult::Unsat) {
        event_trace.detail(k, "analysis_end", -1);
        return finish(20);
      }
      update_tiers_after_analysis(k);
      if (!k.pending.valid) { // reused conflict or direct level-one unit batch
        // Level-one failed-literal analysis owns its root-unit batch inside
        // the atomic M3 transition, so it has no pending clause for policy to
        // observe. Kissat still updates the glue averages and reluctant clock
        // once for that size-one/glue-zero conflict result (learn.c:120-130).
        if (k.stats.learned != learned_before) {
          observe_glue(k, 0);
          if (k.h->stable)
            tick_reluctant();
        }
        event_trace.detail(k, "analysis_end", k.level);
        event_trace_analysis_deletions(k);
        event_trace.mode_clock(k, "post_analyze", mode.ticks_limit,
                               mode.ticks_at_focus_entry, mode.count);
        continue;
      }
      event_trace.learned(k, k.pending.lits);
      event_trace.detail(k, "analysis_tail_learned_emitted",
                         k.pending.lits.size());
      observe_glue(k, k.pending.glue); // policy observes; Analyze is pure
      if (k.h->stable)
        tick_reluctant(); // per learned clause (kissat learn.c)
      event_trace.detail(k, "analysis_tail_policy_updated", k.pending.glue);
      {
        const uint32_t jump = k.pending.jump_level;
        const uint32_t back = k.level - 1;
        uint32_t target = jump;
        if (back - jump > chrono_levels) {
          k.stats.chronological++;
          target = back;
        } else if (chrono_reuse_trail_ && chrono_levels != UINT32_MAX &&
                   jump < back) {
          target = reuse_trail_level(k, jump);
          if (target != jump)
            k.stats.chronological++;
        }
        event_trace.detail(k, "analysis_tail_target", target);
        backjump_apply_to(k, target);
      }
      event_trace.detail(k, "analysis_tail_backjump_return", k.level);
      event_trace.heap_scores(k);
      event_trace.detail(k, "analysis_propagate_head", k.propagate_head);
      event_trace.detail(k, "analysis_trail_size", k.trail.size());
      event_trace.detail(k, "analysis_end", k.level);
      event_trace_analysis_deletions(k);
      event_trace.mode_clock(k, "post_analyze", mode.ticks_limit,
                             mode.ticks_at_focus_entry, mode.count);
      continue;
    }
    if (k.unassigned_active == 0)
      return finish(10);
    if (want_reduce(k) && reduce_guard(k)) {
      event_trace.macro(k, "reduce_begin");
      default_prepare_reduction(k);
      if (k.inconsistent)
        return finish(20);
      ReductionPolicy &rp = reduction ? *reduction : default_reduction_;
      if (dynamic_tiers_)
        retier_current_mode(k, config_.reduction);
      pose_reduce_tiers(k, config_.reduction);
      // Kissat samples compactlim before selecting/deleting victims and uses
      // that decision to choose sparse-collection start 0 versus the first
      // reducible clause.  Reusing the decision after Reduce also prevents a
      // formula-changing pass from silently changing the admission boundary.
      const bool compact_due =
          compact_ && kernel_should_compact_variables(
                          k, config_.reduction.compact_inactive_percent);
      reduce_candidates(k, reduce_scratch_, /*measure=*/false,
                        config_.reduction.protect_tiers);
#ifdef TACTIX_ENABLE_EVENT_TRACE
      k.diagnostic_policy_reduce_bytes =
          reduce_scratch_.capacity() * sizeof(Ref);
#endif
      const size_t reduce_victims =
          std::min(rp.victims(k, reduce_scratch_.size()),
                   reduce_scratch_.size());
      event_trace.reduction(k, reduce_scratch_, reduce_victims);
      (void)default_direct_rule_lazy(
          k, "Reduce",
          [&] { return "victims=" + std::to_string(reduce_victims); }, [&] {
            return reduce_apply_refs(k, reduce_scratch_.data(), reduce_victims,
                                     compact_due);
          });
      if (compact_due)
        event_trace_target_state(
            k, "reduce-compact-pre",
            static_cast<uint32_t>(k.compact_import_order.size() -
                                  k.unassigned_active));
      if (compact_due && kernel_compact_variables(k, true))
        heuristics_compact_random_order_fixed(k);
      if (compact_due)
        event_trace_target_state(
            k, "reduce-compact-post",
            static_cast<uint32_t>(k.compact_import_order.size() -
                                  k.unassigned_active));
      update_reduce_limit(k);
      pose_vivify_tiers(k, config_.inprocess);
      update_formula_classification(k);
      inprocess_.note_reduce(k);
      event_trace.macro(k, "reduce_end");
      continue;
    }
    const bool pin_mode =
        force_mode_ == 1 || (force_mode_ == 2 && k.h->stable);
    if (!pin_mode && want_switch_mode(k) && switchmode_guard(k)) {
      event_trace.macro(k, "switch_begin");
      switchmode_apply(k);
      mode.count++;
      averages[k.h->stable].saved_decisions = k.stats.decisions;
      if (k.h->stable) // entering stable: fresh reluctant sequence
        reluctant = {};
      update_mode_limits(k);
      // Kissat mode.c calls `kissat_start_random_sequence` after every mode
      // transition.  It is a no-op on stable entry and starts (or continues)
      // a focused sequence regardless of decision level or its ordinary
      // conflict deadline.
      if (!branching)
        default_branching_.start_random_sequence(k);
      event_trace.macro(k, "switch_end");
      event_trace.heap_scores(k);
      event_trace.mode_clock(k, "post_switch", mode.ticks_limit,
                             mode.ticks_at_focus_entry, mode.count);
      continue;
    }
    {
      const ModeAverages &avg = averages[k.h->stable];
      event_trace.restart_clock(k, restart.next_conflicts, avg.initialized,
                                avg.fast_glue.value, avg.slow_glue.value,
                                config_.restart.glue_margin, want_restart(k));
    }
    // The public Restart rule is applicable at level zero as an explicit
    // no-op. DefaultPolicy retains Kissat's scheduling choice to restart only
    // when there is a search prefix to abandon.
    if (want_restart(k) && k.level > 0 && restart_guard(k)) {
      event_trace.macro(k, "restart_begin");
      // Kissat restart.c asks `kissat_next_decision_variable` for the reuse
      // threshold.  That call is semantically part of restart: during a
      // random-decision sequence it consumes and counts a draw before the
      // post-restart decision.  Route through the active branching subpolicy,
      // then hand only its variable to the policy-neutral Restart rule.
      BranchingPolicy &bp = branching ? *branching : default_branching_;
      const uint8_t old_heuristic = k.h->stable_heuristic;
      const bool changed_heuristic =
          config_.branching.mab && heuristics_mab_restart(k);
      const uint8_t new_heuristic = k.h->stable_heuristic;
      uint32_t keep = 0;
      if (!changed_heuristic) {
        const Lit next = bp.pick_for_restart_reuse(k);
        keep = heuristics_restart_reuse_level_for(k, var_of(next));
      } else {
        // AE-kissat backtracks with the old ranking active, then repairs the
        // newly selected heap before its next decision.
        k.h->stable_heuristic = old_heuristic;
      }
      if (keep < k.level)
        heuristics_update_target_phases(k);
      (void)default_direct_rule_lazy(
          k, "Restart",
          [&] { return "keep-level=" + std::to_string(keep); },
          [&] { return restart_apply_to(k, keep); });
      if (changed_heuristic) {
        k.h->stable_heuristic = new_heuristic;
        heuristics_mab_update_selected_scores(k);
      }
      reluctant.trigger = false; // consumed (kissat reluctant.h)
      if (!k.h->stable) // kissat restart.c: focused-only limit update
        update_restart_limit(k);
      event_trace.macro(k, "restart_end");
      continue;
    }
    if (want_reorder(k)) {
      k.stats.reorder_eligible++;
      if (reorder_guard(k)) {
        event_trace.reorder_begin(k);
        if (config_.reorder.target == DefaultReorderTarget::Queue)
          reorder_apply_target(k, REORDER_QUEUE);
        else if (config_.reorder.target == DefaultReorderTarget::Heap)
          reorder_apply_target(k, REORDER_HEAP);
        else
          reorder_apply(k);
        reorder.count++;
        update_reorder_limit(k);
        event_trace.reorder_end(k);
        continue;
      }
    }
    if (want_rephase(k) && rephase_guard(k)) {
      event_trace.macro(k, "rephase_begin");
      if (prepare_rephase_root(k) == ApplyResult::Unsat)
        return finish(20);
      const DefaultRephaseSlot slot = current_rephase_slot();
      rephase.count++; // ONE rephase event, whatever it is composed of
      if (slot == DefaultRephaseSlot::Walk && walk_guard(k)) {
        // Kissat warmup.c: before importing phases into the walker, complete a
        // temporary assignment with the active branch ranking and propagate
        // beyond conflicts. Assignment-time phase saving is the output; the
        // trail is then discarded without undoing it.
        if (config_.rephase.walk_warmup) {
          BranchingPolicy &bp = branching ? *branching : default_branching_;
          assert(k.level == 0 && kernel_propagation_fixpoint(k));
          k.warming = true;
          k.stats.warmups++;
          while (k.unassigned_active) {
            if (kernel_terminating(k))
              break;
            const Lit decision = bp.pick(k);
            kernel_assign_decision(k, decision);
            k.stats.warming_decisions++;
            event_trace.detail(k, "decision", kernel_externalize(k, decision));
            event_trace.heap_after_decision(k);
            event_trace.heap_scores(k);
            const size_t warmup_trail_begin = k.trail.size();
            kernel_propagate_beyond_conflicts(k);
            event_trace.implications(k, warmup_trail_begin);
          }
          if (k.level)
            kernel_backtrack(k, 0);
          k.warming = false;
        }
        // Structural searches retain their best complete assignment even when
        // it is not a model.  Import one source in a typed round-robin before
        // generic Walk so Walk can refine it and CDCL later consumes the best
        // result through the ordinary saved/target phase mechanism.
        if (config_.rephase.structural_walk_seed &&
            local_search_guidance_guard(k))
          (void)local_search_guidance_apply_next(
              k, config_.rephase.structural_seed_rotation,
              structural_seed_cursor_);
        const uint64_t reference = walk_effort_reference(k);
        k.work_budget = scale_permille(reference, config_.rephase.walk_permille);
        // Kissat seeds the walker from the search policy's shared generator.
        // DefaultBranching owns that generator in Tactix; snapshot it here so
        // the H-only Walk operation need not reach back into its caller.
        k.walk_random_seed = config_.rephase.walk_use_branch_seed
                                 ? default_branching_.randec_rng
                                 : config_.rephase.walk_random_seed;
        walk_apply(k);
        k.work_budget = 0;
      } else {
        const DefaultRephaseSlot effective =
            slot == DefaultRephaseSlot::Walk
                ? config_.rephase.walk_inapplicable_fallback
                : slot;
        uint64_t type = REPHASE_BEST;
        if (effective == DefaultRephaseSlot::Inverted)
          type = REPHASE_INVERTED;
        else if (effective == DefaultRephaseSlot::Original)
          type = REPHASE_ORIGINAL;
        rephase_apply_type(k, type);
      }
      update_rephase_limit(k);
      event_trace.macro(k, "rephase_end");
      continue;
    }
    if (inprocess_.want_phase(k, SlotGroup::Probe)) {
      event_trace.macro(k, "probe_begin");
      const int phase_result = inprocess_.run_phase(k, SlotGroup::Probe, stop);
      if (phase_result == 10 || phase_result == 20) return finish(phase_result);
      update_formula_classification(k);
      event_trace.macro(k, "probe_end");
      continue;
    }
    if (inprocess_.want_phase(k, SlotGroup::Eliminate)) {
      event_trace.macro(k, "eliminate_begin");
      const int phase_result = inprocess_.run_phase(k, SlotGroup::Eliminate, stop);
      if (phase_result == 10 || phase_result == 20) return finish(phase_result);
      update_formula_classification(k);
      event_trace.macro(k, "eliminate_end");
      continue;
    }
    if (stop && *stop)
      return finish(0);
    BranchingPolicy &bp = branching ? *branching : default_branching_;
    const Lit decision = bp.pick(k);
    (void)default_direct_rule_lazy(
        k, "Decide",
        [&] {
          return "literal=" +
                 std::to_string(kernel_externalize(k, decision));
        },
        [&] { return decide_apply(k, decision, false); });
    event_trace.detail(k, "decision", kernel_externalize(k, decision));
    event_trace.heap_after_decision(k);
    event_trace.heap_scores(k);
  }
}


namespace {
void slot_trace_entry(const Kernel &k, const DefaultInprocessScheduler::SlotEntry &e,
                      const RuleVTable &r, int outer) {
  if (!std::getenv("TACTIX_SLOT_TRACE"))
    return;
  std::fprintf(stderr,
               "[slot] phase=%llu outer=%d %s enabled=%d defer=%d "
               "guard=%d dosed=%d followup=%u mode=%u meter=%llu limit=%llu\n",
               (unsigned long long)k.stats.inprocess_phases, outer, r.name,
               (int)e.enabled, (int)e.defer_preprocess, (int)r.guard(k),
               (int)e.dosed, static_cast<unsigned>(e.followup),
               static_cast<unsigned>(e.followup_mode),
               (unsigned long long)(e.meter ? e.meter(k) : 0),
               (unsigned long long)e.limit);
}
} // namespace

bool DefaultInprocessScheduler::slot_entry_admissible(SlotEntry &e, const Kernel &k,
                                          const SlotPhaseCtx &ctx) {
  if (!e.enabled || ctx.phase_unsat) {
    e.tm.dec_disabled++;
    return false;
  }
  const bool initial_fast_bve =
      initial_fast_elimination_active_ &&
      !std::strcmp(tactix_rules()[e.rule].name, "BVE");
  if (k.stats.conflicts == 0 && !e.preprocess && !initial_fast_bve) {
    e.tm.dec_preprocess++;
    return false;
  }
  if (e.max_applies && e.applies >= e.max_applies) {
    e.tm.dec_cap++;
    return false; // configured per-occurrence cap (see SlotEntry::max_applies)
  }
  if (e.defer_preprocess && k.stats.conflicts == 0 && !initial_fast_bve) {
    e.tm.dec_preprocess++;
    return false; // no elimination at preprocessing (kissat fastel=0)
  }
  e.applies++;
  return true;
}

bool DefaultInprocessScheduler::followup_admissible(SlotEntry &e,
                                                     const Kernel &k,
                                                     SlotPhaseCtx &ctx) {
  e.followup_mode = FollowupMode::None;
  if (k.stats.conflicts != 0 || e.followup == FollowupKind::None ||
      !preprocess_followups_)
    return true;
  e.tm.followup_offered++;
  e.followup_mode = preprocessing_followup_mode(
      e.followup, ctx.congruence_changed, ctx.sweep_changed);
  if (e.followup_mode == FollowupMode::None)
    return false;
  e.tm.followup_taken++;
  if (e.followup_mode == FollowupMode::Eager)
    e.tm.followup_eager++;
  else
    e.tm.followup_final++;
  return true;
}

FollowupMode DefaultInprocessScheduler::preprocessing_followup_mode(
    FollowupKind kind, bool congruence_changed, bool sweep_changed) {
  if (kind == FollowupKind::AfterCongruence)
    return congruence_changed ? FollowupMode::Eager : FollowupMode::None;
  if (kind == FollowupKind::AfterSweepOrFinal) {
    if (sweep_changed)
      return FollowupMode::Eager;
    if (!congruence_changed)
      return FollowupMode::Final;
  }
  return FollowupMode::None;
}

// SC2024 fastel folds a small forward-subsumption check into each occurrence
// flush. Keep the deletion in the SubsumeForward rule; this helper owns only
// the outer occurrence traversal, clause-size cap and population accounting.
static size_t fastel_flush_occurrences(Kernel &k, Lit lit,
                                       const RuleVTable &subsume,
                                       std::vector<uint8_t> &marks,
  uint32_t occurrence_limit,
  uint32_t clause_size_limit) {
  assert(k.dense && k.dense->track_order);
  size_t count = 0;
  // Kissat compacts the inspected prefix in place.  Delay publication until
  // this immutable span expires, but retain the same per-entry keep decisions;
  // an early cap leaves the uninspected suffix untouched.
  const size_t physical = k.dense->ordered.size(lit);
  std::vector<uint8_t> keep(physical, 1);
  size_t at = 0;
  // SubsumeForward marks a clause garbage but does not collect or mutate the
  // dense payload, so this owner-ordered view remains stable during the scan.
  for (const OccIndex::Entry entry : k.dense->ordered[lit]) {
    if (entry.binary) {
      const Lit other = entry.payload;
      if (k.value(other) > 0) {
        ++at;
        continue;
      }
      if (kernel_var_retired(k, var_of(other))) {
        keep[at++] = 0;
        continue;
      }
    } else {
      const Ref ref = entry.payload;
      Clause *clause = clause_at(k.arena, ref);
      bool contains = false;
      for (const Lit other : *clause)
        contains |= other == lit;
      if (clause->garbage() || !contains) {
        keep[at++] = 0;
        continue;
      }
      if (clause->size > clause_size_limit) {
        count = static_cast<size_t>(occurrence_limit) + 1;
        ++at;
        break;
      }
      bool satisfied = false;
      for (const Lit other : *clause)
        satisfied |= k.value(other) > 0;
      if (satisfied) {
        ++at;
        continue;
      }
      const ApplyResult cleaned = apply_rule_structured(
          subsume, k, "fastel-occurrence",
          [&] {
            return subsume_forward_try_fastel(k, ref, occurrence_limit,
                                              marks);
          });
      if (cleaned == ApplyResult::Ok) {
        keep[at++] = 0;
        continue;
      }
    }
    ++at;
    if (++count > occurrence_limit)
      break;
  }
  if (std::find(keep.begin(), keep.end(), uint8_t{0}) != keep.end()) {
    size_t published = 0;
    k.dense->ordered.compact(lit, [&](OccIndex::Entry) {
      assert(published < keep.size());
      return keep[published++];
    });
    assert(published == keep.size());
  }
  return count;
}

uint64_t DefaultInprocessScheduler::ledger_remaining(SlotEntry &e, const Kernel &k,
                                        uint64_t limit) {
  const uint64_t spent = e.meter(k);
  if (limit >= spent)
    return limit - spent;
  e.tm.wrapped++;
  return 0;
}

DefaultInprocessScheduler::SlotStep
DefaultInprocessScheduler::run_dosed_entry(Kernel &k, SlotEntry &e, const RuleVTable &r,
                               SlotPhaseCtx &ctx) {
  uint64_t limit = e.limit;
  ctx.last_result = ApplyResult::NoOp;
  if (!r.guard(k)) {
    e.tm.dec_guard++;
    return SlotStep::Next;
  }
  const bool bve_entry = !std::strcmp(r.name, "BVE");
  const bool initial_fast_bve =
      bve_entry && initial_fast_elimination_active_;
  BveBoundPolicy *ramp = nullptr;
  if (bve_entry && !initial_fast_bve)
    ramp = bve_bound ? bve_bound : &default_bve_ramp_;
  const bool level_mode = bve_entry && ramp;
  const uint32_t passes = level_mode ? 1 : ramp ? ramp->num_passes() : 1;
  uint64_t elim_at_last_pass = k.stats.bve_eliminated;
  const bool use_retry = bve_entry && !ramp;
  bool engaged = false; // a pass got past the budget break and ran instances
  for (uint32_t pass = 0; pass < passes && !ctx.phase_unsat; pass++) {
    if (ramp && e.meter(k) > limit) {
      break;
    }
    engaged = true;
    if (ramp)
      k.bve_bound = level_mode ? bve_level_ : ramp->bound(pass);
    elim_at_last_pass = k.stats.bve_eliminated; // fixpoint test above
    // Pose and validate BVE's typed invocation once per pass.  Keeping this
    // session outside the hot candidate loop preserves the legacy default
    // schedule without paying parameter save/restore and rule validation for
    // every pivot.
    std::optional<strategy::InvocationBudget> bve_invocation_budget;
    std::optional<strategy::BveInvocationSession> bve_invocation_session;
    if (bve_entry) {
      bve_invocation_budget.emplace(strategy::WorkUnit::BveTicks,
                                    strategy::WorkLimit::unlimited());
      const auto *posed = std::get_if<strategy::BveParameters>(&e.parameters);
      const strategy::BveParameters parameters =
          initial_fast_bve
              ? config().initial_fast_elimination_parameters
              : posed ? *posed : strategy::BveParameters::from_kernel(k);
      bve_invocation_session.emplace(
          r, k, parameters, *bve_invocation_budget);
    }
    if (initial_fast_bve) {
      // Candidate discovery must inspect every live variable before the
      // owner's radix order is known. Charge that mandatory lower bound to
      // the same typed startup dose as resolution. If it cannot fit, decline
      // before allocating or mutating a partial owner domain.
      const uint64_t active = active_variables(k);
      ++k.stats.fastel_rounds;
      k.stats.fastel_active += active;
      const uint64_t resolution_remaining = ledger_remaining(e, k, e.limit);
      const bool overflow =
          initial_fast_elimination_discovery_ticks_ > resolution_remaining;
      const uint64_t discovery_remaining =
          overflow ? 0
                   : resolution_remaining -
                         initial_fast_elimination_discovery_ticks_;
      if (!default_fast_elimination_discovery_admissible(
              active, discovery_remaining)) {
        ++k.stats.fastel_budget_stops;
        initial_fast_elimination_budget_exhausted_ = true;
        ctx.eliminate_limit_reached = true;
        ++e.tm.dec_budget;
        return SlotStep::Next;
      }
      initial_fast_elimination_discovery_ticks_ += active;
      k.stats.fastel_discovery_ticks += active;
      assert(initial_fast_elimination_discovery_ticks_ <= e.limit);
      limit = e.limit - initial_fast_elimination_discovery_ticks_;
    }
    payloads_.resize(2 * static_cast<size_t>(k.nvars) + 1);
    uint32_t n =
        r.instances(k, payloads_.data(),
                    static_cast<uint32_t>(payloads_.size()));
    if (initial_fast_bve) {
      const std::vector<RuleVTable> &rules = tactix_rules();
      const int subsume_id = tactix_rule_id("SubsumeForward");
      assert(subsume_id >= 0);
      const RuleVTable &subsume = rules[static_cast<size_t>(subsume_id)];
      const strategy::BveParameters &parameters =
          config().initial_fast_elimination_parameters;
      struct Candidate {
        uint64_t payload;
        uint64_t score;
        uint64_t tie;
      };
      std::vector<Candidate> candidates;
      candidates.reserve(n);
      for (uint32_t j = 0; j < n; ++j) {
        Lit candidate;
        if (!lit_of_instance(k, payloads_[j], &candidate))
          continue;
        const Var variable = var_of(candidate);
        if (variable >= initial_fast_elimination_attempted_.size() ||
            initial_fast_elimination_attempted_[variable] ||
            k.value(candidate) || kernel_var_retired(k, variable))
          continue;
        const Lit positive = make_lit(variable, false);
        const size_t pos = fastel_flush_occurrences(
            k, positive, subsume, initial_fast_elimination_marks_,
            parameters.occurrence_limit,
            parameters.clause_size_limit);
        if (pos > parameters.occurrence_limit)
          continue;
        // Preserve the shipped owner's observable gather bug: both terms use
        // LIT(pivot), so the radix score is twice the positive population.
        const size_t neg = fastel_flush_occurrences(
            k, positive, subsume, initial_fast_elimination_marks_,
            parameters.occurrence_limit,
            parameters.clause_size_limit);
        if (neg > parameters.occurrence_limit ||
            pos + neg > parameters.occurrence_limit)
          continue;
        const uint64_t tie =
            variable < k.compact_import_position.size() &&
                    k.compact_import_position[variable] != INVALID_VAR
                ? k.compact_import_position[variable]
                : variable;
        candidates.push_back({payloads_[j], pos + neg, tie});
      }
      k.stats.fastel_candidates += candidates.size();
      if (!default_should_run_initial_fast_elimination(candidates.size(),
                                                       active_variables(k))) {
        ++k.stats.fastel_declined;
        candidates.clear();
      }
      std::stable_sort(candidates.begin(), candidates.end(),
                       [](const Candidate &a, const Candidate &b) {
                         return std::tie(a.score, a.tie) <
                                std::tie(b.score, b.tie);
                       });
      n = static_cast<uint32_t>(candidates.size());
      for (uint32_t j = 0; j < n; ++j)
        payloads_[j] = candidates[j].payload;
    }
    const bool dynamic_bve = bve_entry && !candidate_order &&
                             e.order == CandidateOrder::Heuristic &&
                             !initial_fast_bve;
    BveCandidateHeap bve_heap;
    if (dynamic_bve)
      bve_heap.initialize(k, payloads_.data(), n);
    else if (!initial_fast_bve)
      order_candidates(k, e, payloads_.data(), n);
    if (std::getenv("TACTIX_SLOT_TRACE"))
      std::fprintf(stderr,
                   "[slot]   %s pass=%u n=%u bve_bound=%u meter=%llu "
                   "limit=%llu\n",
                   r.name, pass, n, k.bve_bound,
                   (unsigned long long)e.meter(k), (unsigned long long)limit);
    if (dynamic_bve) {
      assert(!k.bve_score_update_hook);
      k.bve_score_update_hook = BveCandidateHeap::update_hook;
      k.bve_score_update_state = &bve_heap;
    }
    uint32_t i = 0;
    while (dynamic_bve ? !bve_heap.empty() : i < n) {
      const uint64_t payload =
          dynamic_bve ? bve_heap.pop_max() : payloads_[i++];
      if (bve_entry) {
        Lit candidate;
        if (lit_of_instance(k, payload, &candidate) &&
            var_of(candidate) < k.nvars &&
            (k.value(candidate) || kernel_var_retired(k, var_of(candidate))))
          continue;
        // Resolvent generation can delete a newly satisfied large antecedent
        // and reinsert its still-active pivot before retiring it. Preserve
        // that physical ghost until pop, but do not apply/count BVE again.
        // Kissat tests active status before its effort limit at this boundary;
        // this is policy eligibility, not a restriction on public BVE actions.
      }
      if (initial_fast_bve) {
        Lit candidate;
        if (!lit_of_instance(k, payload, &candidate))
          continue;
        const Var variable = var_of(candidate);
        if (variable >= initial_fast_elimination_attempted_.size() ||
            initial_fast_elimination_attempted_[variable])
          continue;
        initial_fast_elimination_attempted_[variable] = 1;
        const int subsume_id = tactix_rule_id("SubsumeForward");
        assert(subsume_id >= 0);
        const RuleVTable &subsume =
            tactix_rules()[static_cast<size_t>(subsume_id)];
        const strategy::BveParameters &parameters =
            config().initial_fast_elimination_parameters;
        const size_t pos = fastel_flush_occurrences(
            k, make_lit(variable, false), subsume,
            initial_fast_elimination_marks_,
            parameters.occurrence_limit, parameters.clause_size_limit);
        const size_t neg = fastel_flush_occurrences(
            k, make_lit(variable, true), subsume,
            initial_fast_elimination_marks_,
            parameters.occurrence_limit, parameters.clause_size_limit);
        if (pos > parameters.occurrence_limit ||
            neg > parameters.occurrence_limit ||
            pos + neg > parameters.occurrence_limit)
          continue;
      }
      if (e.meter(k) > limit) {
        if (initial_fast_bve &&
            !initial_fast_elimination_budget_exhausted_) {
          ++k.stats.fastel_budget_stops;
          initial_fast_elimination_budget_exhausted_ = true;
          ctx.eliminate_limit_reached = true;
        }
        break; // dose spent
      }
      if (!r.guard(k)) {
        break;
      }
      if (use_retry || ramp) {
        Lit rl;
        if (lit_of_instance(k, payload, &rl) &&
            var_of(rl) < k.nvars && !k.bve_retry[var_of(rl)])
          continue;
      }
      if (ctx.stop && *ctx.stop)
        break; // §6: a dose can enumerate thousands of candidates
      if (e.cursor_enabled) {
        e.cursor = instance_key(payload) + 1;
        e.ord.advanced++;
      }
      const bool hand_residual = e.budget_aware && e.meter;
      if (hand_residual) {
        const uint64_t remaining = ledger_remaining(e, k, limit);
        k.work_budget = remaining ? remaining : 1;
      }
      // Kissat mutates H at the same points as each BVE candidate: units
      // produced while generating/connecting resolvents become fixed first,
      // then a successfully eliminated pivot is removed, and only afterward
      // can propagation fix more variables.  Formula rules publish those
      // effects to the policy as trail and retirement events, so remember the
      // candidate boundary and consume the two streams in that same order.
      // Deferring all BVE retirements to the slot boundary batches hundreds
      // of arbitrary score-heap removals and changes the physical heap even
      // when the final formula and scores are identical.
      const size_t candidate_trail_before = k.trail.size();
      const uint64_t candidate_roots_before = k.stats.root_assignments;
      const uint64_t candidate_eliminated_before = k.stats.bve_eliminated;
      const uint32_t bve_flush_from = k.propagate_head;
#ifdef TACTIX_ENABLE_EVENT_TRACE
      Var trace_bve_var = INVALID_VAR;
      const uint64_t trace_bve_eliminated_before = k.stats.bve_eliminated;
#endif
      const ApplyResult ar = [&] {
        TickSinkScope sink(k, e.tick_counter);
#ifdef TACTIX_ENABLE_EVENT_TRACE
        if (bve_entry) {
          Lit candidate;
          if (lit_of_instance(k, payload, &candidate)) {
            trace_bve_var = var_of(candidate);
            event_trace_bve_candidate(k, trace_bve_var, "begin", e.meter(k),
                                      limit, false);
          }
        }
#endif
        const ApplyResult result = metered_rule_apply(k, e.meter, [&] {
          if (!bve_entry)
            return apply_rule_instance(r, k, payload);
          const strategy::InvocationResult invoked =
              bve_invocation_session->apply_one(payload);
          // Existing configurations predate typed validation.  The surrounding
          // scheduler has already checked this candidate and its stop/guard;
          // preserve that legacy transition if an as-yet-unmigrated setting
          // cannot be represented instead of silently turning it into NoOp.
          if (!invoked.applications)
            return apply_rule_instance(r, k, payload);
          return invoked.rule_result;
        });
#ifdef TACTIX_ENABLE_EVENT_TRACE
        if (trace_bve_var != INVALID_VAR)
          event_trace_bve_candidate(k, trace_bve_var, "end", e.meter(k),
                                    limit,
                                    k.stats.bve_eliminated !=
                                        trace_bve_eliminated_before);
#endif
        return result;
      }();
      ctx.last_result = ar;
      heuristics_consume_rule_advice(k);
      // Every dosed Kissat rule which learns a root unit fixes/removes that
      // variable from H before its ensuing propagation.  BVE was the first
      // producer wired here; TransitiveReduce's failed-source unit uses the
      // same general lifecycle rather than waiting for the whole slot.
      if (k.stats.root_assignments != candidate_roots_before)
        heuristics_consume_root_assignments(k, candidate_trail_before);
      if (bve_entry) {
        heuristics_consume_retirements(k);
      }
      if (hand_residual)
        k.work_budget = 0;
      if (ar == ApplyResult::Unsat || k.inconsistent) {
        ctx.phase_unsat = true;
        break;
      }
      if (ar != ApplyResult::Ok)
        continue; // this candidate changed nothing; try the next
      // Kissat's round repeats on eliminations (`last_round_eliminated`), not
      // on a unit a declined candidate happened to learn.
      if (!bve_entry || k.stats.bve_eliminated != candidate_eliminated_before)
        ctx.round_changed = true;
      // resolve.c can learn a unit immediately and then reject the same BVE
      // candidate on its later growth bound.  eliminate.c nevertheless flushes
      // that unit after every candidate, and the rule reports such a decline
      // as a state change, so root propagation follows it here as well.
      const size_t propagation_trail_before = k.trail.size();
      const ApplyResult propagation =
          default_propagate(k, "inprocess-candidate");
      if (propagation == ApplyResult::Unsat) {
        ctx.phase_unsat = true;
        break;
      }
      if (bve_entry && k.trail.size() != propagation_trail_before)
        heuristics_consume_root_assignments(k, propagation_trail_before);
      if (bve_entry)
        bve_flush_units_while_connected(k, bve_flush_from);
#ifdef TACTIX_ENABLE_EVENT_TRACE
      if (trace_bve_var != INVALID_VAR)
        event_trace_bve_candidate(
            k, trace_bve_var, "postflush", e.meter(k), limit,
            k.stats.bve_eliminated != trace_bve_eliminated_before);
#endif
    }
    if (dynamic_bve) {
      k.bve_score_update_hook = nullptr;
      k.bve_score_update_state = nullptr;
      assert(k.bve_occurrence_count_image);
      k.bve_occurrence_count_image = nullptr;
    }
  }
  if (level_mode && engaged && !ctx.phase_unsat)
    bve_ran_this_phase_ = true;
  (void)elim_at_last_pass;
  if (bve_entry && ctx.outer == 0 && !initial_fast_bve)
    bve_rounds_run_++;
  if (bve_entry && !initial_fast_bve && !ctx.phase_unsat) {
    // Kissat flushes and densely collects after every completed elimination
    // round, including a round which schedules candidates but eliminates
    // none (eliminate.c:416-509).  The dosed scheduler is Tactix's authored
    // elimination round; deferring its lazy garbage until phase exit carries
    // a much larger arena into the following Strengthen round and changes the
    // physical state from which that common consumer reconstructs.
    kernel_collect_garbage(k);
    // The resolution ceiling belongs to the whole Eliminate phase.  Finish
    // this round's cleanup, but do not start another forward round after
    // exhausting it (Kissat eliminate.c::eliminate_variables).  Equality still
    // admits work; neither heap completeness nor progress identifies this
    // boundary, since even a rejected last candidate can cross the ceiling.
    if (ctx.group == SlotGroup::Eliminate && e.meter(k) > limit)
      ctx.eliminate_limit_reached = true;
  }
  e.tm.admitted++; // the dosed branch ran; it exits here, not below
  return SlotStep::Next;
}

bool DefaultInprocessScheduler::factor_entry_declines(const Kernel &k, SlotEntry &e) {
  const auto &cfg = config();
  // This remains an explicit typed diagnostic arm. Formula classification
  // never changes it; production admits both startup and repeated Factor work.
  if (k.stats.conflicts > 0 && !cfg.factor_repeated_enabled) {
    e.tm.dec_profile++;
    return true;
  }
  const uint64_t active = active_variables(k);
  // A nonzero ceiling is an explicit diagnostic arm. Production leaves it at
  // zero and follows Kissat's factordelay predicate below for every formula.
  if (cfg.factor_active_ceiling && active >= cfg.factor_active_ceiling)
    factor_large_formula_ = true;
  if (factor_large_formula_) {
    e.tm.dec_warmup++;
    return true;
  }
  uint64_t threshold = 1;
  const uint32_t decades =
      bve_rounds_run_ > cfg.factor_decade_round_cap
          ? cfg.factor_decade_cap
          : bve_rounds_run_ + cfg.factor_decade_offset;
  for (uint32_t d = 0; d < decades; d++)
    threshold *= cfg.factor_decade_base;
  if (active >= threshold) {
    e.tm.dec_warmup++;
    return true;
  }
  // `limits.factor.marked >= statistics.literals_factor` is a call-level
  // cumulative watermark, not a scan of the current `flags->factor` bits.
  // A completed Factor call records the counter *after* creating its own
  // divider/quotient clauses, so those self-produced marks do not schedule an
  // otherwise material-free second call.  An interrupted call leaves the
  // watermark unchanged and therefore remains retryable.
  if (factor_marked_watermark_ >= k.factor_literals_marked) {
    e.tm.dec_material++;
    return true;
  }
  return false;
}

void DefaultInprocessScheduler::factor_dose_config(Kernel &k, SlotEntry &) {
  k.factor_composite = true;
}

ApplyResult DefaultInprocessScheduler::run_vivify_dose(Kernel &k, SlotEntry &e,
                                           const RuleVTable &r,
                                           uint64_t limit) {
  // `vivifyfocusedtiers=1` is Kissat's shipped policy: every Vivify band reads
  // the focused-mode tier snapshot, independent of the current search mode.
  // A stable OTFS retier legitimately poses the stable snapshot for the
  // analysis it resumes, so pose the Vivify consumer here instead of relying
  // on the last Reduce to have left these shared fields in focused mode.
  pose_vivify_tiers(k, config());
  const auto &cfg = config();
  const uint64_t remaining0 = ledger_remaining(e, k, limit);
  const uint64_t remaining = remaining0 ? remaining0 : 1;
  const uint64_t dose_start = e.meter(k);
  const bool irr_delayed = k.stats.conflicts > 0 && e.delay_count > 0;
  if (irr_delayed)
    e.delay_count--;
  ApplyResult ar = ApplyResult::NoOp;
  // Kissat advances one cumulative probing-tick ceiling by each band's
  // proportional share (vivify.c:1455-1490).  Keep the same ledger here:
  // unused work from an early tier belongs to every later tier, while an
  // overrun is precharged rather than granting the next call a fresh dose.
  const uint64_t denominator = irr_delayed ? cfg.vivify_redundant_share
                                           : cfg.vivify_total_share;
  auto share = [&](uint32_t weight) {
    return remaining / denominator * weight +
           remaining % denominator * weight / denominator;
  };
  uint64_t cumulative_budget = 0;
  k.work_budget_bounded = true;
  const uint32_t passes =
      static_cast<uint32_t>(cfg.vivify_tier_scopes.size());
  // Equal focused tier-1 and tier-2 glue limits leave tier 2 empty.  Kissat
  // then hands tier 2's share to tier 1 up front and never runs the tier-2
  // round, so no flush/rewatch happens for it (vivify.c:kissat_vivify,
  // "tier1 matches tier2 thus using tier2 budget for tier1"). Without the
  // merge tier 1 stops at half its budget and the leftover flows to tier 3.
  std::array<uint32_t, 3> tier_shares = cfg.vivify_tier_shares;
  if (k.tier1 == k.tier2 && tier_shares[0] && tier_shares[1]) {
    tier_shares[0] += tier_shares[1];
    tier_shares[1] = 0;
  }
  for (uint32_t p = 0; p < passes && ar != ApplyResult::Unsat && !k.inconsistent;
       p++) {
    if (tier_shares[p] == 0)
      continue; // a band without a share is not a round
    k.vivify_scope = cfg.vivify_tier_scopes[p];
    cumulative_budget += share(tier_shares[p]);
    k.work_budget = cumulative_budget;
    k.work_budget_offset = e.meter(k) - dose_start;
    TickSinkScope sink(k, e.tick_counter);
    const ApplyResult a =
        metered_rule_apply(k, e.meter, [&] { return apply_rule(r, k); });
    if (a == ApplyResult::Unsat ||
        (a == ApplyResult::Ok && ar != ApplyResult::Unsat))
      ar = a;
  }
  if (!irr_delayed && ar != ApplyResult::Unsat && !k.inconsistent) {
    cumulative_budget += share(cfg.vivify_total_share -
                               cfg.vivify_redundant_share);
    const uint64_t tried_before = k.stats.vivify_checked;
    const auto produced = [&] {
      // Kissat increments vivifier.vivified for every successful candidate
      // terminal, not only learned replacements (vivify.c:1129-1217,
      // 1313-1315).  Root-schedule cleanup is outside the tried population.
      return k.stats.vivify_subsumed + k.stats.vivify_shrunken +
             k.stats.vivify_implied + k.stats.vivify_asymmetric +
             k.stats.vivify_instantiated;
    };
    const uint64_t produced_before = produced();
    k.vivify_scope = 2;
    k.work_budget = cumulative_budget;
    k.work_budget_offset = e.meter(k) - dose_start;
    const ApplyResult ar2 = [&] {
      TickSinkScope sink(k, e.tick_counter);
      return metered_rule_apply(k, e.meter,
                                [&] { return apply_rule(r, k); });
    }();
    if (ar2 == ApplyResult::Unsat)
      ar = ar2;
    else if (ar2 == ApplyResult::Ok && ar != ApplyResult::Ok)
      ar = ar2;
    if (k.stats.conflicts > 0) {
      const uint64_t tried = k.stats.vivify_checked - tried_before;
      const uint64_t produced_now = produced() - produced_before;
      if (tried == 0 ||
          static_cast<unsigned __int128>(produced_now) * PERCENT_SCALE <
              static_cast<unsigned __int128>(tried) *
                  cfg.vivify_irredundant_productivity_percent) {
        e.delay_current += (e.delay_current < UINT32_MAX);
        e.delay_count = e.delay_current;
      } else {
        e.delay_current /= 2;
        e.delay_count = e.delay_current;
      }
    }
  }
  k.vivify_scope = 0;
  k.work_budget = 0;
  k.work_budget_offset = 0;
  k.work_budget_bounded = false;
  return ar;
}

ApplyResult DefaultInprocessScheduler::run_budgeted_batch(Kernel &k, SlotEntry &e,
                                              const RuleVTable &r,
                                              uint64_t limit,
                                              bool factor_entry) {
  const uint64_t remaining0 = ledger_remaining(e, k, limit);
  const bool substitute = !std::strcmp(r.name, "Substitute");
  // Substitute's effort is tested after an indivisible productive round.
  // A zero allowance still admits that mandatory first round; other
  // budget-aware rules retain a one-tick hand-off so they can make progress.
  const uint64_t handed = substitute ? remaining0
                                     : (remaining0 ? remaining0 : 1);
  const uint64_t spent_before = e.meter(k);
  bool substitute_round_budget_break = false;
#ifdef TACTIX_ENABLE_RULE_JOURNAL
  uint32_t substitute_rounds_run = 0;
  e.journal_last_round_spent = 0;
  e.journal_rounds = 0;
  e.journal_round_budget_break = false;
#endif
  if (factor_entry)
    factor_dose_config(k, e);
  k.work_budget = handed;
  // The fused Strengthen pass reproduces Kissat's forward-step ceiling at the
  // only reference cut point: strictly between complete candidates.  The
  // standalone C1 decomposition retains its diagnostic per-partner budget.
  // Both cuts are resumable through the touched-variable substrate.
  const bool previous_midround_budget = k.midround_budget;
  k.midround_budget = config().forward_midround_budget &&
                      (!std::strcmp(r.name, "SubsumeForward") ||
                       !std::strcmp(r.name, "Strengthen"));
  ApplyResult ar;
  {
    TickSinkScope sink(k, e.tick_counter);
    if (!std::strcmp(r.name, "Sweep")) {
      const auto *posed = std::get_if<SweepLimits>(&e.parameters);
      const SweepLimits lim = posed ? *posed : configured_sweep_limits(config());
      const uint64_t t0 = now_nanos();
      ar = sweep_apply_exact_limits(k, lim);
      if (r.id < Stats::MAX_TIMED_RULES) {
        k.stats.rule_nanos[r.id] += now_nanos() - t0;
        k.stats.rule_calls[r.id]++;
      }
    } else if (substitute) {
      // kissat substitute.c:568-602 runs round one of every authored call
      // unconditionally.  Only after that round retires a variable does its
      // own tick delta get compared with 10 per mille of the Probe reference;
      // an overrun suppresses the optional next round, never a later call.
      // `complete=true` during initial probing ignores the comparison.
      const uint64_t t0 = now_nanos();
      ar = ApplyResult::NoOp;
      const bool complete = k.stats.conflicts == 0;
      // The large watches leave in round one and come back once after the
      // call's last round (substitute.c `substitute_rounds`).
      const bool watches_at_entry = k.large_watches_connected;
      const uint32_t trail_at_entry = static_cast<uint32_t>(k.trail.size());
      for (uint32_t round = 0; round < config().substitute_rounds; round++) {
        const uint64_t active_before = active_variables(k);
        const uint64_t round_entry = e.meter(k);
        const ApplyResult current = default_substitute_round(k);
        const uint64_t round_spent = e.meter(k) - round_entry;
#ifdef TACTIX_ENABLE_RULE_JOURNAL
        substitute_rounds_run++;
        e.journal_rounds = substitute_rounds_run;
        e.journal_last_round_spent = round_spent;
#endif
        if (current == ApplyResult::Unsat) {
          ar = current;
          break;
        }
        if (current == ApplyResult::Ok)
          ar = current;
        const bool productive = active_variables(k) < active_before;
        if (!productive)
          break;
        if (!complete && round_spent > handed) {
          substitute_round_budget_break = true;
#ifdef TACTIX_ENABLE_RULE_JOURNAL
          e.journal_round_budget_break = true;
#endif
          break;
        }
      }
      if (watches_at_entry && !k.large_watches_connected &&
          ar != ApplyResult::Unsat &&
          substitute_reconnect_large_watches(k, trail_at_entry) ==
              ApplyResult::Unsat)
        ar = ApplyResult::Unsat;
      if (r.id < Stats::MAX_TIMED_RULES) {
        k.stats.rule_nanos[r.id] += now_nanos() - t0;
        k.stats.rule_calls[r.id]++;
      }
    } else {
      ar = metered_rule_apply(k, e.meter, [&] { return apply_rule(r, k); });
    }
  }
  if (factor_entry && k.factor_completed)
    factor_marked_watermark_ = k.factor_literals_marked;
  k.midround_budget = previous_midround_budget;
  k.work_budget = 0;
  k.factor_composite = false;
  const uint64_t spent = e.meter(k) - spent_before;
  e.tm.handed += handed;
  e.tm.spent += spent;
  if (spent > 0)
    e.doses++;
  if (spent > 0 &&
      (substitute ? !substitute_round_budget_break : spent <= handed)) {
    e.tm.completed++;
    e.binaries_mark = k.binary_ids.size();
    e.arena_mark = k.arena.size();
    e.root_fixed_mark = kernel_logical_root_fixed(k);
  }
  return ar;
}

DefaultInprocessScheduler::SlotStep
DefaultInprocessScheduler::run_batch_entry(Kernel &k, SlotEntry &e, const RuleVTable &r,
                               SlotPhaseCtx &ctx) {
  const uint64_t limit = e.limit;
  ctx.last_result = ApplyResult::NoOp;
  const bool substitute = !std::strcmp(r.name, "Substitute");
#ifdef TACTIX_ENABLE_RULE_JOURNAL
  e.journal_last_round_spent = 0;
  e.journal_rounds = 0;
  e.journal_round_budget_break = false;
#endif
  // Substitute has no call-entry effort gate in Kissat. Its first round is
  // mandatory and the round-local comparison lives in run_budgeted_batch.
  if (!substitute && e.meter && e.meter(k) > limit) {
    e.tm.dec_budget++;
    return SlotStep::Next;
  }
  const bool factor_entry = e.budget_aware && !std::strcmp(r.name, "Factor");
  if (factor_entry && factor_entry_declines(k, e))
    return SlotStep::Next;
  // The ordinary begin boundary is before Kissat's call-entry predicates.
  // This second observer-only boundary is the exact point after factordelay
  // and the cumulative marked-material watermark admit the call, but before
  // Factor changes representation or formula state.
  if (factor_entry)
    event_trace_slot_boundary(k, r.name, "admitted");
  if (e.closure && k.stats.conflicts > 0 &&
      k.binary_ids.size() <= e.binaries_mark &&
      kernel_logical_root_fixed(k) <= e.root_fixed_mark) {
    e.tm.dec_material++;
    return SlotStep::Next;
  }
  if (closure_delay_ && (e.closure || delay_spec(r.name)) &&
      k.stats.conflicts > 0 && e.delay_count > 0) {
    e.delay_count--;
    e.tm.dec_delay++;
    return SlotStep::Next;
  }
  if (!r.guard(k)) {
    e.tm.dec_guard++;
    return SlotStep::Next;
  }
  // Per-occurrence strategy parameters are posed for exactly this safe rule
  // application and restored before the scheduler advances. The reference
  // program carries monostate, so its legacy Kernel values and hot path remain
  // unchanged.
  std::optional<strategy::ScopedSubsumeForwardParameters> c1_parameters;
  std::optional<strategy::ScopedStrengthenParameters> c2_parameters;
  std::optional<strategy::ScopedCongruenceParameters> congruence_parameters;
  std::optional<strategy::ScopedInstantiateParameters> instantiate_parameters;
  std::optional<strategy::ScopedBackboneParameters> backbone_parameters;
  std::optional<strategy::ScopedVivifyParameters> vivify_parameters;
  if (const auto *p =
          std::get_if<strategy::SubsumeForwardParameters>(&e.parameters))
    c1_parameters.emplace(k, *p);
  else if (const auto *p =
               std::get_if<strategy::StrengthenParameters>(&e.parameters))
    c2_parameters.emplace(k, *p);
  else if (const auto *p =
               std::get_if<strategy::CongruenceParameters>(&e.parameters))
    congruence_parameters.emplace(k, *p);
  else if (const auto *p =
               std::get_if<strategy::InstantiateParameters>(&e.parameters))
    instantiate_parameters.emplace(k, *p);
  else if (const auto *p =
               std::get_if<strategy::BackboneParameters>(&e.parameters))
    backbone_parameters.emplace(k, *p);
  else if (const auto *p =
               std::get_if<strategy::VivifyParameters>(&e.parameters))
    vivify_parameters.emplace(k, *p);
  e.tm.admitted++;
  const DelaySpec *const dspec = delay_spec(r.name);
  const uint64_t yield_before = dspec ? dspec->yield(k) : 0;
  const uint64_t denom_before = dspec ? dspec->denom(k) : 0;
  const bool budgeted = e.meter && !e.dosed && e.budget_aware;
  const bool vivify_dose = budgeted && !std::strcmp(r.name, "Vivify");
  const bool forward_entry = ctx.group == SlotGroup::Eliminate &&
                             !std::strcmp(r.name, "Strengthen");
  const uint32_t forward_trail_from = k.propagate_head;
  ApplyResult ar;
  if (vivify_dose) {
    ar = run_vivify_dose(k, e, r, limit);
  } else if (budgeted) {
    ar = run_budgeted_batch(k, e, r, limit, factor_entry);
  } else {
    TickSinkScope sink(k, e.tick_counter);
    // Kissat's two preprocessing follow-ups call substitute with
    // `complete=true`: a productive rewrite can expose another binary SCC,
    // and the shipped `substituterounds=2` consumes that closure immediately.
    // Unbudgeted search-time calls retain the ordinary one-round contract.
    // Publish every round's roots/retirements before reconnecting watches.
    if (substitute) {
      const uint64_t t0 = now_nanos();
#ifdef TACTIX_ENABLE_RULE_JOURNAL
      // This policy-composed call no longer passes through apply_rule. Keep
      // its complete proof/reconstruction transaction and source currency,
      // including the final watch reconnection, in diagnostic builds only.
      ar = metered_rule_apply(k, journal_effort_meter(e, r), [&] {
        return journal_direct_rule(
            k, r.name,
            std::string("policy-complete-rounds=") +
                std::to_string(k.stats.conflicts == 0
                                   ? config().substitute_rounds
                                   : config().substitute_search_rounds),
            [&] {
              return default_substitute_complete(
                  k, k.stats.conflicts == 0
                         ? config().substitute_rounds
                         : config().substitute_search_rounds);
            });
      });
#else
      ar = default_substitute_complete(
          k, k.stats.conflicts == 0 ? config().substitute_rounds
                                    : config().substitute_search_rounds);
#endif
      if (r.id < Stats::MAX_TIMED_RULES) {
        k.stats.rule_nanos[r.id] += now_nanos() - t0;
        k.stats.rule_calls[r.id]++;
      }
    } else {
      ar = metered_rule_apply(k, journal_effort_meter(e, r),
                              [&] { return apply_rule(r, k); });
    }
  }
  ctx.last_result = ar;
  if (factor_entry)
    event_trace_target_state(k, "factor-stamps-pre",
        k.fresh_var_events.empty() ? 0 : k.fresh_var_events.back().end - k.fresh_var_events.back().first);
  heuristics_consume_rule_advice(k);
  if (factor_entry)
    event_trace_target_state(k, "factor-stamps-post", 0);
  // Match Kissat's post-Factor return point after sparse reconstruction and
  // fresh-variable heuristic adjustment, but before caller propagation or a
  // later inprocessing slot can change the semantic formula.
  if (factor_entry)
    event_trace_slot_boundary(k, r.name, "applied");
  if (e.closure) {
    e.binaries_mark = k.binary_ids.size();
    e.arena_mark = k.arena.size();
    e.root_fixed_mark = kernel_logical_root_fixed(k);
  }
  // Kissat bumps/reduces the named Congruence and Sweep delay ladders after
  // their preprocessing calls too.  Suppressing this update at conflict zero
  // made Tactix run the first search-time Congruence while Kissat consumed its
  // one-call delay.  Substitute has no Kissat delay object; retain its local
  // closure backoff only for search-time applications.
  const bool update_named_delay = dspec;
  const bool update_local_closure_delay = e.closure && k.stats.conflicts > 0;
  if (closure_delay_ &&
      (update_named_delay || update_local_closure_delay)) {
    bool unproductive;
    if (dspec) {
      const uint64_t yield = dspec->yield(k) - yield_before;
      const uint64_t denom =
          dspec->denom_delta ? dspec->denom(k) - denom_before : dspec->denom(k);
      const uint32_t permille = config().*(dspec->permille);
      unproductive = denom == 0 ||
                     yield * PERMILLE_SCALE < uint64_t(permille) * denom;
    } else {
      unproductive = ar != ApplyResult::Ok;
    }
    if (unproductive)
      e.delay_current += (e.delay_current < UINT32_MAX);
    else
      e.delay_current /= 2;
    e.delay_count = e.delay_current;
  }
  if (ar == ApplyResult::Ok)
    e.tm.ok++;
  if (ar == ApplyResult::Unsat || k.inconsistent) {
    ctx.phase_unsat = true;
    return SlotStep::Stop;
  }
  if (forward_entry) {
    // C2's internal partial scan can consume the cursor while leaving full
    // clause consequences pending. Publish its roots in assignment order,
    // then close the reconnected suffix before any following slot observes it.
    heuristics_consume_root_assignments(k, forward_trail_from);
    const size_t closure_trail_from = k.trail.size();
    const ApplyResult closure =
        strengthen_reconnect_and_flush(k, forward_trail_from);
    heuristics_consume_root_assignments(k, closure_trail_from);
    if (closure == ApplyResult::Unsat) {
      ctx.phase_unsat = true;
      return SlotStep::Stop;
    }
  }
  if (ar != ApplyResult::Ok)
    return SlotStep::Next;
  ctx.round_changed = true;
  const ApplyResult propagation = default_propagate(k, "inprocess-batch");
  if (propagation == ApplyResult::Unsat) {
    ctx.phase_unsat = true;
    return SlotStep::Stop;
  }
  return SlotStep::Next;
}

int DefaultInprocessScheduler::run_structured_root(
    Kernel &k, volatile sig_atomic_t *stop) {
  using strategy::InvocationStatus;
  if (structured_root_consumed_ || k.stats.conflicts)
    return 0;
  structured_root_consumed_ = true;
  ++structured_root.runs;
  const bool large_domain =
      k.nvars > config().structured_root_large_domain_limit;
  const bool bounded_backtracking =
      k.nvars >= config().structured_root_backtracking_domain_limit;
  const auto &stages =
      large_domain
          ? config().structured_root_large_domain_stages
          : bounded_backtracking
                ? config().structured_root_bounded_backtracking_stages
                : config().structured_root_stages;
  if (stages.empty())
    return 0;
  if (k.proof && !k.proof->dsr()) {
    ++structured_root.proof_format_declines;
    structured_root.terminal = InvocationStatus::Inapplicable;
    return 0;
  }
  InprocessScope scope(k);
  const auto hard_discovery_limit =
      config().structured_root_sr_discovery_budget;
  uint64_t progress_window = 0;
  const bool progress_feedback =
      config().structured_root_progress_feedback &&
      (!large_domain ||
       config().structured_root_large_domain_progress_feedback);
  if (progress_feedback) {
    const uint64_t scale =
        config().structured_root_progress_ticks_per_variable;
    const uint64_t variable_window =
        scale && k.nvars > UINT64_MAX / scale
            ? UINT64_MAX
            : scale * static_cast<uint64_t>(k.nvars);
    progress_window =
        std::max(config().structured_root_progress_minimum_ticks,
                 variable_window);
  }
  strategy::WorkLimit initial_discovery_limit = hard_discovery_limit;
  if (progress_window &&
      (hard_discovery_limit.is_unlimited() ||
       hard_discovery_limit.amount() > progress_window))
    initial_discovery_limit = strategy::WorkLimit::bounded(progress_window);
  uint64_t granted_discovery_limit =
      initial_discovery_limit.is_unlimited()
          ? UINT64_MAX
          : initial_discovery_limit.amount();
  strategy::Allowance sr_discovery_allowance(
      strategy::WorkUnit::SrDiscoveryTicks, initial_discovery_limit);
  structured_root.sr_discovery_progress_window = progress_window;
  structured_root.stages.resize(stages.size());
  bool prior_stage_progress = false;
  const uint64_t unique_literal_amo_before =
      k.stats.sr_unique_literal_amo_binaries;
  const uint64_t nonforcing_cuts_before =
      k.stats.sr_nonforcing_cuts_declined;
  for (size_t index = 0; index < stages.size(); ++index) {
    const auto stage = DefaultStrategyConfig::structured_root_stage_after_feedback(
        stages[index], prior_stage_progress,
        k.stats.sr_unique_literal_amo_binaries > unique_literal_amo_before,
        k.stats.sr_nonforcing_cuts_declined > nonforcing_cuts_before);
    auto &telem = structured_root.stages[index];
    ++telem.runs;
    strategy::OnlineStrategySequence executor;
    std::string error;
    if (!executor.configure(stage, 1,
                            strategy::ReconfigureMode::ResetRuntime, &error)) {
      telem.terminal = structured_root.terminal = InvocationStatus::InvalidRequest;
      return 0;
    }
    const uint64_t started = now_nanos();
    const auto finish = [&] {
      telem.sequence_passes = executor.rounds();
      telem.nanos += now_nanos() - started;
      structured_root.sequence_passes += telem.sequence_passes;
      structured_root.nanos += telem.nanos;
    };
    while (!executor.complete()) {
      // Rule-local probing and BVE snapshots must end with each application;
      // collection may relocate clauses at the following atomic boundary.
      assert(k.level == 0 && !k.probing.recording && !k.bve_occurrence_count_image);
      const auto advanced =
          executor.advance(
              k, stop, &sr_discovery_allowance,
              strategy::DiscoveryFeedbackPolicy{
                  progress_window,
                  hard_discovery_limit.is_unlimited()
                      ? UINT64_MAX
                      : hard_discovery_limit.amount()});
      structured_root.sr_discovery_ticks =
          sr_discovery_allowance.consumed();
      structured_root.sr_discovery_overflow =
          sr_discovery_allowance.accounting_overflow();
      ++telem.advances;
      ++structured_root.advances;
      telem.applications += advanced.applications;
      structured_root.applications += advanced.applications;
      telem.effective += advanced.made_rule_progress;
      structured_root.effective += advanced.made_rule_progress;
      uint64_t discovery_credit_units =
          advanced.discovery_progress_units >
                  UINT64_MAX - uint64_t(advanced.made_rule_progress)
              ? UINT64_MAX
              : advanced.discovery_progress_units +
                    uint64_t(advanced.made_rule_progress);
      if (advanced.discovery_entry_required &&
          discovery_credit_units != UINT64_MAX)
        ++discovery_credit_units;
      if (progress_window && discovery_credit_units &&
          !sr_discovery_allowance.accounting_overflow()) {
        const uint64_t consumed = sr_discovery_allowance.consumed();
        const uint64_t base = std::max(granted_discovery_limit, consumed);
        const uint64_t credit =
            discovery_credit_units &&
                    progress_window > UINT64_MAX / discovery_credit_units
                ? UINT64_MAX
                : progress_window * discovery_credit_units;
        uint64_t renewed = credit > UINT64_MAX - base
                               ? UINT64_MAX
                               : base + credit;
        if (!hard_discovery_limit.is_unlimited())
          renewed = std::min(renewed, hard_discovery_limit.amount());
        if (renewed > granted_discovery_limit) {
          granted_discovery_limit = renewed;
          sr_discovery_allowance.set_limit(
              strategy::WorkLimit::bounded(renewed));
          ++structured_root.sr_discovery_renewals;
        }
      }
      telem.terminal = structured_root.terminal = advanced.status;
      switch (advanced.status) {
      case InvocationStatus::Completed:
      case InvocationStatus::NoChange:
      case InvocationStatus::ScopedFixpoint:
        continue;
      case InvocationStatus::Sat:
        finish();
        return 10;
      case InvocationStatus::Unsat:
        finish();
        return 20;
      case InvocationStatus::BudgetExhausted:
        if (stage.on_budget_exhaustion == strategy::BudgetExhaustionPolicy::Continue ||
            (stage.on_budget_exhaustion == strategy::BudgetExhaustionPolicy::FinishRoundThenStop &&
             !executor.complete()))
          continue;
        finish();
        return 0;
      case InvocationStatus::Interrupted:
      case InvocationStatus::ResourceExhausted:
      case InvocationStatus::Inapplicable:
      case InvocationStatus::InvalidRequest:
      case InvocationStatus::StaleRequest:
      case InvocationStatus::AccountingError:
        // Preserve the visible status and every committed atomic transition.
        // No stale payload is retried or silently advanced by the scheduler.
        finish();
        return 0;
      case InvocationStatus::Conflict:
        std::fprintf(stderr, "c ERROR: root preprocessing returned status %u\n",
                     static_cast<unsigned>(advanced.status));
        std::abort();
      }
    }
    finish();
    prior_stage_progress |= telem.effective != 0;
  }
  return k.inconsistent ? 20 : 0;
}

int DefaultInprocessScheduler::run_initial_fast_elimination(
    Kernel &k, volatile sig_atomic_t *stop) {
  assert(config().initial_fast_elimination);
  assert(!initial_fast_elimination_active_);
  initial_fast_elimination_active_ = true;
  initial_fast_elimination_discovery_ticks_ = 0;
  initial_fast_elimination_budget_exhausted_ = false;
  initial_fast_elimination_attempted_.assign(k.nvars, 0);
  initial_fast_elimination_marks_.assign(2 * static_cast<size_t>(k.nvars), 0);
  const uint64_t eliminated_before = k.stats.bve_eliminated;
  const uint64_t resolutions_before = k.stats.bve_resolutions;
  const uint64_t started = now_nanos();
  const int result = run_phase(k, SlotGroup::Eliminate, stop);
  k.stats.fastel_nanos += now_nanos() - started;
  k.stats.fastel_eliminated += k.stats.bve_eliminated - eliminated_before;
  k.stats.fastel_resolutions += k.stats.bve_resolutions - resolutions_before;
  initial_fast_elimination_attempted_.clear();
  initial_fast_elimination_marks_.clear();
  initial_fast_elimination_active_ = false;
  return result;
}

int DefaultInprocessScheduler::run_phase(Kernel &k, SlotGroup group,
                                  volatile sig_atomic_t *stop) {
  SlotClock &clock = group == SlotGroup::Probe ? probe_clock : elim_clock;
  clock.reductions_mark = k.stats.reductions;
  clock.marks_mark = k.stats.bve_marks;
  clock.fixed_mark = kernel_logical_root_fixed(k);
  clock.blocked = false; // a new blocking episode may now be counted
  forward_pair_limit_ = 0;
  bve_ran_this_phase_ = false;
  // Kissat constructs one embedded Kitten at the beginning of the complete
  // `eliminate()` invocation and releases it after all of that invocation's
  // elimination rounds. `run_phase(Eliminate)` is that lifetime boundary;
  // its outer fixpoint rounds must reuse the same deterministic generator
  // sequence instead of restarting it at each BVE slot visit.
  if (group == SlotGroup::Eliminate && !initial_fast_elimination_active_)
    k.bve_definition_session = k.bve_definition_session + 1;
  k.bve_occurrence_limit = config().bve_occurrence_limit;
  k.congruence_parameters = config().congruence_parameters;
  k.instantiate_parameters = config().instantiate_parameters;
  k.backbone_parameters = config().backbone_parameters;
  k.bce_occ_limit = config().bce_parameters.occurrence_limit;
  k.ternary_occ_limit = config().ternary_parameters.occurrence_limit;
  k.ternary_max_add_percent =
      config().ternary_parameters.maximum_add_percent;
  k.factor_size = config().factor_parameters.maximum_clause_size;
  k.factor_bound = config().factor_parameters.growth_bound;
  k.factor_cand_rounds = config().factor_parameters.candidate_rounds;
  k.factor_composite = config().factor_parameters.composite;
  k.factor_demote_fresh = config().factor_parameters.demote_fresh;
  k.transitive_early_exit = config().transitive_parameters.early_exit;
  k.transitive_live_meter = config().transitive_parameters.live_meter;
  k.transitive_budget_checked =
      config().transitive_parameters.checked_budget_meter;
  k.subst_demote = config().substitute_parameters.demote_substituted;
  k.vivify_scope = config().vivify_parameters.scope;
  k.vivify_reuse = config().vivify_parameters.reuse;
  k.vivify_flush = config().vivify_parameters.flush;
  k.vivify_irredundant_sort_ratio =
      config().vivify_parameters.irredundant_sort_ratio;
  k.bve_clause_size_limit = config().bve_clause_size_limit;
  k.bve_resolvent_count_limit = UINT32_MAX;
  k.bve_xor_arity_limit = config().bve_xor_arity_limit;
  k.bve_resolvent_size_limit = config().bve_resolvent_size_limit;
  k.bve_backward_occurrence_limit =
      config().bve_backward_occurrence_limit;
  k.bve_definition_budget = config().bve_definition_budget;
  k.bve_definition_cores = config().bve_definition_cores;
  k.bve_definition_core_budget_multiplier =
      config().bve_definition_core_budget_multiplier;
  k.bve_backward = config().bve_backward;
  factor_bound_snapshot_ =
      couple_factor_bound_ ? bve_level_ : 0;
  const uint64_t phase_props_at_entry = k.stats.propagations;
  const uint64_t phase_nanos_at_entry = now_nanos();
  k.stats.inprocess_phases++;
  // Probe sets Kissat's probing flag before root preparation; Eliminate
  // still uses ordinary search propagation here. Enter the common simplifier
  // scope only after that boundary so Eliminate credits search ticks and
  // saves phases for any newly exposed root implications.
  std::optional<InprocessScope> entry_probe_scope;
  if (group == SlotGroup::Probe)
    entry_probe_scope.emplace(k);
  if (k.level > 0 && restart_guard(k)) {
    // `kissat_probe` sets `solver->probing` before `probe` enters
    // `kissat_backtrack_propagate_and_flush_trail`; the target/best updater
    // explicitly returns in probing mode.  Eliminate enters the same root
    // restart without that flag and therefore retains the snapshot.
    if (group != SlotGroup::Probe)
      heuristics_update_target_phases(k);
    // Probe and Eliminate use Kissat's shared root-backtrack primitive, not
    // `kissat_restart`: entering an inprocessing phase must not advance the
    // focused-restart count or its logarithmic cadence.
    (void)default_direct_rule(k, "Restart", "keep-level=0;inprocess=1",
                              [&] { return restart_backtrack_to(k, 0); });
  }
  // Retained out-of-order root assignments must be rescanned after their
  // transient blockers disappear, before dense construction or rule admission.
  // Reuse the rule's root proof path, including a possible terminal conflict.
  const ApplyResult root_result = default_propagate(
      k, group == SlotGroup::Probe ? "probe-root" : "eliminate-root");
  if (root_result == ApplyResult::Unsat)
    return 20;
  assert(root_result == ApplyResult::Ok && k.level == 0 &&
         kernel_propagation_fixpoint(k));
  k.unflushed_root = 0;
  entry_probe_scope.reset();
  InprocessScope inprocess_scope(k);
  // Kissat has physically cleared the previously propagated root trail at
  // this point. Preserve Tactix's immutable prefix but remember the equivalent
  // beginning for its sparse-resume reset below.
  const uint32_t sparse_resume_trail =
      static_cast<uint32_t>(k.trail.size());
  if (group == SlotGroup::Eliminate)
    event_trace_eliminate_cleanup(k, "entry");
  // Only the Eliminate pipeline contains BVE, the sole consumer of Kissat's
  // mixed binary/large connection stream. Probe consumers share the ordinary
  // large occurrence image and do not instantiate a duplicate formula-wide
  // ordering representation. Constructing either cache is not itself a
  // physical sparse-watch transition. Eliminate owns that transition here:
  // kissat_enter_dense_mode both disconnects large watches and deletes every
  // repeated binary before occurrences are built (eliminate.c). Probe rules
  // retain their own entry/exit transitions. Keeping sparse watches throughout
  // Eliminate otherwise publishes and scans a second, obsolete large image.
  if (group == SlotGroup::Eliminate)
    kernel_flush_large_watches(k);
  k.stats.inprocess_entry_nanos += now_nanos() - phase_nanos_at_entry;
  default_factor_match_.bound = std::max(k.factor_bound, factor_bound_snapshot_); // see DefaultFactorMatch
  k.factor_selection = factor_match ? factor_match : &default_factor_match_;
  if (factor_match)
    factor_match->set_bound(factor_bound_snapshot_);
  // Structured startup owns rule-local occurrence scopes. Construct the
  // ordinary Probe index only after it finishes, so every SR insertion and
  // collection does not maintain an index that no startup consumer needs.
  const int structured_result = group == SlotGroup::Probe
                                    ? run_structured_root(k, stop) : 0;
  if (structured_result == 10) {
    // No pipeline occurrence image has been attached yet. Preserve the
    // terminal model and release only the phase-owned guidance handoff.
    k.factor_selection = nullptr;
    k.stats.inprocess_propagations += k.stats.propagations - phase_props_at_entry;
    k.stats.inprocess_nanos += now_nanos() - phase_nanos_at_entry;
    return 10;
  }
  const bool structured_unsat = structured_result == 20;
  const uint64_t dense_connect_started = now_nanos();
  kernel_dense_connect(k, occurrence_index_, group == SlotGroup::Eliminate);
  k.stats.inprocess_dense_connect_nanos +=
      now_nanos() - dense_connect_started;
  SlotPhaseCtx ctx{group, stop};
  ctx.phase_unsat = structured_unsat;
  const std::vector<RuleVTable> &rules = tactix_rules();
  uint64_t active_before = active_variables(k);
  size_t sweep_retired_begin = SIZE_MAX;
  size_t sweep_substituted_begin = SIZE_MAX;
  const int rounds = initial_fast_elimination_active_
                         ? static_cast<int>(
                               config().initial_fast_elimination_rounds)
                         : k.stats.conflicts == 0
                               ? 1
                               : static_cast<int>(config().phase_rounds);
  const uint64_t slot_loop_started = now_nanos();
  for (ctx.outer = 0;
       ctx.outer < rounds && !ctx.phase_unsat &&
       !(stop && *stop);
       ctx.outer++) {
    // `SET_EFFORT_LIMIT(forward_steps)` lives inside Kissat's
    // `forward_subsume_all_clauses`, which is called once per elimination
    // round.  The search-tick reference is shared, but each round receives a
    // fresh delta starting at its current forward_steps counter.  Keep the C1
    // diagnostic decomposition and fused C2 on one allowance within a round,
    // then discard that absolute ceiling before the next round.
    forward_pair_limit_ = 0;
    ctx.round_changed = false;
    k.subsume_complete = true;
    k.strengthen_complete = true;
    for (size_t slot = 0; slot < entries.size(); slot++) {
      SlotEntry &e = entries[slot];
      if (e.group != group)
        continue; // the other clock's pipeline: not offered here at all
      const RuleVTable &r = rules[e.rule];
      if (initial_fast_elimination_active_ && std::strcmp(r.name, "BVE"))
        continue;
      if (stop && *stop)
        break; // §6: leave the phase promptly; cleanup runs at its exit
      e.tm.occasions++;
      const bool followup = followup_admissible(e, k, ctx);
      slot_trace_entry(k, e, r, ctx.outer);
      if (!followup) {
        e.tm.dec_preprocess++;
        continue;
      }
      if (!slot_entry_admissible(e, k, ctx))
        continue;
      const bool substitute = !std::strcmp(r.name, "Substitute");
      if (e.enabled && e.meter) {
        const bool forward_round = e.meter == meter_forward_pair;
        if (substitute || group == SlotGroup::Probe || ctx.outer == 0 ||
            forward_round) {
          set_entry_limit(e, k);
        }
      }
#ifdef TACTIX_ENABLE_RULE_JOURNAL
      const std::string invocation =
          std::string("group=") +
          (group == SlotGroup::Probe ? "probe" : "eliminate") +
          ";phase=" + std::to_string(clock.rounds) +
          ";round=" + std::to_string(ctx.outer) +
          ";slot=" + std::to_string(slot) +
          ";occasion=" + std::to_string(e.tm.occasions);
      const bool journal_invocation =
          rule_journal_wants(k, r.name, invocation);
      const auto invocation_meter = journal_effort_meter(e, r);
      const uint64_t invocation_entry =
          journal_invocation && invocation_meter ? invocation_meter(k) : 0;
      const uint64_t invocation_pre_digest =
          journal_invocation ? rule_journal_digest(k) : 0;
      const uint64_t invocation_formula_epoch = k.arena_generation;
      const uint64_t invocation_root_epoch = k.touch_fixed_head;
      const SlotEntry::Telem invocation_tm = e.tm;
#endif
#ifdef TACTIX_ENABLE_EVENT_TRACE
      k.diagnostic_policy_inprocess_bytes =
          diagnostic_non_dense_storage_bytes();
#endif
      event_trace_slot_boundary(k, r.name, "begin");
      const bool sweep = !std::strcmp(r.name, "Sweep");
      const size_t trail_before = k.trail.size();
      const uint64_t root_assignments_before = k.stats.root_assignments;
      const size_t retired_before = k.retired_events.size();
      const size_t substituted_before = sweep ? k.substituted_events.size() : 0;
      const bool dosed_instance = e.dosed && r.instances && r.apply_instance;
      const SlotStep step = dosed_instance ? run_dosed_entry(k, e, r, ctx)
                                           : run_batch_entry(k, e, r, ctx);
      // Kissat's root assignment primitive marks a variable fixed and removes
      // it from both decision rankings immediately.  Formula rules remain
      // policy-agnostic in Tactix, so publish that same lifecycle at the rule
      // boundary, before consuming the rule's eliminated/substituted events.
      // Substitute has already consumed roots/retirements per SCC round;
      // this boundary also consumes roots from its final watch reconnection,
      // after those retirements (substitute.c substitute_rounds).
      // Dosed entries consume direct and propagated roots at each candidate
      // boundary inside run_dosed_entry.  Do not rescan the whole rule-local
      // trail here; batch entries still publish their roots at this boundary.
      if (!dosed_instance &&
          k.stats.root_assignments != root_assignments_before)
        heuristics_consume_root_assignments(k, trail_before);
#ifdef TACTIX_ENABLE_RULE_JOURNAL
      if (journal_invocation) {
        const bool admitted = e.tm.admitted != invocation_tm.admitted;
        const char *decline = "none";
        if (!admitted) {
          if (e.tm.dec_budget != invocation_tm.dec_budget)
            decline = "budget";
          else if (e.tm.dec_guard != invocation_tm.dec_guard)
            decline = "guard";
          else if (e.tm.dec_delay != invocation_tm.dec_delay)
            decline = "delay";
          else if (e.tm.dec_material != invocation_tm.dec_material)
            decline = "material";
          else if (e.tm.dec_warmup != invocation_tm.dec_warmup)
            decline = "warmup";
          else if (e.tm.dec_profile != invocation_tm.dec_profile)
            decline = "profile";
          else
            decline = "scheduler";
        }
        const bool bounded = e.meter != nullptr;
        const uint64_t exit =
            invocation_meter ? invocation_meter(k) : invocation_entry;
        const uint64_t delta = exit - invocation_entry;
        const uint64_t terminal_spent = substitute
                                            ? e.journal_last_round_spent
                                            : delta;
        const uint64_t overshoot = bounded && terminal_spent > e.journal_allowance
                                       ? terminal_spent - e.journal_allowance
                                       : 0;
        const uint64_t post_digest = rule_journal_digest(k);
        const char *terminal =
            !bounded ? "unbounded"
            : overshoot ? "overshot"
                      : terminal_spent == e.journal_allowance ? "exhausted"
                                                              : "within";
        RuleJournalRecord record;
        record.kind = "schedule";
        record.rule = r.name;
        record.event = "inprocess-invocation";
        record.candidate = invocation;
        record.trigger = "default-inprocess-scheduler";
        record.context =
            std::string("currency=") + effort_currency(r.name) +
            ";reference=" + std::to_string(e.journal_reference) +
            ";allowance=" + std::to_string(e.journal_allowance) +
            ";bounded=" + (bounded ? "1" : "0") +
            ";entry=" + std::to_string(invocation_entry) +
            ";exit=" + std::to_string(exit) +
            ";delta=" + std::to_string(delta) +
            ";overshoot=" + std::to_string(overshoot) +
            ";terminal=" + terminal +
            (substitute
                 ? ";rounds=" + std::to_string(e.journal_rounds) +
                       ";last-round=" +
                       std::to_string(e.journal_last_round_spent) +
                       ";round-budget-break=" +
                       (e.journal_round_budget_break ? "1" : "0")
                 : "");
        record.formula_epoch = invocation_formula_epoch;
        record.root_epoch = invocation_root_epoch;
        record.pre_digest = invocation_pre_digest;
        record.guards = std::string("admitted=") + (admitted ? '1' : '0');
        record.antecedents = "slot-ledger";
        record.outcome = admitted ? journal_result(ctx.last_result) : "declined";
        record.decline = decline;
        record.deltas = invocation_pre_digest == post_digest
                            ? "none"
                            : "state-digest-change";
        record.witnesses = "rule-owned";
        record.effort = delta;
        record.budget = bounded ? e.limit : 0;
        record.post_digest = post_digest;
        rule_journal_emit(k, record);
      }
#endif
      if (!std::strcmp(r.name, "Congruence"))
        ctx.congruence_changed = ctx.last_result == ApplyResult::Ok;
      if (sweep) {
        ctx.sweep_changed = ctx.last_result == ApplyResult::Ok;
        if (ctx.sweep_changed) {
          sweep_retired_begin = retired_before;
          sweep_substituted_begin = substituted_before;
        } else if (sweep_retired_begin == SIZE_MAX) {
          heuristics_consume_retirements(k);
        }
      } else {
        if (substitute && sweep_retired_begin != SIZE_MAX) {
          // Kissat's post-Sweep Substitute scans one union containing both the
          // representatives proved by Sweep and any older SCC exposed by
          // their binaries.  Sweep has already ordered its own portion;
          // extend that same scan boundary across this mandated follow-up
          // before H consumes either portion at this call boundary.
          // Canonical Substitute already appends each SCC round in import
          // order. Sweep no longer retires inline; sorting this suffix would
          // move later-round removals ahead of earlier-round removals.
          sweep_retired_begin = sweep_substituted_begin = SIZE_MAX;
        }
        if (sweep_retired_begin == SIZE_MAX) {
          // All other Kissat rule-local eliminations are active-flag
          // transitions owned by that call.  Do not let their arbitrary heap
          // removals drift to phase exit.  A productive Sweep is the sole
          // exception: its inline rewrites deliberately wait for the
          // mandatory follow-up Substitute to retire the complete
          // import-ordered union.
          heuristics_consume_retirements(k);
        }
      }
#ifdef TACTIX_ENABLE_EVENT_TRACE
      k.diagnostic_policy_inprocess_bytes =
          diagnostic_non_dense_storage_bytes();
#endif
      event_trace_slot_boundary(k, r.name, "end");
      if (step == SlotStep::Stop)
        break;
    }
    if (ctx.eliminate_limit_reached)
      break;
    const bool subsume_pending =
        group == SlotGroup::Eliminate &&
        config().hold_subsume_until_eliminate &&
        (!k.subsume_complete || !k.strengthen_complete);
    if (!ctx.round_changed && subsume_pending)
      k.stats.subsume_holds++;
    const uint64_t active_now = active_variables(k);
    if (active_now == active_before && !subsume_pending)
      break; // outer fixpoint: the round retired and created nothing
    active_before = active_now;
  }
  k.stats.inprocess_slot_loop_nanos += now_nanos() - slot_loop_started;
  const uint64_t phase_exit_started = now_nanos();
  if (group == SlotGroup::Eliminate && !ctx.phase_unsat)
    event_trace_eliminate_cleanup(k, "before");
  // Kissat collects the arena only inside an Eliminate round (eliminate.c:519,
  // mirrored by the BVE round above) and at Reduce (reduce.c:202).  A Probe
  // phase whose dosed entry applied (TransitiveReduce, HyperBinaryRes) leaves
  // no arena garbage of its own and must not collect: a collection resets the
  // eager-subsumption register and compacts the arena, both search-visible.
  // Eliminate's sparse-resume pass below performs the reference's single
  // arena-order collection of every root-satisfied or retired-variable large
  // clause.  Other groups retain the generic redundant-retirement safeguard.
  if (!ctx.phase_unsat && group != SlotGroup::Eliminate)
    kernel_flush_retired_redundant(k);
  heuristics_consume_retirements(k);
  kernel_dense_disconnect(k);
  // Only Eliminate reconnects at the pipeline level (eliminate.c:587-589).
  // `probe.c` has no rewatch of its own: each dense-mode rule flushes large
  // watches on entry and reconnects on exit (vivify.c:1265/1276,
  // substitute.c:594, dense.c:105/217), and the pipeline returns to search
  // carrying the pose the last sparse probing propagation left. A rewatch here
  // re-sorts every watched pair, refreshes every cached blocker and resets
  // every replacement-search cursor, erasing the stale hints Kissat keeps
  // (benchmarks/reports/2026-09-02-unit-cost-and-fidelity-stack.md 3.40).
  // The full dense-mode exit corresponds to Kissat's arena-order reconnect.
  // Packed Tactix replacements replay their persistent source positions, as
  // every rule-local reconnect does, until collection materializes the order.
  if (group == SlotGroup::Eliminate || !k.large_watches_connected)
    kernel_rebuild_large_watches(k, group == SlotGroup::Eliminate);
  if (group == SlotGroup::Eliminate && !ctx.phase_unsat) {
    // dense.c::kissat_resume_sparse_mode resets propagation after reconnecting
    // and, because Eliminate is not a probing scope, deliberately uses
    // kissat_search_propagate. Its scan cost therefore contributes to the
    // stable-mode and inprocessing `search_ticks` currency even though the
    // enclosing simplifier remains active.
    const ApplyResult replay = default_resume_sparse_propagation(
        k, sparse_resume_trail, /*charge_search_ticks=*/true);
    if (replay == ApplyResult::Unsat || k.inconsistent)
      ctx.phase_unsat = true;
    else
      assert(replay == ApplyResult::Ok);
  }
  if (group == SlotGroup::Eliminate && !ctx.phase_unsat)
    event_trace_eliminate_cleanup(k, "after");
  k.factor_selection = nullptr;
  k.stats.inprocess_propagations +=
      k.stats.propagations - phase_props_at_entry;
  const uint64_t phase_finished = now_nanos();
  k.stats.inprocess_exit_nanos += phase_finished - phase_exit_started;
  k.stats.inprocess_nanos += phase_finished - phase_nanos_at_entry;
  if (group == SlotGroup::Eliminate && bve_ran_this_phase_ &&
      !initial_fast_elimination_active_ && !ctx.phase_unsat) {
    BveBoundPolicy &bramp = bve_bound ? *bve_bound : default_bve_ramp_;
    const uint32_t last = bramp.num_passes() - 1;
    const uint32_t blim = bramp.bound(last);
    // Pinned Kissat releases the round schedule before final bookkeeping;
    // its outer last_round_eliminated is zero (the round counter shadows it).
    // Every consistent engaged phase therefore advances, even on a quota cut.
    // Preserve that policy contract directly, without copying the shadowing.
    if (bve_level_idx_ >= last) {
      clock.marks_mark = k.stats.bve_marks;
      clock.fixed_mark = kernel_logical_root_fixed(k);
      // Consume added material only at the native maximum-bound exit, never
      // at generic phase entry or when merely advancing the bound ladder.
      clock.material_mark = k.subsume_material_count;
    } else {
      bve_level_ = std::min(bramp.bound(++bve_level_idx_), blim);
      // eliminate.c::try_to_eliminate_all_variables_again sets the eliminate
      // flag on every variable whenever the bound grows.  Fixed/eliminated
      // variables are filtered when the next schedule is built.
      std::fill(k.bve_retry.begin(), k.bve_retry.end(), uint8_t{1});
      clock.marks_mark = 0;
      clock.fixed_mark = 0;
    }
  }
  // `kissat_probe_initially` does not update `last.ticks.probe`; the first
  // search-time Probe phase therefore measures effort from search tick zero.
  // Only a completed post-search Probe phase advances that anchor.
  if (!initial_fast_elimination_active_ &&
      (group != SlotGroup::Probe || k.stats.conflicts))
    clock.anchor = search_ticks(k);
  if (ctx.phase_unsat)
    return 20;
  if (!initial_fast_elimination_active_) {
    clock.rounds++;
    update_limit(k, group);
  }
  return 0;
}

void DefaultInprocessScheduler::set_entry_limit(SlotEntry &e, Kernel &k) {
  const std::vector<RuleVTable> &rules = tactix_rules();
  const SlotClock &clock =
      e.group == SlotGroup::Probe ? probe_clock : elim_clock;
  const uint64_t now = search_ticks(k);
  uint64_t reference = 0;
  if (now >= clock.anchor)
    reference = now - clock.anchor;
  else
    e.tm.wrapped++; // see Telem::wrapped
  const bool substitute =
      !std::strcmp(rules[e.rule].name, "Substitute");
  if (k.stats.conflicts == 0)
    reference = config().preprocess_initial_ticks;
  else if (!substitute && reference < config().minimum_effort_ticks)
    reference = config().minimum_effort_ticks;
  const uint64_t delta = scale_permille(reference, e.permille);
  e.limit = e.meter(k) + delta;
#ifdef TACTIX_ENABLE_RULE_JOURNAL
  e.journal_reference = reference;
#endif
  if (std::getenv("TACTIX_SLOT_TRACE"))
    std::fprintf(stderr,
                 "[slot-limit] %s now=%llu anchor=%llu reference=%llu "
                 "permille=%u delta=%llu meter=%llu\n",
                 rules[e.rule].name, (unsigned long long)now,
                 (unsigned long long)clock.anchor,
                 (unsigned long long)reference, e.permille,
                 (unsigned long long)delta,
                 (unsigned long long)e.meter(k));
  if (e.meter == meter_forward_pair) {
    if (forward_pair_limit_)
      e.limit = forward_pair_limit_;
    else
      forward_pair_limit_ = e.limit;
  }
  // Kissat's `factoriniticks` belongs to the first factorization invocation,
  // including the preprocessing call from `probe_initially`.  Restricting it
  // to post-search phases silently replaced the shipped 700M first dose with
  // 50 permille of the 10M preprocessing reference (only 0.5M ticks).
  if (e.doses == 0 && e.budget_aware &&
      !std::strcmp(rules[e.rule].name, "Factor"))
    e.limit = e.meter(k) + factor_init_ticks_;
#ifdef TACTIX_ENABLE_RULE_JOURNAL
  const uint64_t entry = e.meter(k);
  e.journal_allowance = e.limit >= entry ? e.limit - entry : 0;
#endif
}

void DefaultInprocessScheduler::report(const Kernel &k) const {
  std::printf("c structured-root runs %llu advances %llu applications %llu "
              "effective %llu passes %llu seconds %.6f terminal %u "
              "proof-format-declines %llu sr-discovery-ticks %llu "
              "sr-discovery-window %llu renewals %llu "
              "sr-discovery-overflow %u\n",
              (unsigned long long)structured_root.runs,
              (unsigned long long)structured_root.advances,
              (unsigned long long)structured_root.applications,
              (unsigned long long)structured_root.effective,
              (unsigned long long)structured_root.sequence_passes,
              structured_root.nanos / 1e9,
              static_cast<unsigned>(structured_root.terminal),
              (unsigned long long)structured_root.proof_format_declines,
              (unsigned long long)structured_root.sr_discovery_ticks,
              (unsigned long long)structured_root.sr_discovery_progress_window,
              (unsigned long long)structured_root.sr_discovery_renewals,
              static_cast<unsigned>(structured_root.sr_discovery_overflow));
  for (size_t i = 0; i < structured_root.stages.size(); ++i) {
    const auto &stage = structured_root.stages[i];
    std::printf("c structured-stage %zu runs %llu advances %llu applications %llu "
                "effective %llu passes %llu seconds %.6f terminal %u\n", i,
                (unsigned long long)stage.runs,
                (unsigned long long)stage.advances,
                (unsigned long long)stage.applications,
                (unsigned long long)stage.effective,
                (unsigned long long)stage.sequence_passes, stage.nanos / 1e9,
                static_cast<unsigned>(stage.terminal));
  }

  std::printf("c meters      probe %llu backbone %llu vivify %llu "
              "instantiate %llu | global ticks %llu\n",
              (unsigned long long)k.stats.probe_ticks,
              (unsigned long long)k.stats.backbone_ticks,
              (unsigned long long)k.stats.vivify_ticks,
              (unsigned long long)k.stats.instantiate_ticks,
              (unsigned long long)k.stats.ticks);
  const std::vector<RuleVTable> &rules = tactix_rules();
  std::printf("c slot-order  authored");
  for (const SlotEntry &e : entries)
    std::printf(" %s", rules[e.rule].name);
  std::printf("\n");
  std::printf("c slot-clock  probe phases %llu next %llu blocked %llu | "
              "eliminate phases %llu next %llu blocked %llu | bve-marks %llu\n",
              (unsigned long long)probe_clock.rounds,
              (unsigned long long)probe_clock.next_conflicts,
              (unsigned long long)probe_clock.blocked_episodes,
              (unsigned long long)elim_clock.rounds,
              (unsigned long long)elim_clock.next_conflicts,
              (unsigned long long)elim_clock.blocked_episodes,
              (unsigned long long)k.stats.bve_marks);
  for (const SlotEntry &e : entries) {
    if (!e.dosed)
      continue;
    std::printf("c cand-order  %-18s arm %-12s cursor %s | lists %llu "
                "candidates %llu rotated %llu advanced %llu ranked %llu "
                "moved %llu\n",
                rules[e.rule].name, candidate_order_name(e.order),
                e.cursor_enabled ? "on " : "off",
                (unsigned long long)e.ord.lists,
                (unsigned long long)e.ord.candidates,
                (unsigned long long)e.ord.rotated,
                (unsigned long long)e.ord.advanced,
                (unsigned long long)e.ord.ranked,
                (unsigned long long)e.ord.moved);
  }
  for (const SlotEntry &e : entries) {
    const SlotEntry::Telem &t = e.tm;
    if (!t.occasions)
      continue;
    const uint64_t declined =
        t.dec_disabled + t.dec_cap + t.dec_preprocess + t.dec_guard +
        t.dec_budget + t.dec_delay + t.dec_material + t.dec_warmup +
        t.dec_profile;
    const char *balance = (t.admitted + declined == t.occasions) ? "" : "  ***UNACCOUNTED***";
    std::printf(
        "c slot %-18s occ %6llu adm %5llu ok %5llu | dec dis %llu cap %llu "
        "pre %llu grd %llu bud %llu dly %llu mat %llu warm %llu prof %llu "
        "| handed %llu spent %llu completed %llu | "
        "wrapped %llu%s\n",
        rules[e.rule].name, (unsigned long long)t.occasions,
        (unsigned long long)t.admitted, (unsigned long long)t.ok,
        (unsigned long long)t.dec_disabled, (unsigned long long)t.dec_cap,
        (unsigned long long)t.dec_preprocess, (unsigned long long)t.dec_guard,
        (unsigned long long)t.dec_budget, (unsigned long long)t.dec_delay,
        (unsigned long long)t.dec_material, (unsigned long long)t.dec_warmup,
        (unsigned long long)t.dec_profile,
        (unsigned long long)t.handed,
        (unsigned long long)t.spent, (unsigned long long)t.completed,
        (unsigned long long)t.wrapped, balance);
    if (t.followup_offered)
      std::printf("c followup %-14s offered %llu taken %llu eager %llu final %llu\n",
                  rules[e.rule].name,
                  (unsigned long long)t.followup_offered,
                  (unsigned long long)t.followup_taken,
                  (unsigned long long)t.followup_eager,
                  (unsigned long long)t.followup_final);
  }
}

int default_solve(Kernel &k, volatile sig_atomic_t *stop) {
  DefaultPolicy policy;
  const int res = policy.solve(k, stop);
  if (std::getenv("TACTIX_STRATEGY_CONFIG"))
    std::printf("c strategy-config %s\n",
                policy.strategy_config_snapshot().c_str());
  if (std::getenv("TACTIX_SLOT_STATS"))
    policy.inprocess().report(k);
  return res;
}

} // namespace tactix
