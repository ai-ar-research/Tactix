// S4 SwitchMode: flip the active instance-ranking mode between focused (VMTF
// queue) and stable (EVSIDS score heap). Transliterated from kissat/src/mode.c
// switch_to_stable_mode / switch_to_focused_mode (MIT). Pure `H`, no proof
// delta — flipping is sound in any state, so the guard only excludes a refuted
// kernel. When to switch is policy state (plan §5), as are the per-mode restart
// regimes.
#include "policies/ops/switchmode/switchmode.hpp"
#include "policies/heuristics.hpp"

namespace tactix {

// Requires `H`: SwitchMode flips the ranking mode, which is `H` state — a pure
// precondition of a policy operation that genuinely needs `H` (plan §5).
RuleEligibility switchmode_guard(const Kernel &k) {
  RuleEligibility result;
  return result.fact("consistent", !k.inconsistent)
      .fact("heuristics-attached", k.h != nullptr);
}

ApplyResult switchmode_apply(Kernel &k) {
  assert(switchmode_guard(k));
  k.h->stable = !k.h->stable;
  k.stats.switched++;
  if (k.h->stable) {
    // entering stable: every var must be reachable via the score heap
    // (kissat bump.c kissat_update_scores)
    heuristics_update_scores(k);
  } else {
    // entering focused: the VMTF search cache must point at the queue
    // tail again (kissat queue.c kissat_reset_search_of_queue)
    heuristics_reset_queue_search(k);
  }
  return ApplyResult::Ok;
}

// Policy operation (plan §4): H-only, no proof delta.
TACTIX_REGISTER_POLICY_OP(SwitchMode, RuleTier::Macro, switchmode_guard,
                          switchmode_apply);

} // namespace tactix
