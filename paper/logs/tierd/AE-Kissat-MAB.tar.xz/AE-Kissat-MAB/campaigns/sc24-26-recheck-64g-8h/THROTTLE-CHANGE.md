# Throttle change

2026-10-09T02:57:18-04:00: ArrayTaskThrottle raised from 25 to 125 by user request ("raise it to 125").
Reason: rerun (A) 1757931 was nearly finished (7 tasks running), so its 100-slot share was idle.
The 10-minute quota governor (1757996; hold above 750 GB, release below 700 GB) still applies.
